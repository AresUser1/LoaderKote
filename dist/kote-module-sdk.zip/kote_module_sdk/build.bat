@echo off
rem ==============================================================================
rem Kotogram Module SDK Windows Build Script
rem Сборка модулей Kotogram на Windows через Clang / NDK
rem ==============================================================================

set SCRIPT_DIR=%~dp0
set INCLUDE_DIR=%SCRIPT_DIR%include
set SRC_DIR=%SCRIPT_DIR%src
set OUT_DIR=%SCRIPT_DIR%out

if not exist "%OUT_DIR%" mkdir "%OUT_DIR%"

echo ==========================================================
echo 🛠  Kotogram Module SDK Builder (Windows)
echo ==========================================================

where clang >nul 2>nul
if %errorlevel% neq 0 (
    echo [!] Ошибка: Clang не найден в PATH.
    echo Установите LLVM / Clang или используйте WSL / Linux.
    exit /b 1
)

for %%f in ("%SRC_DIR%\*.c") do (
    echo ⚙️ Компиляция %%~nxf...
    clang -O2 -shared -fPIC -std=c11 -I"%INCLUDE_DIR%" "%%f" -o "%OUT_DIR%\%%~nf.so"
    if %errorlevel% equ 0 (
        echo ✅ Успешно: "%OUT_DIR%\%%~nf.so"
    ) else (
        echo ❌ Ошибка сборки %%~nxf
    )
)

echo.
echo 🎉 Готово! Файлы в папке: %OUT_DIR%
