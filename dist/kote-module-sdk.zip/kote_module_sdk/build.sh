#!/usr/bin/env bash
set -euo pipefail
sdk="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
target=android
source_file=
for arg in "$@"; do
    case "$arg" in
        --host|--linux) target=host ;;
        --android) target=android ;;
        --help|-h) echo 'Использование: bash build.sh [файл.c|файл.cpp|файл.lua] [--android|--host]'; exit 0 ;;
        *) [[ -f "$arg" ]] || { echo "Нет исходника: $arg" >&2; exit 2; }; source_file="$arg" ;;
    esac
done
if [[ "$target" == android ]]; then
    ndk="${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-${ANDROID_HOME:-$HOME/android-toolchain/sdk}/ndk/26.3.11579264}}"
    cc="$ndk/toolchains/llvm/prebuilt/linux-x86_64/bin/aarch64-linux-android26-clang"
    cxx="${cc}++"
    out="$sdk/out/android-arm64-v8a"
else
    cc="${CC:-cc}"
    cxx="${CXX:-c++}"
    out="$sdk/out/host-$(uname -m)"
fi
mkdir -p "$out"
build() {
    local src="$1" name compiler
    name="$(basename -- "$src")"
    case "$src" in
        *.lua)
            if command -v luac >/dev/null; then luac -p "$src"; fi
            cp -- "$src" "$out/$name"
            return ;;
        *.c) compiler="$cc"; standard=c11 ;;
        *.cpp|*.cc) compiler="$cxx"; standard=c++20 ;;
        *) echo "Неизвестный тип исходника: $src" >&2; exit 2 ;;
    esac
    command -v "$compiler" >/dev/null || {
        echo "Не найден компилятор: $compiler. Android требует NDK; Linux-тесты запускайте с --host." >&2
        exit 1
    }
    local binary="$out/${name%.*}.so"
    "$compiler" -O2 -fPIC -shared -pthread -Wall -Wextra "-std=$standard" \
        -I"$sdk/include" "$src" -o "$binary"
    if [[ "$target" == android ]]; then
        python3 - "$binary" <<'ELF'
from pathlib import Path
import sys
payload = Path(sys.argv[1]).read_bytes()
if payload[:6] != b'\x7fELF\x02\x01' or int.from_bytes(payload[18:20], 'little') != 183:
    raise SystemExit('Ожидался Android ARM64 ELF; файл не подходит для установки.')
ELF
    fi
    printf 'Готово (%s): %s\n' "$target" "$binary"
}
if [[ -n "$source_file" ]]; then
    build "$source_file"
else
    shopt -s nullglob
    for src in "$sdk"/src/*.c "$sdk"/src/*.cpp "$sdk"/src/*.cc "$sdk"/src/*.lua; do build "$src"; done
fi
