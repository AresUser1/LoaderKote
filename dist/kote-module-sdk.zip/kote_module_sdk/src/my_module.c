// src/my_module.c
// Шаблон для создания нового нативного C-модуля юзербота Kotogram.
// Замените "my_module" и команду "mycmd" на свои.

#include <stdio.h>
#include <string.h>
#include "module_abi.h"

// Обработчик команды
static void cmd_mycmd(koto_ctx* ctx, const koto_api* api) {
    const char* args = api->cmd_args(ctx);
    while (args && (*args == ' ' || *args == '\t')) args++; // обрезка пробелов

    api->c_reset(ctx);
    api->c_fmt(ctx, "🚀 Модуль работает отлично!", KOTO_ENT_BOLD);
    
    if (args && *args) {
        api->c_text(ctx, "\nАргументы: ");
        api->c_fmt(ctx, args, KOTO_ENT_CODE);
    }
    
    api->c_edit(ctx, KOTO_FMT_PLAIN);
}

// Список команд модуля
static const koto_command COMMANDS[] = {
    {
        "mycmd",              // имя команды (вызывается через префикс: .mycmd)
        &cmd_mycmd,           // функция-обработчик
        KOTO_LEVEL_ALL,       // уровень доступа: KOTO_LEVEL_ALL (все), KOTO_LEVEL_TRUSTED, KOTO_LEVEL_OWNER
        "Описание вашей команды", // текст в .help
        "[аргументы]"         // подсказка аргументов в .help
    },
};

// Метаданные модуля
static const koto_module MODULE = {
    KOTO_MODULE_ABI,          // Версия ABI: 3
    "my_module",              // Уникальное системное имя модуля
    "Описание назначения модуля", // Описание
    "1.0.0",                  // Версия
    0,                        // min_host_version
    0,                        // flags: 0 (обычный) или KOTO_MOD_SYSTEM
    COMMANDS,
    sizeof(COMMANDS) / sizeof(COMMANDS[0]),
    NULL, 0,                  // on_watch, watch_flags
    NULL,                     // on_callback
    NULL, 0                   // settings, settings_count (см. examples/native/settings_demo.c)
};

// Экспорт модуля для хоста
const koto_module* koto_module_register(void) {
    return &MODULE;
}
