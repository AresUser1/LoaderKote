-- video_dl.lua: Пример модуля загрузки видео и медиа по ссылке в Telegram
name = "video_dl"
description = "Скачивание и отправка видео по ссылке (TikTok, YouTube, прямые URL)"
version = "1.0.0"

commands = {
    dl = { doc = "Скачать видео и отправить в чат: .dl <url>", usage = "<url>" },
    tt = { doc = "Скачать видео TikTok (пример): .tt <url>", usage = "<url>" }
}

function on_message(msg)
    if not msg.out then return end
    local text = msg.text or ""

    -- 1. Команда скачивания видео по ссылке
    if text:sub(1, 4) == ".dl " or text:sub(1, 4) == ".tt " then
        local url = text:sub(5):match("^%s*(%S+)%s*$")
        if not url or url == "" then
            msg:edit("⚠️ **Укажите ссылку на видео:**\n> `.dl <ссылка_на_видео>`")
            return
        end

        msg:edit("⏳ **Загружаю видео...**\n> " .. url)

        -- Скачивание потоком прямо в кэш устройства
        local file_path = koto.download(url)
        if not file_path then
            msg:edit("❌ **Ошибка загрузки:** не удалось скачать видео по указанной ссылке.")
            return
        end

        msg:edit("📤 **Отправка видео в Telegram...**")

        -- Отправка видео: .mp4/.mov/.webm автоматически отправляются как нативное видео с плеером
        msg:reply_file(file_path, "🎬 **Видео загружено:**\n> " .. url)

        -- Очистка временного файла и служебного сообщения
        os.remove(file_path)
        msg:delete()
        return
    end
end
