-- simple_echo.lua
-- Пример базового Lua-модуля для Kotogram / KoteLoader.
-- Реагирует на команду .echo <текст> и .lua_ping

name = "simple_echo"
description = "Пример эхо-модуля на Lua"
author = "Developer"
version = "1.0.0"

-- Список команд модуля для отображения в .help и .modules
commands = {
    echo = { doc = "Эхо сообщения", usage = "<текст>" },
    lua_ping = { doc = "Проверка отклика из Lua", usage = "" }
}

function on_message(msg)
    -- msg содержит:
    -- msg.id            (число)   - ID сообщения
    -- msg.text          (строка)  - текст сообщения
    -- msg.chat_id       (число)   - ID чата
    -- msg.sender_id     (число)   - ID отправителя
    -- msg.reply_to_msg_id (число) - ID сообщения, на которое ответили (или 0)
    -- msg.out           (булево)  - true, если сообщение отправлено нами

    if not msg.out then return end
    local text = msg.text or ""

    -- Команда .echo
    if text:sub(1, 5) == ".echo" then
        local arg = text:sub(6):match("^%s*(.-)%s*$")
        if arg == "" then
            koto.edit("ℹ️ Использование: `.echo <текст>`")
        else
            koto.edit("🔊 " .. arg)
            koto.log("Эхо отправлено: " .. arg)
        end
        return
    end

    -- Команда .lua_ping
    if text == ".lua_ping" then
        koto.edit("🏓 Понг из Lua-модуля!")
        return
    end
end
