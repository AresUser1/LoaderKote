name = "userinfo"
description = "Информация о пользователях и чатах (Section 27 ABI / v0.3.6)"
version = "1.0.0"
min_host_version = 26

commands = {
    whois = { doc = "Получить информацию о пользователе", usage = "[reply/@username/id]" },
    chat = { doc = "Получить информацию о текущем чате", usage = "" }
}

function on_message(msg)
    if not msg.out then return end
    local text = msg.text or ""

    if text:sub(1, 6) == ".whois" or text:sub(1, 5) == ".user" then
        local target_uid = 0
        if msg.reply and msg.reply.sender_id and msg.reply.sender_id ~= 0 then
            target_uid = msg.reply.sender_id
        end

        local first = msg:user_first_name(target_uid)
        local last = msg:user_last_name(target_uid)
        local uname = msg:user_username(target_uid)
        local full_json = msg:user_full(target_uid)

        local out = "👤 **Профиль пользователя:**\n"
        out = out .. "• **Имя:** " .. (first ~= "" and first or "—") .. "\n"
        if last ~= "" then
            out = out .. "• **Фамилия:** " .. last .. "\n"
        end
        if uname ~= "" then
            out = out .. "• **Юзернейм:** @" .. uname .. "\n"
        end
        if full_json and full_json ~= "{}" then
            out = out .. "\n📄 **Расширенный профиль (JSON):**\n```json\n" .. full_json .. "\n```"
        end
        msg:edit(out)
        return
    end

    if text:sub(1, 5) == ".chat" then
        local full_json = msg:chat_full()
        local out = "💬 **Информация о чате (JSON):**\n```json\n" .. full_json .. "\n```"
        msg:edit(out)
        return
    end
end
