-- examples/lua/canvas_draw.lua — Рисование поверх экрана и обмен рисунками на Lua
--
-- Команды:
--   .draw        — открыть холст для рисования поверх экрана
--   .drawpass    — включить сквозной режим (рисунок поверх рабочего стола)
--   .drawsend    — сохранить рисунок и отправить в текущий чат
--   .drawclear   — очистить холст
--   .drawhide    — скрыть холст
--   .drawstatus  — показать JSON-состояние оверлея

function on_command(cmd, args)
    if cmd == "draw" then
        local ok = koto.overlay_show(1, '{"mode":1,"pen_color":"#30D158","pen_width":10.0}')
        if ok then
            koto.reply("🎨 <b>Холст открыт для рисования!</b> Рисуйте по экрану пальцем.", "html")
        else
            koto.reply("❌ Не удалось открыть оверлей-холст (проверьте разрешение поверх других приложений).")
        end

    elseif cmd == "drawpass" then
        koto.overlay_show(0, '{"mode":0}')
        koto.reply("👁 <b>Сквозной режим включен.</b> Касания проходят сквозь рисунок на рабочий стол.", "html")

    elseif cmd == "drawsend" then
        local path = koto.overlay_save()
        if path and path ~= "" then
            local msg = koto.get_message()
            local cid = msg and msg.chat_id or 0
            koto.send_file(cid, path, "🎨 <i>Рисунок с оверлей-холста</i>", "html")
        else
            koto.reply("⚠️ Не удалось сохранить рисунок с холста.")
        end

    elseif cmd == "drawclear" then
        koto.overlay_clear()
        koto.reply("🗑 <b>Холст очищен.</b>", "html")

    elseif cmd == "drawhide" then
        koto.overlay_hide()
        koto.reply("🙈 <b>Холст скрыт.</b>", "html")

    elseif cmd == "drawstatus" then
        local state = koto.overlay_get_state()
        koto.reply("📊 <b>Статус оверлея:</b>\n<pre>" .. tostring(state) .. "</pre>", "html")
    end
end
