-- welcome_watcher.lua
-- Пример фонового вочкера входящих сообщений.
-- Автоматически здоровается, если в чате написали "ку" или "привет",
-- и ведёт счётчик приветствий в локальной БД koto.db.

name = "welcome_watcher"
description = "Пример фонового вочкера сообщений с БД"
author = "Developer"
version = "1.0.0"

function on_message(msg)
    -- Реагируем на входящие сообщения от других пользователей
    if msg.out then return end

    local text = string.lower(msg.text or "")
    if text == "привет" or text == "ку" or text == "хай" then
        -- Читаем и обновляем счётчик из БД
        local count = tonumber(koto.db.get("greetings_count") or "0") + 1
        koto.db.set("greetings_count", tostring(count))

        -- Отправляем ответ в чат
        koto.reply("👋 Привет! Я юзербот на Kotogram. Поздоровался уже " .. count .. " раз(а).")
        koto.log("Отправлено приветствие в чат " .. tostring(msg.chat_id))
    end
end
