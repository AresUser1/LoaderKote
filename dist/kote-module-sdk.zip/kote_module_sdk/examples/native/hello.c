// hello.c
// Минимальный пример нативного C-модуля для Kotogram (ABI 3).
// Реализует команду .hello [имя] с красивым форматированием.

#include "module_abi.h"

// ID кастомных эмодзи Telegram (опционально)
#define SPARKLE_EMOJI_ID 5431449001532594346LL

static void cmd_hello(koto_ctx* ctx, const koto_api* api) {
    // Получаем аргументы команды, переданные после ".hello "
    const char* args = api->cmd_args(ctx);
    while (args && (*args == ' ' || *args == '\t')) args++; // обрезка пробелов

    const char* target = (args && *args) ? args : "Мир";

    // Сбрасываем буфер композера сообщений
    api->c_reset(ctx);

    // Добавляем эмодзи
    api->c_emoji(ctx, "✨", SPARKLE_EMOJI_ID);

    // Добавляем жирный текст
    api->c_fmt(ctx, " Привет, ", KOTO_ENT_BOLD);

    // Имя оформляем моноширинным шрифтом (код)
    api->c_fmt(ctx, target, KOTO_ENT_CODE);
    api->c_fmt(ctx, "!", KOTO_ENT_BOLD);

    // Редактируем сообщение с командой
    api->c_edit(ctx, KOTO_FMT_PLAIN);
}

// Таблица команд модуля
static const koto_command COMMANDS[] = {
    {
        "hello",            // имя команды (вызов: .hello)
        &cmd_hello,         // указатель на функцию
        KOTO_LEVEL_ALL,     // уровень доступа (KOTO_LEVEL_ALL, KOTO_LEVEL_TRUSTED, KOTO_LEVEL_OWNER)
        "Приветствует пользователя.", // краткая справка для .help
        "[имя]"             // аргументы для справки
    },
};

// Метаданные модуля
static const koto_module MODULE = {
    KOTO_MODULE_ABI,        // версия ABI (3)
    "hello",                // уникальное имя модуля (латиница)
    "Пример простого модуля приветствия на C", // описание
    "1.0.0",                // версия
    0,                      // min_host_version (0 = любая)
    0,                      // флаги (0 или KOTO_MOD_SYSTEM)
    COMMANDS,               // массив команд
    sizeof(COMMANDS) / sizeof(COMMANDS[0]), // число команд
    NULL, 0,                // on_watch, watch_flags
    NULL,                   // on_callback
    NULL, 0                 // settings, settings_count
};

// Точка входа для загрузчика юзербота
const koto_module* koto_module_register(void) {
    return &MODULE;
}
