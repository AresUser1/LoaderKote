// btndemo.c — Демо-модуль покраса инлайн-кнопок (c_button_ex).
//   .btndemo                 — сообщение с кнопками Primary/Danger/Success + обычная
//                              + «Тыковка» 🎃 (кастом-эмодзи иконка, id вшит)
//   .btndemo <custom_emoji_id> — заменит иконку «Тыковки» на переданный id
// Тап по любой кнопке показывает всплывашку с её типом (проверка on_callback).
#include "module_abi.h"
#include <string.h>
#include <stdlib.h>

// Премиум кастом-эмодзи 🎃 для кнопки «Тыковка» (document_id).
#define PUMPKIN_EMOJI_ID 5330165297506693515LL

static void cmd_btndemo(koto_ctx* ctx, const koto_api* api) {
    api->c_reset(ctx);
    api->c_text(ctx, "Тест покраса инлайн-кнопок:");
    // Ряд 1: три цвета.
    api->c_button_ex(ctx, "Primary", "demo:p", 1, KOTO_BTN_PRIMARY, 0);
    api->c_button_ex(ctx, "Danger",  "demo:d", 0, KOTO_BTN_DANGER,  0);
    api->c_button_ex(ctx, "Success", "demo:s", 0, KOTO_BTN_SUCCESS, 0);
    // Ряд 2: обычная кнопка (как c_button, без покраса).
    api->c_button(ctx, "Обычная", "demo:x", 1);
    // Ряд 3: «Тыковка» с кастом-эмодзи иконкой.
    long long icon = PUMPKIN_EMOJI_ID;
    const char* args = api->cmd_args(ctx);
    if (args && *args) {
        long long id = strtoll(args, 0, 10);
        if (id) icon = id;
    }
    api->c_button_ex(ctx, "🎃 Тыковка", "demo:i", 1, KOTO_BTN_DEFAULT, icon);
    api->c_reply(ctx, KOTO_FMT_PLAIN);
}

static void on_cb(koto_ctx* ctx, const koto_api* api) {
    const char* d = api->cb_data(ctx);
    if (!d) return;
    if      (!strcmp(d, "demo:p")) api->cb_answer(ctx, "Синяя — primary",   0);
    else if (!strcmp(d, "demo:d")) api->cb_answer(ctx, "Красная — danger",  0);
    else if (!strcmp(d, "demo:s")) api->cb_answer(ctx, "Зелёная — success", 0);
    else if (!strcmp(d, "demo:i")) api->cb_answer(ctx, "Кнопка с иконкой",  0);
    else                           api->cb_answer(ctx, "Обычная кнопка",    0);
}

static const koto_command COMMANDS[] = {
    { "btndemo", &cmd_btndemo, KOTO_LEVEL_OWNER, "Демо покраса инлайн-кнопок", "[custom_emoji_id]" },
};

static const koto_module MODULE = {
    KOTO_MODULE_ABI, "btndemo", "Демо цветных инлайн-кнопок", "1.0.0", 18, 0,
    COMMANDS, 1, 0, 0, &on_cb, 0, 0, 0,
};
const koto_module* koto_module_register(void) { return &MODULE; }
