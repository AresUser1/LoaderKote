// examples/native/userinfo.c
// Демонстрационный модуль Kotogram (Section 27 ABI / Kotogram 0.3.6 Hotfix 4):
// Получение расширенных данных пользователей и чатов:
//   - Имя, фамилия, юзернейм (user_first_name, user_last_name, user_username)
//   - Полный профиль в JSON (user_full_json): био, подарки, др, музыка, истории, общие группы
//   - Данные о чате в JSON (chat_full_json): участники, админы, описание
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "module_abi.h"

static long long get_target_uid(koto_ctx* ctx, const koto_api* api) {
    long long reply_uid = api->reply_sender_id(ctx);
    if (reply_uid != 0) return reply_uid;

    const char* args = api->cmd_args(ctx);
    if (args && *args) {
        char tok[128] = {0};
        sscanf(args, "%127s", tok);
        if (tok[0] == '@') {
            long long resolved = api->resolve(ctx, tok + 1);
            if (resolved != 0) return resolved;
        } else {
            long long parsed = atoll(tok);
            if (parsed > 0) return parsed;
            long long resolved = api->resolve(ctx, tok);
            if (resolved != 0) return resolved;
        }
    }
    return api->sender_id(ctx);
}

// ── 1. Команда .whois / .user [reply/@user/id] ─────────────────────────────────
static void cmd_whois(koto_ctx* ctx, const koto_api* api) {
    long long uid = get_target_uid(ctx, api);

    char first[128] = {0};
    char last[128] = {0};
    char uname[128] = {0};
    char full_json[4096] = {0};

    api->user_first_name(ctx, uid, first, sizeof(first));
    api->user_last_name(ctx, uid, last, sizeof(last));
    api->user_username(ctx, uid, uname, sizeof(uname));
    api->user_full_json(ctx, uid, full_json, sizeof(full_json));

    api->c_reset(ctx);
    api->c_text(ctx, "👤 ");
    api->c_fmt(ctx, "Профиль пользователя\n\n", KOTO_ENT_BOLD);

    api->c_text(ctx, "• Имя: ");
    api->c_fmt(ctx, first[0] ? first : "—", KOTO_ENT_BOLD);
    api->c_text(ctx, "\n");

    if (last[0]) {
        api->c_text(ctx, "• Фамилия: ");
        api->c_fmt(ctx, last, KOTO_ENT_BOLD);
        api->c_text(ctx, "\n");
    }

    if (uname[0]) {
        api->c_text(ctx, "• Юзернейм: @");
        api->c_text(ctx, uname);
        api->c_text(ctx, "\n");
    }

    char id_str[32];
    snprintf(id_str, sizeof(id_str), "%lld", uid);
    api->c_text(ctx, "• ID: ");
    api->c_fmt(ctx, id_str, KOTO_ENT_CODE);
    api->c_text(ctx, "\n");

    if (full_json[0] && strcmp(full_json, "{}") != 0) {
        api->c_text(ctx, "\n📄 ");
        api->c_fmt(ctx, "Расширенные данные (JSON):\n", KOTO_ENT_BOLD);
        api->c_fmt(ctx, full_json, KOTO_ENT_CODE);
    }

    api->c_edit(ctx, 0);
}

// ── 2. Команда .chatinfo ──────────────────────────────────────────────────────
static void cmd_chatinfo(koto_ctx* ctx, const koto_api* api) {
    long long cid = api->chat_id(ctx);
    char full_json[4096] = {0};
    api->chat_full_json(ctx, cid, full_json, sizeof(full_json));

    api->c_reset(ctx);
    api->c_text(ctx, "💬 ");
    api->c_fmt(ctx, "Информация о чате\n\n", KOTO_ENT_BOLD);

    char id_str[32];
    snprintf(id_str, sizeof(id_str), "%lld", cid);
    api->c_text(ctx, "• ID чата: ");
    api->c_fmt(ctx, id_str, KOTO_ENT_CODE);
    api->c_text(ctx, "\n");

    if (full_json[0] && strcmp(full_json, "{}") != 0) {
        api->c_text(ctx, "\n📄 ");
        api->c_fmt(ctx, "Метаданные (JSON):\n", KOTO_ENT_BOLD);
        api->c_fmt(ctx, full_json, KOTO_ENT_CODE);
    }

    api->c_edit(ctx, 0);
}

static const koto_command COMMANDS[] = {
    { "whois",    &cmd_whois,    KOTO_LEVEL_ALL, "Информация о пользователе (имя, фамилия, JSON профиля)", "[reply/@user/id]" },
    { "userinfo", &cmd_whois,    KOTO_LEVEL_ALL, "Информация о пользователе", "[reply/@user/id]" },
    { "chatinfo", &cmd_chatinfo, KOTO_LEVEL_ALL, "Информация о текущем чате (метаданные JSON)", NULL },
};

static const koto_module MODULE = {
    KOTO_MODULE_ABI, "userinfo",
    "Просмотр информации о пользователях и чатах через Section 27 ABI.",
    "1.0.0", 26, 0,
    COMMANDS, (int)(sizeof COMMANDS / sizeof COMMANDS[0]),
    NULL, 0, NULL, NULL, 0, NULL
};

const koto_module* koto_module_register(void) {
    return &MODULE;
}
