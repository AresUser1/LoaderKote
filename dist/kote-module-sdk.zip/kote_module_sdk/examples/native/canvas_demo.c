/* examples/native/canvas_demo.c — Демонстрационный модуль оверлей-холста (Kote Canvas)
 *
 * Позволяет рисовать поверх экрана / рабочего стола через SYSTEM_ALERT_WINDOW,
 * сохранять рисунки и делиться ими со второй половинкой / друзьями прямо в чате!
 *
 * Команды:
 *   .canvas draw   — открыть холст в режиме рисования (касания рисуют на экране)
 *   .canvas pass   — переключить в сквозной режим (рисунок остаётся, клики проходят на рабочий стол)
 *   .canvas clear  — очистить текущий холст
 *   .canvas hide   — скрыть холст
 *   .canvas send   — сохранить текущий рисунок и отправить в чат
 *   .canvas status — показать текущее состояние холста (режим, путь, цвет)
 */
#include "module_abi.h"
#include <stdio.h>
#include <string.h>

static void cmd_canvas(koto_ctx* ctx, const koto_api* api) {
    if (!api->overlay_show) {
        api->c_reset(ctx);
        api->c_text(ctx, "❌ Оверлей-холст не поддерживается текущей версией ядра (требуется Kotogram 0.3.4+).");
        api->c_reply(ctx, 0);
        return;
    }

    const char* args = api->cmd_args(ctx);
    if (!args || !*args) {
        api->c_reset(ctx);
        api->c_fmt(ctx, "🎨 Оверлей-холст (Kote Canvas)\n\n", KOTO_ENT_BOLD);
        api->c_text(ctx, "Использование:\n");
        api->c_fmt(ctx, "• .canvas draw", KOTO_ENT_CODE);
        api->c_text(ctx, " — открыть холст для рисования\n");
        api->c_fmt(ctx, "• .canvas pass", KOTO_ENT_CODE);
        api->c_text(ctx, " — сквозной режим (поверх рабочего стола)\n");
        api->c_fmt(ctx, "• .canvas send", KOTO_ENT_CODE);
        api->c_text(ctx, " — отправить рисунок в текущий чат\n");
        api->c_fmt(ctx, "• .canvas clear", KOTO_ENT_CODE);
        api->c_text(ctx, " — очистить холст\n");
        api->c_fmt(ctx, "• .canvas hide", KOTO_ENT_CODE);
        api->c_text(ctx, " — скрыть холст\n");
        api->c_fmt(ctx, "• .canvas status", KOTO_ENT_CODE);
        api->c_text(ctx, " — статус и параметры\n");
        api->c_reply(ctx, 0);
        return;
    }

    if (strncmp(args, "draw", 4) == 0) {
        // Открываем режим рисования с ярким цветом
        api->overlay_show(ctx, KOTO_OVERLAY_DRAW, "{\"mode\":1,\"pen_color\":\"#FF2D55\",\"pen_width\":12.0}");
        api->c_reset(ctx);
        api->c_text(ctx, "🎨 Холст открыт в режиме ");
        api->c_fmt(ctx, "рисования", KOTO_ENT_BOLD);
        api->c_text(ctx, ". Рисуйте прямо по экрану пальцем!");
        api->c_reply(ctx, 0);
    } else if (strncmp(args, "pass", 4) == 0) {
        // Сквозной режим — клики проходят сквозь холст на рабочий стол
        api->overlay_show(ctx, KOTO_OVERLAY_PASSTHROUGH, "{\"mode\":0}");
        api->c_reset(ctx);
        api->c_text(ctx, "👁 Холст переключён в ");
        api->c_fmt(ctx, "сквозной режим", KOTO_ENT_BOLD);
        api->c_text(ctx, " (клики проходят на рабочий стол/приложения).");
        api->c_reply(ctx, 0);
    } else if (strncmp(args, "clear", 5) == 0) {
        api->overlay_clear(ctx);
        api->c_reset(ctx);
        api->c_text(ctx, "🗑 Холст успешно очищен.");
        api->c_reply(ctx, 0);
    } else if (strncmp(args, "hide", 4) == 0) {
        api->overlay_hide(ctx);
        api->c_reset(ctx);
        api->c_text(ctx, "🙈 Оверлей-холст скрыт.");
        api->c_reply(ctx, 0);
    } else if (strncmp(args, "send", 4) == 0) {
        char saved_path[512] = {0};
        int ok = api->overlay_save(ctx, saved_path, sizeof(saved_path));
        if (ok && saved_path[0]) {
            long long cid = api->chat_id(ctx);
            api->c_reset(ctx);
            api->c_text(ctx, "🎨 Мой рисунок с экрана!");
            api->c_send_file(ctx, cid, saved_path, 0);
        } else {
            api->c_reset(ctx);
            api->c_text(ctx, "⚠️ Не удалось сохранить холст (возможно, он пуст или не был открыт).");
            api->c_reply(ctx, 0);
        }
    } else if (strncmp(args, "status", 6) == 0) {
        char state_json[1024] = {0};
        api->overlay_get_state(ctx, state_json, sizeof(state_json));
        api->c_reset(ctx);
        api->c_fmt(ctx, "📊 Состояние оверлей-холста:\n", KOTO_ENT_BOLD);
        api->c_fmt(ctx, state_json, KOTO_ENT_PRE);
        api->c_reply(ctx, 0);
    } else {
        api->c_reset(ctx);
        api->c_text(ctx, "Неизвестное поддействие. Используйте: draw, pass, send, clear, hide, status.");
        api->c_reply(ctx, 0);
    }
}

static const koto_command commands[] = {
    { "canvas", cmd_canvas, KOTO_LEVEL_OWNER, "Управление прозрачным оверлей-холстом", "[draw|pass|send|clear|hide|status]" },
};

static const koto_module module_desc = {
    .abi_version      = KOTO_MODULE_ABI,
    .name             = "canvas_demo",
    .description      = "Демонстрация прозрачного оверлей-холста для рисования и отображения поверх экрана",
    .version          = "1.0.0",
    .min_host_version = 24, // Kotogram 0.3.4+
    .flags            = 0,
    .commands         = commands,
    .command_count    = 1,
    .on_watch         = NULL,
    .watch_flags      = 0,
    .on_callback      = NULL,
    .settings         = NULL,
    .settings_count   = 0,
    .update_url       = NULL
};

const koto_module* koto_module_register(void) {
    return &module_desc;
}
