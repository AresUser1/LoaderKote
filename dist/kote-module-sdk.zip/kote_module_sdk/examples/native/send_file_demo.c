// send_file_demo.c
// Пример отправки файлов и медиа на C/C++ для Kotogram (ABI 3).
// Показывает логику отправки:
// 1. Отправка файла с диска с кликабельной ссылкой в подписи и инлайн-кнопками
// 2. По веб-ссылке (URL)
// 3. Файла из буфера в оперативной памяти (c_send_bytes)
// 4. Обработка нажатий на инлайн-кнопки (on_callback)

#include "module_abi.h"
#include <stdio.h>
#include <string.h>

// ── 1. Команда .sendlocal <path> ─────────────────────────────────────────────
// Отправка локального файла с устройства по абсолютному пути.
// ВАЖНО: Даже если у модуля зарегистрирован on_callback, отправка файлов
// ВСЕГДА выполняется клиентом юзербота напрямую через MTProto sendMedia!
// А если к сообщению добавлены c_button(), движок автоматически прикрепляет
// кнопки через вспомогательного бота (via @bot).
static void cmd_send_local(koto_ctx* ctx, const koto_api* api) {
    const char* path = api->cmd_args(ctx);
    while (path && (*path == ' ' || *path == '\t')) path++;
    if (!path || !*path) {
        api->c_reset(ctx);
        api->c_markdown(ctx, "⚠️ **Использование:** `.sendlocal </абсолютный/путь/к/файлу>`");
        api->c_edit(ctx, 0);
        return;
    }

    long long cid = api->chat_id(ctx);

    // Подпись к файлу с кликабельной ссылкой и форматированием
    api->c_reset(ctx);
    api->c_markdown(ctx, "📁 **Локальный файл с устройства**\n> Документация: ");
    api->c_url(ctx, "Kotogram SDK v0.2.7", "https://github.com/AresUser1/LoaderKote");
    api->c_text(ctx, "\nНажмите кнопку ниже для проверки:");

    // Прикрепляем инлайн-кнопки к файлу
    api->c_button(ctx, "🔔 Нажми меня", "btn_click_1", 0);
    api->c_button(ctx, "ℹ️ Инфо", "btn_info", 0);

    // c_send_file отправит файл юзерботом, а кнопки прикрепятся ботом
    api->c_send_file(ctx, cid, path, 0);
}

// ── 2. Команда .sendurl <url> ────────────────────────────────────────────────
// Отправка файла или медиа по прямой веб-ссылке (http/https).
static void cmd_send_url(koto_ctx* ctx, const koto_api* api) {
    const char* args = api->cmd_args(ctx);
    while (args && (*args == ' ' || *args == '\t')) args++;
    if (!args || !*args) {
        api->c_reset(ctx);
        api->c_markdown(ctx, "⚠️ **Использование:** `.sendurl <прямая_ссылка_на_файл>`");
        api->c_edit(ctx, 0);
        return;
    }

    char url[1024];
    if (sscanf(args, "%1023s", url) != 1) return;

    long long cid = api->chat_id(ctx);

    api->c_reset(ctx);
    api->c_markdown(ctx, "📦 **Файл отправлен по ссылке:**\n> ");
    api->c_url(ctx, "Оригинал ссылки", url);

    api->c_send_file(ctx, cid, url, 0);
}

// ── 3. Команда .sendmem ──────────────────────────────────────────────────────
// Отправка файла напрямую из буфера в оперативной памяти (c_send_bytes)
static void cmd_send_mem(koto_ctx* ctx, const koto_api* api) {
    long long cid = api->chat_id(ctx);

    const char* sample_data = "Привет из Kotogram C/C++ ABI 3 (v0.2.7)!\nЭто сгенерированный в памяти текстовый файл.";
    int len = (int)strlen(sample_data);

    api->c_reset(ctx);
    api->c_markdown(ctx, "📄 **Сгенерированный файл из памяти**\n> Создан модулем без записи на диск.");
    api->c_button(ctx, "✨ Проверено", "btn_mem_ok", 0);

    // c_send_bytes: (ctx, chat_id, имя_файла, указатель_на_байты, размер, флаги)
    api->c_send_bytes(ctx, cid, "sample.txt", (const unsigned char*)sample_data, len, 0);
}

// ── 4. Обработчик нажатий на кнопки (on_callback) ───────────────────────────
static void on_callback(koto_ctx* ctx, const koto_api* api) {
    const char* data = api->cb_data(ctx);
    if (!data) return;

    if (strcmp(data, "btn_click_1") == 0) {
        // Показать всплывающее уведомление (Toast / Alert) в Telegram
        api->cb_answer(ctx, "🎉 Кнопка под файлом успешно сработала!", 0);
    } else if (strcmp(data, "btn_info") == 0) {
        api->cb_answer(ctx, "Kotogram v0.2.7: нативные файлы + инлайн-кнопки!", 1);
    } else if (strcmp(data, "btn_mem_ok") == 0) {
        api->cb_answer(ctx, "Файл из ОЗУ подтверждён!", 0);
    }
}

// Таблица команд модуля
static const koto_command COMMANDS[] = {
    {
        "sendlocal",
        &cmd_send_local,
        KOTO_LEVEL_ALL,
        "Отправить файл с диска со ссылкой в тексте и кнопками.",
        "<path>"
    },
    {
        "sendurl",
        &cmd_send_url,
        KOTO_LEVEL_ALL,
        "Отправить медиа или файл по ссылке (URL).",
        "<url>"
    },
    {
        "sendmem",
        &cmd_send_mem,
        KOTO_LEVEL_ALL,
        "Отправить файл напрямую из оперативной памяти.",
        ""
    }
};

// Дескриптор модуля
static const koto_module MODULE = {
    KOTO_MODULE_ABI,
    "send_file_demo",
    "Пример отправки файлов, кликабельных ссылок и инлайн-кнопок",
    "1.1.0",
    17, // KoteLoader v0.2.7+ (versionCode: 17)
    0,
    COMMANDS,
    sizeof(COMMANDS) / sizeof(COMMANDS[0]),
    NULL, 0,
    &on_callback, // Обработчик inline-кнопок
    NULL, 0,
    NULL
};

// Точка входа для загрузчика
const koto_module* koto_module_register(void) {
    return &MODULE;
}
