// bannerdemo.cpp
// Демо-модуль для Kotogram (C++ ABI 3): показывает работу c_banner.
// Отправляет via-bot сообщение с картинкой-баннером (link-preview) и кнопками;
// кнопки переключают баннер вкл/выкл, НЕ трогая сами кнопки — ровно как
// inline.form у Hikka (FHeta). Баннер — это превью по ссылке, а не загруженное
// медиа, поэтому его можно показать/спрятать обычным edit, сохранив клавиатуру.
//
// Команды:
//   .banner [url]  - прислать демо-сообщение с баннером и кнопками-переключателями

#include "module_abi.h"
#include <string>

namespace {

// Ключ в БД модуля, под которым прячем выбранный URL баннера (per-user).
// callback_data у Telegram ограничен 64 байтами, поэтому URL туда НЕ влезает —
// держим его в неймспейсе модуля, а в кнопках шлём короткие bd:on/bd:off/bd:done.
std::string url_key(const koto_api* api, koto_ctx* ctx) {
    return "url:" + std::to_string(api->sender_id(ctx));
}
std::string load_url(const koto_api* api, koto_ctx* ctx) {
    char buf[1024];
    int n = api->db_get(ctx, url_key(api, ctx).c_str(), buf, (int)sizeof(buf));
    if (n > 0) return std::string(buf, (size_t)n);
    return std::string();   // нет сохранённого url — баннер не показываем
}

// Нарисовать тело сообщения (текст + две кнопки-переключателя).
// state: показан ли сейчас баннер.
void render(koto_ctx* ctx, const koto_api* api, bool banner_on, const std::string& url) {
    api->c_reset(ctx);
    api->c_markdown(ctx,
        "🖼 **Демо баннера (c_banner)**\n\n"
        "Это сообщение ушло через бота-помощника. Картинка сверху — это\n"
        "link-preview (а не загруженное медиа), поэтому её можно включать и\n"
        "выключать кнопкой, не теряя клавиатуру.\n\n");
    api->c_markdown(ctx, banner_on
        ? "> Статус: баннер **показан** 🟢"
        : "> Статус: баннер **скрыт** 🔴");

    if (banner_on && !url.empty()) {
        // Баннер НАД текстом + крупное превью (как «шапка» у Hikka-форм).
        api->c_banner(ctx, url.c_str(), KOTO_BANNER_ABOVE | KOTO_BANNER_LARGE);
        api->c_button(ctx, "🙈 Скрыть баннер", "bd:off", 0);
    } else {
        // c_banner НЕ вызываем — на следующем edit превью пропадёт, кнопки живут.
        api->c_button(ctx, "🖼 Показать баннер", "bd:on", 0);
    }
    api->c_button(ctx, "✖️ Готово", "bd:done", 1);
}

// ── Команда .banner [url] ────────────────────────────────────────────────────
void cmd_banner(koto_ctx* ctx, const koto_api* api) {
    // Баннер прошивается хостом v23+; на старом хосте слот c_banner == nullptr.
    if (api->c_banner == nullptr) {
        api->c_reset(ctx);
        api->c_markdown(ctx,
            "❌ **Баннеры недоступны в этой версии KoteLoader.**\n"
            "> Обновите приложение, чтобы использовать c_banner.");
        api->c_edit(ctx, 0);
        return;
    }

    const char* raw = api->cmd_args(ctx);
    while (raw && (*raw == ' ' || *raw == '\t')) raw++;
    std::string url = (raw && *raw) ? std::string(raw) : std::string();
    while (!url.empty() && (url.back() == ' ' || url.back() == '\t')) url.pop_back();

    if (url.empty()) {
        api->c_reset(ctx);
        api->c_markdown(ctx,
            "🖼 **Демо c_banner**\n\n"
            "Укажи прямую ссылку на картинку:\n"
            "> `.banner <url>`\n\n"
            "Ссылка должна отдавать реальное изображение (200 `image/*`) — Telegram\n"
            "сам фетчит её и строит link-preview. Битая/404 ссылка → картинки не будет.\n"
            "> _Пример:_ `.banner https://example.com/pic.jpg`");
        api->c_edit(ctx, 0);
        return;
    }

    // Прячем URL в БД модуля — в callback_data он не влезет (лимит 64 байта).
    api->db_set(ctx, url_key(api, ctx).c_str(), url.c_str());

    render(ctx, api, /*banner_on=*/true, url);
    // Сообщение с кнопками уходит через бота-помощника как via-bot сообщение.
    api->c_edit(ctx, 0);
}

// ── Нажатия кнопок ────────────────────────────────────────────────────────────
void on_callback(koto_ctx* ctx, const koto_api* api) {
    const char* data = api->cb_data(ctx);
    if (!data) return;
    std::string d = data;

    if (d == "bd:done") {
        api->cb_answer(ctx, "Готово!", 0);
        api->c_reset(ctx);
        api->c_markdown(ctx, "✅ **Демо закрыто.**");
        api->c_edit(ctx, 0);   // убрать и баннер, и кнопки
        return;
    }

    if (d == "bd:on") {
        api->cb_answer(ctx, "Баннер показан", 0);
        render(ctx, api, /*banner_on=*/true, load_url(api, ctx));
        api->c_edit(ctx, 0);
        return;
    }

    if (d == "bd:off") {
        api->cb_answer(ctx, "Баннер скрыт", 0);
        render(ctx, api, /*banner_on=*/false, load_url(api, ctx));
        api->c_edit(ctx, 0);
        return;
    }

    api->cb_answer(ctx, "", 0);
}

const koto_command COMMANDS[] = {
    {
        "banner",
        &cmd_banner,
        KOTO_LEVEL_ALL,
        "Демо c_banner: via-bot сообщение с переключаемым баннером и кнопками.",
        "<url>"
    }
};

const koto_module MODULE = {
    KOTO_MODULE_ABI,
    "bannerdemo",
    "Демо баннера (c_banner): переключаемое link-preview фото + кнопки (C++ ABI 3)",
    "1.0.0",
    23,   // c_banner появился в KoteLoader versionCode 23+
    0,
    COMMANDS,
    sizeof(COMMANDS) / sizeof(COMMANDS[0]),
    nullptr, 0,
    &on_callback,
    nullptr, 0,
    nullptr
};

} // namespace

extern "C" const koto_module* koto_module_register(void) {
    return &MODULE;
}
