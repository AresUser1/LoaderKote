// counter.c
// Пример нативного C-модуля с работой с локальной базой данных SQLite.
// Команды:
// .counter        - показывает текущее значение и увеличивает на 1
// .counter reset  - сбрасывает счётчик в 0

#include <stdio.h>
#include <string.h>
#include "module_abi.h"

static void cmd_counter(koto_ctx* ctx, const koto_api* api) {
    const char* args = api->cmd_args(ctx);
    while (args && (*args == ' ' || *args == '\t')) args++;

    // Сброс счётчика
    if (args && strcmp(args, "reset") == 0) {
        api->db_set_int(ctx, "count", 0);
        api->c_reset(ctx);
        api->c_fmt(ctx, "🔄 Счётчик сброшен в 0.", KOTO_ENT_BOLD);
        api->c_edit(ctx, KOTO_FMT_PLAIN);
        return;
    }

    // Чтение текущего значения (по умолчанию 0)
    long long count = api->db_get_int(ctx, "count", 0);
    count++;
    // Сохранение нового значения
    api->db_set_int(ctx, "count", count);

    char buf[64];
    snprintf(buf, sizeof(buf), "%lld", count);

    api->c_reset(ctx);
    api->c_fmt(ctx, "🔢 Значение счётчика: ", KOTO_ENT_BOLD);
    api->c_fmt(ctx, buf, KOTO_ENT_CODE);
    api->c_fmt(ctx, " раз(а)", KOTO_ENT_BOLD);
    api->c_edit(ctx, KOTO_FMT_PLAIN);
}

static const koto_command COMMANDS[] = {
    {
        "counter",
        &cmd_counter,
        KOTO_LEVEL_TRUSTED,
        "Инкрементирует локальный счётчик или сбрасывает его.",
        "[reset]"
    },
};

static const koto_module MODULE = {
    KOTO_MODULE_ABI,
    "counter",
    "Пример работы с постоянным хранилищем базы данных модуля",
    "1.0.0",
    0, 0,
    COMMANDS, sizeof(COMMANDS) / sizeof(COMMANDS[0]),
    NULL, 0,
    NULL,
    NULL, 0
};

const koto_module* koto_module_register(void) {
    return &MODULE;
}
