// settings_demo.c
// Пример нативного модуля, регистрирующего настройки для инлайн-панели .cfg
// Команда: .sdemo — показывает текущие значения настроек

#include <stdio.h>
#include <string.h>
#include "module_abi.h"

// Декларация настроек модуля, которые отображаются в инлайн-панели .cfg:
static const koto_setting_field SETTINGS[] = {
    {
        "enabled",                  // ключ в БД
        "Включить уведомления",     // человекопонятное название
        KOTO_FIELD_BOOL,            // тип: булево (тумблер)
        "1",                        // значение по умолчанию (1 = включено)
        NULL
    },
    {
        "greeting",                 // ключ в БД
        "Текст приветствия",        // название
        KOTO_FIELD_STR,             // тип: строка
        "Приветствую!",             // значение по умолчанию
        NULL
    },
    {
        "limit",                    // ключ в БД
        "Лимит сообщений",          // название
        KOTO_FIELD_INT,             // тип: целое число
        "10",                       // значение по умолчанию
        NULL
    }
};

static void cmd_sdemo(koto_ctx* ctx, const koto_api* api) {
    char enabled_buf[16];
    char greeting_buf[128];
    char limit_buf[32];

    // Получаем текущие значения настроек (изменяются через .cfg)
    api->cfg_get(ctx, "enabled", enabled_buf, sizeof(enabled_buf));
    api->cfg_get(ctx, "greeting", greeting_buf, sizeof(greeting_buf));
    api->cfg_get(ctx, "limit", limit_buf, sizeof(limit_buf));

    api->c_reset(ctx);
    api->c_fmt(ctx, "⚙️ Текущие настройки модуля:\n", KOTO_ENT_BOLD);

    api->c_fmt(ctx, "• enabled: ", KOTO_ENT_BOLD);
    api->c_fmt(ctx, enabled_buf[0] ? enabled_buf : "дефолт", KOTO_ENT_CODE);
    api->c_text(ctx, "\n");

    api->c_fmt(ctx, "• greeting: ", KOTO_ENT_BOLD);
    api->c_fmt(ctx, greeting_buf[0] ? greeting_buf : "дефолт", KOTO_ENT_CODE);
    api->c_text(ctx, "\n");

    api->c_fmt(ctx, "• limit: ", KOTO_ENT_BOLD);
    api->c_fmt(ctx, limit_buf[0] ? limit_buf : "дефолт", KOTO_ENT_CODE);

    api->c_edit(ctx, KOTO_FMT_PLAIN);
}

static const koto_command COMMANDS[] = {
    {
        "sdemo",
        &cmd_sdemo,
        KOTO_LEVEL_TRUSTED,
        "Показывает текущие настройки модуля settings_demo.",
        NULL
    },
};

static const koto_module MODULE = {
    KOTO_MODULE_ABI,
    "settings_demo",
    "Пример модуля с настраиваемыми параметрами для команды .cfg",
    "1.0.0",
    0, 0,
    COMMANDS, sizeof(COMMANDS) / sizeof(COMMANDS[0]),
    NULL, 0,        /* on_watch, watch_flags */
    NULL,           /* on_callback */
    SETTINGS, sizeof(SETTINGS) / sizeof(SETTINGS[0]) /* settings, settings_count */
};

const koto_module* koto_module_register(void) {
    return &MODULE;
}
