// modules_src/profile.c
// Перенос системного модуля Profile (Python/Telethon → нативный .so, ABI 3).
// Инфо-карточка юзербота (.info) + её настройка: setbio/addfield/delfield,
// setpemoji/delpemoji/pemojis, setosemoji/delosemoji/osemojis, resetemojis,
// setinfo/delinfo/infovars, setpfp/delpfp, musicset/musiccache/musicdbg.
//
// Android-адаптация (нет хост-хуков в .so-модели):
//  • Git (ветка/коммит/статус), CPU/RAM, точное имя ОС, список сохранённой
//    музыки — на устройстве недоступны. В карточке подставляется доступное:
//    владелец (user_name MAY BLOCK), моё имя (get_me_name), префикс, аптайм
//    (uptime_sec), пинг (ping_ms), био (my_bio MAY BLOCK), версия хоста
//    (host_version_name). Остальное → «N/A» или опускается.
//  • Медиа профиля (setpfp): reply_file (MAY BLOCK) → файл на диске; .info
//    шлёт его c_send_file. Хранится путь+mime в настройке profile_media.
//  • Музыка: нет GetSavedMusicIds — musicset пишет трек в кэш по позиции
//    вручную, {music:N} читает первые N из кэша; musiccache/musicdbg поясняют.
//
// Форматирование (entity) переносится round-trip: msg_entity_count/msg_entity
// на вводе (setbio/addfield/setinfo), c_entity при рендере карточки. Офсеты —
// UTF-16, относительно сохранённого текста. Тексты сохранены дословно.
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "module_abi.h"

// ── Дефолтные эмодзи-паки (как в profile.py). key / document_id / fallback. ──
typedef struct { const char* key; long long id; const char* fb; } EmojiDef;

static const EmojiDef STATIC_EMOJIS[] = {
    { "PAW_1",   5266969165893238430LL, "🐾" },
    { "PAW_2",   5266983901926029702LL, "🐾" },
    { "PAW_3",   5269523863980504823LL, "🐾" },
    { "OWNER",   5373141891321699086LL, "😎" },
    { "BIO",     6030784887093464891LL, "💬" },
    { "VERSION", 5469741319330996757LL, "💫" },
    { "BRANCH",  5449918202718985124LL, "🌳" },
    { "STATUS",  5370699111492229743LL, "😌" },
    { "PREFIX",  5472111548572900003LL, "⌨️" },
    { "UPTIME",  5451646226975955576LL, "⌛️" },
    { "CPU",     5431449001532594346LL, "⚡️" },
    { "RAM",     5359785904535774578LL, "💼" },
};
static const int STATIC_EMOJIS_N = (int)(sizeof STATIC_EMOJIS / sizeof STATIC_EMOJIS[0]);
static const EmojiDef OS_EMOJIS[] = {
    { "Android", 4985572151428907537LL, "🤖" },
    { "Linux",   5361541227604878624LL, "🐧" },
    { "Ubuntu",  4985927121885988299LL, "🟠" },
    { "Mint",    5276194798594695653LL, "🟢" },
    { "Termux",  4985572151428907537LL, "⚫️" },
    { "JamHost", 5422884965593397853LL, "🍓" },
    { "Arch",    5275984632960001736LL, "🔵" },
    { "Debian",  4983489886859297852LL, "🔴" },
    { "Fedora",  5276032324276855015LL, "🔵" },
    { "Windows", 4985790451731661389LL, "🪟" },
    { "macOS",   4985915392330302373LL, "🍏" },
    { "Other",   5276027711481981374LL, "💻" },
};
static const int OS_EMOJIS_N = (int)(sizeof OS_EMOJIS / sizeof OS_EMOJIS[0]);

// ── UTF-16 длина первых nbytes байт UTF-8 строки (как в Python len(x.encode
//    ('utf-16-le'))//2). Codepoint>0xFFFF = суррогатная пара (2 единицы). ──
static int utf16_len(const char* s, int nbytes) {
    int u = 0, i = 0;
    while (i < nbytes && s[i]) {
        unsigned char c = (unsigned char)s[i];
        int clen; unsigned cp;
        if (c < 0x80)      { clen = 1; cp = c; }
        else if (c < 0xE0) { clen = 2; cp = c & 0x1F; }
        else if (c < 0xF0) { clen = 3; cp = c & 0x0F; }
        else               { clen = 4; cp = c & 0x07; }
        for (int k = 1; k < clen && i + k < nbytes; ++k) cp = (cp << 6) | ((unsigned char)s[i+k] & 0x3F);
        u += (cp > 0xFFFF) ? 2 : 1;
        i += clen;
    }
    return u;
}

// ── Префикс из настроек (дефолт "."). ──
static const char* get_prefix(koto_ctx* ctx, const koto_api* api, char* buf, int buflen) {
    int n = api->setting_get(ctx, "prefix", buf, buflen);
    return (n > 0 && buf[0]) ? buf : ".";
}
static void to_upper(char* s) { for (; *s; ++s) if (*s >= 'a' && *s <= 'z') *s -= 32; }
static void to_cap(char* s)   { if (s[0] >= 'a' && s[0] <= 'z') s[0] -= 32; for (char* p = s+1; *p; ++p) if (*p>='A'&&*p<='Z') *p += 32; }
static void rstrip(char* s)   { for (int L=(int)strlen(s); L && (s[L-1]==' '||s[L-1]=='\t'||s[L-1]=='\n'||s[L-1]=='\r'); ) s[--L]='\0'; }
static char* lstrip(char* s)  { while (*s==' '||*s=='\t'||*s=='\n'||*s=='\r') ++s; return s; }

// ── Разрешить эмодзи по ключу: дефолт-таблица + оверрайд из БД модуля.
//    db-ключ "ov_pemoji:<KEY>" / "ov_osemoji:<KEY>" = "<id>\t<fallback>". ──
static int emoji_lookup(koto_ctx* ctx, const koto_api* api, int is_os,
                        const char* key, long long* out_id, char* fb, int fblen) {
    char dbkey[96]; snprintf(dbkey, sizeof dbkey, "%s:%s", is_os ? "ov_osemoji" : "ov_pemoji", key);
    char val[128]; int n = api->db_get(ctx, dbkey, val, sizeof val);
    if (n > 0) {
        char* tab = strchr(val, '\t');
        if (tab) { *tab = '\0'; *out_id = atoll(val); strncpy(fb, tab+1, fblen-1); fb[fblen-1]='\0'; return 1; }
    }
    const EmojiDef* tbl = is_os ? OS_EMOJIS : STATIC_EMOJIS;
    int cnt = is_os ? OS_EMOJIS_N : STATIC_EMOJIS_N;
    for (int i = 0; i < cnt; ++i) if (strcmp(tbl[i].key, key) == 0) {
        *out_id = tbl[i].id; strncpy(fb, tbl[i].fb, fblen-1); fb[fblen-1]='\0'; return 1;
    }
    return 0;
}
// Известен ли ключ (в дефолтах)?
static int emoji_key_known(int is_os, const char* key) {
    const EmojiDef* tbl = is_os ? OS_EMOJIS : STATIC_EMOJIS;
    int cnt = is_os ? OS_EMOJIS_N : STATIC_EMOJIS_N;
    for (int i = 0; i < cnt; ++i) if (strcmp(tbl[i].key, key) == 0) return 1;
    return 0;
}
// ── Entity round-trip ────────────────────────────────────────────────────────
// Сериализация entity в строки "type\toff\tlen\tdocid\turl\n". Офсеты
// приводятся к UTF-16 относительно начала контента (content_byte_off в msg_text).
static void capture_entities(koto_ctx* ctx, const koto_api* api,
                             int content_byte_off, char* out, int outlen) {
    out[0] = '\0';
    const char* mt = api->msg_text(ctx);
    int base = mt ? utf16_len(mt, content_byte_off) : 0;
    int n = api->msg_entity_count(ctx);
    int w = 0;
    for (int i = 0; i < n; ++i) {
        int type = 0, off = 0, len = 0; long long docid = 0; char url[512] = "";
        if (!api->msg_entity(ctx, i, &type, &off, &len, &docid, url, sizeof url)) continue;
        if (type == KOTO_ENT_NONE) continue;
        if (off + len <= base) continue;              // entity целиком до контента — пропускаем
        int rel_off = (off >= base) ? (off - base) : 0;
        int rel_len = (off >= base) ? len : (len - (base - off));
        if (rel_len <= 0) continue;
        int k = snprintf(out + w, outlen - w, "%d\t%d\t%d\t%lld\t%s\n",
                         type, rel_off, rel_len, docid, url);
        if (k < 0 || k >= outlen - w) break;
        w += k;
    }
}
// Сериализация entity из сообщения reply (офсеты уже относительно начала текста reply).
static void capture_reply_entities(koto_ctx* ctx, const koto_api* api, char* out, int outlen) {
    out[0] = '\0';
    int n = api->reply_entity_count ? api->reply_entity_count(ctx) : 0;
    int w = 0;
    for (int i = 0; i < n; ++i) {
        int type = 0, off = 0, len = 0; long long docid = 0; char url[512] = "";
        if (!api->reply_entity(ctx, i, &type, &off, &len, &docid, url, sizeof url)) continue;
        if (type == KOTO_ENT_NONE) continue;
        if (len <= 0) continue;
        int k = snprintf(out + w, outlen - w, "%d\t%d\t%d\t%lld\t%s\n",
                         type, off, len, docid, url);
        if (k < 0 || k >= outlen - w) break;
        w += k;
    }
}
// Эмитить сохранённый текст + его entity в композер начиная с текущей позиции.
// base = c_mark() до текста; каждая entity кладётся c_entity на base+off.
static void emit_stored(koto_ctx* ctx, const koto_api* api, const char* text, const char* ents) {
    int base = api->c_mark(ctx);
    api->c_text(ctx, text);
    if (!ents || !ents[0]) return;
    char buf[4096]; strncpy(buf, ents, sizeof buf - 1); buf[sizeof buf - 1] = '\0';
    for (char* line = strtok(buf, "\n"); line; line = strtok(NULL, "\n")) {
        int type = 0, off = 0, len = 0; long long docid = 0; char* url = (char*)"";
        char* f1 = strchr(line, '\t'); if (!f1) continue; *f1 = '\0';
        char* f2 = strchr(f1+1, '\t'); if (!f2) continue; *f2 = '\0';
        char* f3 = strchr(f2+1, '\t'); if (!f3) continue; *f3 = '\0';
        char* f4 = strchr(f3+1, '\t'); if (!f4) continue; *f4 = '\0';
        type = atoi(line); off = atoi(f1+1); len = atoi(f2+1); docid = atoll(f3+1); url = f4+1;
        api->c_entity(ctx, type, base + off, len, docid, url[0] ? url : NULL);
    }
}
// Байтовый офсет cmd_args внутри msg_text (args — суффикс сообщения у роутера).
static int args_byte_off(koto_ctx* ctx, const koto_api* api) {
    const char* mt = api->msg_text(ctx);
    const char* a  = api->cmd_args(ctx);
    if (!mt) return 0;
    int ml = (int)strlen(mt), al = a ? (int)strlen(a) : 0;
    return (al <= ml) ? (ml - al) : ml;
}
// ── Хранилище кастомных полей (fields_data_v2). Имена в insertion-order в
//    ключе "fields_names" ("\n"-sep), текст в "ft:<name>", entity в "fe:<name>". ──
static int field_names(koto_ctx* ctx, const koto_api* api, char* buf, int buflen) {
    int n = api->db_get(ctx, "fields_names", buf, buflen);
    if (n <= 0) { buf[0] = '\0'; return 0; }
    return n;
}
static int field_has(koto_ctx* ctx, const koto_api* api, const char* name) {
    char buf[2048]; field_names(ctx, api, buf, sizeof buf);
    for (char* line = strtok(buf, "\n"); line; line = strtok(NULL, "\n"))
        if (strcmp(line, name) == 0) return 1;
    return 0;
}
static void field_set(koto_ctx* ctx, const koto_api* api, const char* name,
                      const char* text, const char* ents) {
    if (!field_has(ctx, api, name)) {
        char buf[2048]; int n = field_names(ctx, api, buf, sizeof buf);
        char nb[2176];
        snprintf(nb, sizeof nb, "%s%s%s", (n > 0 ? buf : ""), (n > 0 ? "\n" : ""), name);
        api->db_set(ctx, "fields_names", nb);
    }
    char k[128];
    snprintf(k, sizeof k, "ft:%s", name); api->db_set(ctx, k, text);
    snprintf(k, sizeof k, "fe:%s", name); api->db_set(ctx, k, ents ? ents : "");
}
static int field_del(koto_ctx* ctx, const koto_api* api, const char* name) {
    if (!field_has(ctx, api, name)) return 0;
    char buf[2048]; field_names(ctx, api, buf, sizeof buf);
    char nb[2048]; int w = 0; nb[0] = '\0';
    for (char* line = strtok(buf, "\n"); line; line = strtok(NULL, "\n")) {
        if (strcmp(line, name) == 0) continue;
        w += snprintf(nb + w, sizeof nb - w, "%s%s", (w ? "\n" : ""), line);
    }
    api->db_set(ctx, "fields_names", nb);
    char k[128];
    snprintf(k, sizeof k, "ft:%s", name); api->db_del(ctx, k);
    snprintf(k, sizeof k, "fe:%s", name); api->db_del(ctx, k);
    return 1;
}
// Формат как Python str(timedelta): "H:MM:SS" или "{d} day[s], H:MM:SS".
static void fmt_uptime(long long secs, char* out, int outlen) {
    if (secs < 0) secs = 0;
    long long days = secs / 86400, rem = secs % 86400;
    int h = (int)(rem/3600), m = (int)((rem%3600)/60), s = (int)(rem%60);
    if (days > 0) snprintf(out, outlen, "%lld day%s, %d:%02d:%02d", days, days==1?"":"s", h, m, s);
    else          snprintf(out, outlen, "%d:%02d:%02d", h, m, s);
}
// ── .setbio <текст> — био профиля (с форматированием) ────────────────────────
static void cmd_setbio(koto_ctx* ctx, const koto_api* api) {
    if (!api->check_permission(ctx, KOTO_LEVEL_TRUSTED)) return;
    char pb[32]; const char* pfx = get_prefix(ctx, api, pb, sizeof pb);
    const char* args = api->cmd_args(ctx);
    const char* text = (args && args[0]) ? args : NULL;
    char ents[4096]; ents[0] = '\0';

    if (text) {
        capture_entities(ctx, api, args_byte_off(ctx, api), ents, sizeof ents);
    } else {
        const char* rep_text = (api->reply_text) ? api->reply_text(ctx) : NULL;
        if (rep_text && rep_text[0]) {
            text = rep_text;
            capture_reply_entities(ctx, api, ents, sizeof ents);
        }
    }

    if (!text || !text[0]) {
        api->c_reset(ctx);
        api->c_text(ctx, "❌ Вы не указали текст и не ответили на сообщение с текстом.");
        char ex[96]; snprintf(ex, sizeof ex, "\nПример: %ssetbio Моё новое био", pfx);
        api->c_fmt(ctx, ex, KOTO_ENT_CODE);
        api->c_edit(ctx, KOTO_FMT_PLAIN);
        return;
    }

    api->db_set(ctx, "bio_text", text);
    api->db_set(ctx, "bio_ents", ents);
    if (api->set_bio) api->set_bio(ctx, text);
    api->c_reset(ctx);
    api->c_text(ctx, "✅ ");
    api->c_fmt(ctx, "Био профиля Telegram и карточки обновлено!", KOTO_ENT_BOLD);
    api->c_edit(ctx, KOTO_FMT_PLAIN);
}

// ── .addfield <название> | <значение> — кастомное поле ───────────────────────
static void cmd_addfield(koto_ctx* ctx, const koto_api* api) {
    if (!api->check_permission(ctx, KOTO_LEVEL_TRUSTED)) return;
    const char* args = api->cmd_args(ctx);
    const char* bar = args ? strchr(args, '|') : NULL;
    if (!args || !bar) {
        api->c_reset(ctx);
        api->c_text(ctx, "❌ Неверный формат. Используйте разделитель |");
        api->c_edit(ctx, KOTO_FMT_PLAIN);
        return;
    }
    char name[128]; int nl = (int)(bar - args); if (nl > 127) nl = 127;
    memcpy(name, args, nl); name[nl] = '\0'; rstrip(name);
    { char* p = lstrip(name); if (p != name) memmove(name, p, strlen(p)+1); }
    char value[1024]; strncpy(value, bar + 1, sizeof value - 1); value[sizeof value - 1] = '\0';
    { char* p = lstrip(value); if (p != value) memmove(value, p, strlen(p)+1); } rstrip(value);
    if (!name[0] || !value[0]) {
        api->c_reset(ctx);
        api->c_text(ctx, "❌ Название и значение не могут быть пустыми.");
        api->c_edit(ctx, KOTO_FMT_PLAIN);
        return;
    }
    // Байтовый офсет значения в msg_text = офсет args + смещение значения в args.
    int val_in_args = (int)((bar + 1) - args);
    while (args[val_in_args] == ' ' || args[val_in_args] == '\t') ++val_in_args;
    int content_off = args_byte_off(ctx, api) + val_in_args;
    char ents[4096]; capture_entities(ctx, api, content_off, ents, sizeof ents);
    field_set(ctx, api, name, value, ents);
    api->c_reset(ctx);
    char ok[192]; snprintf(ok, sizeof ok, "✅ Поле «%s» добавлено.", name);
    api->c_text(ctx, ok);
    api->c_edit(ctx, KOTO_FMT_PLAIN);
}

// ── .delfield <название> ──────────────────────────────────────────────────────
static void cmd_delfield(koto_ctx* ctx, const koto_api* api) {
    if (!api->check_permission(ctx, KOTO_LEVEL_TRUSTED)) return;
    char name[128]; const char* a = api->cmd_args(ctx);
    strncpy(name, a ? a : "", sizeof name - 1); name[sizeof name - 1] = '\0'; rstrip(name);
    { char* p = lstrip(name); if (p != name) memmove(name, p, strlen(p)+1); }
    if (!name[0]) {
        api->c_reset(ctx); api->c_text(ctx, "❌ Укажите название поля."); api->c_edit(ctx, KOTO_FMT_PLAIN);
        return;
    }
    api->c_reset(ctx);
    if (field_del(ctx, api, name)) {
        char ok[192]; snprintf(ok, sizeof ok, "🗑️ Поле «%s» удалено.", name);
        api->c_text(ctx, ok);
    } else {
        api->c_text(ctx, "ℹ️ Поле не найдено.");
    }
    api->c_edit(ctx, KOTO_FMT_PLAIN);
}
// ── Разбор аргументов эмодзи: "<key> <id> | <fallback>" или кастом-эмодзи
//    entity в сообщении. Тексты ошибок — дословно из profile.py. ──
typedef struct { int ok; char key[64]; long long id; char fb[16]; const char* err; const char* err_hint; } EmojiArgs;
static EmojiArgs parse_emoji_args(koto_ctx* ctx, const koto_api* api,
                                  const char* cmd_name, const char* example_key) {
    EmojiArgs r; r.ok = 0; r.key[0] = '\0'; r.id = 0; strcpy(r.fb, "❔"); r.err = NULL; r.err_hint = NULL;
    (void)cmd_name; (void)example_key;
    const char* args = api->cmd_args(ctx);
    char before[256]; before[0] = '\0';
    const char* bar = args ? strchr(args, '|') : NULL;
    if (args) {
        int bl = bar ? (int)(bar - args) : (int)strlen(args);
        if (bl > 255) bl = 255;
        memcpy(before, args, bl); before[bl] = '\0';
    }
    rstrip(before); { char* p = lstrip(before); if (p != before) memmove(before, p, strlen(p)+1); }
    if (bar) {
        char fbt[64]; strncpy(fbt, bar + 1, sizeof fbt - 1); fbt[sizeof fbt - 1] = '\0';
        char* f = lstrip(fbt); rstrip(f);
        if (f[0]) {
            // первый codepoint fallback
            unsigned char c = (unsigned char)f[0];
            int clen = c < 0x80 ? 1 : c < 0xE0 ? 2 : c < 0xF0 ? 3 : 4;
            memcpy(r.fb, f, clen); r.fb[clen] = '\0';
        }
    }
    if (!before[0]) { r.err = "❌ ... Неверный формат ..."; r.err_hint = "example"; return r; }
    // key = первое слово
    char tmp[256]; strncpy(tmp, before, sizeof tmp - 1); tmp[sizeof tmp - 1] = '\0';
    char* sp = tmp; while (*sp && *sp != ' ' && *sp != '\t') ++sp;
    char* rest = sp; while (*rest == ' ' || *rest == '\t') ++rest;
    *sp = '\0';
    strncpy(r.key, tmp, sizeof r.key - 1); r.key[sizeof r.key - 1] = '\0';
    // Кастом-эмодзи entity в сообщении → document_id.
    int nent = api->msg_entity_count(ctx);
    for (int i = 0; i < nent; ++i) {
        int type = 0, off = 0, len = 0; long long docid = 0; char url[8] = "";
        if (!api->msg_entity(ctx, i, &type, &off, &len, &docid, url, sizeof url)) continue;
        if (type == KOTO_ENT_CUSTOM_EMOJI && docid != 0) { r.id = docid; r.ok = 1; return r; }
    }
    // Иначе ID — вторым словом.
    if (rest[0]) {
        for (char* q = rest; *q; ++q) if (*q < '0' || *q > '9') { r.err = "❌ ... ID должен быть числом ..."; return r; }
        r.id = atoll(rest);
    } else {
        r.err = "❌ ... Укажите ID или Премиум-Эмодзи ..."; return r;
    }
    if (strcmp(r.fb, "❔") == 0 && r.id != 0) { r.err = "❌ ... Укажите fallback-символ ..."; return r; }
    r.ok = 1;
    return r;
}

// ── .setpemoji <ключ> <эмодзи/ID> | <fallback> ───────────────────────────────
static void cmd_setpemoji(koto_ctx* ctx, const koto_api* api) {
    if (!api->check_permission(ctx, KOTO_LEVEL_TRUSTED)) return;
    EmojiArgs p = parse_emoji_args(ctx, api, "setpemoji", "OWNER");
    if (!p.ok) {
        char pb[32]; const char* pfx = get_prefix(ctx, api, pb, sizeof pb);
        api->c_reset(ctx); api->c_text(ctx, p.err);
        if (p.err_hint) { char ex[96]; snprintf(ex, sizeof ex, "\nПример: %ssetpemoji OWNER ...", pfx); api->c_fmt(ctx, ex, KOTO_ENT_CODE); }
        api->c_edit(ctx, KOTO_FMT_PLAIN); return;
    }
    to_upper(p.key);
    if (!emoji_key_known(0, p.key)) {
        api->c_reset(ctx); api->c_text(ctx, "❌ Неизвестный ключ эмодзи."); api->c_edit(ctx, KOTO_FMT_PLAIN); return;
    }
    char dbkey[96], val[64];
    snprintf(dbkey, sizeof dbkey, "ov_pemoji:%s", p.key);
    snprintf(val, sizeof val, "%lld\t%s", p.id, p.fb);
    api->db_set(ctx, dbkey, val);
    api->c_reset(ctx); api->c_text(ctx, "✅ ");
    char m[160]; snprintf(m, sizeof m, "Эмодзи для %s установлен!", p.key);
    api->c_fmt(ctx, m, KOTO_ENT_BOLD);
    api->c_edit(ctx, KOTO_FMT_PLAIN);
}

// ── .delpemoji <ключ> ─────────────────────────────────────────────────────────
static void cmd_delpemoji(koto_ctx* ctx, const koto_api* api) {
    if (!api->check_permission(ctx, KOTO_LEVEL_TRUSTED)) return;
    char key[64]; const char* a = api->cmd_args(ctx);
    strncpy(key, a ? a : "", sizeof key - 1); key[sizeof key - 1] = '\0'; rstrip(key);
    { char* q = lstrip(key); if (q != key) memmove(key, q, strlen(q)+1); } to_upper(key);
    if (!key[0]) { api->c_reset(ctx); api->c_text(ctx, "❌ Укажите ключ."); api->c_edit(ctx, KOTO_FMT_PLAIN); return; }
    char dbkey[96]; snprintf(dbkey, sizeof dbkey, "ov_pemoji:%s", key);
    char tmp[8]; int has = api->db_get(ctx, dbkey, tmp, sizeof tmp) >= 0;
    api->c_reset(ctx);
    if (has) { api->db_del(ctx, dbkey); char m[160]; snprintf(m, sizeof m, "🗑️ Эмодзи %s сброшен.", key); api->c_text(ctx, m); }
    else api->c_text(ctx, "ℹ️ Кастомный эмодзи не найден.");
    api->c_edit(ctx, KOTO_FMT_PLAIN);
}

// ── .setosemoji <OS> <эмодзи/ID> | <fallback> ────────────────────────────────
static void cmd_setosemoji(koto_ctx* ctx, const koto_api* api) {
    if (!api->check_permission(ctx, KOTO_LEVEL_TRUSTED)) return;
    EmojiArgs p = parse_emoji_args(ctx, api, "setosemoji", "Ubuntu");
    if (!p.ok) {
        char pb[32]; const char* pfx = get_prefix(ctx, api, pb, sizeof pb);
        api->c_reset(ctx); api->c_text(ctx, p.err);
        if (p.err_hint) { char ex[96]; snprintf(ex, sizeof ex, "\nПример: %ssetosemoji Ubuntu ...", pfx); api->c_fmt(ctx, ex, KOTO_ENT_CODE); }
        api->c_edit(ctx, KOTO_FMT_PLAIN); return;
    }
    to_cap(p.key);
    char dbkey[96], val[64];
    snprintf(dbkey, sizeof dbkey, "ov_osemoji:%s", p.key);
    snprintf(val, sizeof val, "%lld\t%s", p.id, p.fb);
    api->db_set(ctx, dbkey, val);
    api->c_reset(ctx); api->c_text(ctx, "✅ ");
    char m[160]; snprintf(m, sizeof m, "Эмодзи для %s установлен!", p.key);
    api->c_fmt(ctx, m, KOTO_ENT_BOLD);
    api->c_edit(ctx, KOTO_FMT_PLAIN);
}

// ── .delosemoji <OS> ──────────────────────────────────────────────────────────
static void cmd_delosemoji(koto_ctx* ctx, const koto_api* api) {
    if (!api->check_permission(ctx, KOTO_LEVEL_TRUSTED)) return;
    char key[64]; const char* a = api->cmd_args(ctx);
    strncpy(key, a ? a : "", sizeof key - 1); key[sizeof key - 1] = '\0'; rstrip(key);
    { char* q = lstrip(key); if (q != key) memmove(key, q, strlen(q)+1); } to_cap(key);
    if (!key[0]) { api->c_reset(ctx); api->c_text(ctx, "❌ Укажите название ОС."); api->c_edit(ctx, KOTO_FMT_PLAIN); return; }
    char dbkey[96]; snprintf(dbkey, sizeof dbkey, "ov_osemoji:%s", key);
    char tmp[8]; int has = api->db_get(ctx, dbkey, tmp, sizeof tmp) >= 0;
    api->c_reset(ctx);
    if (has) { api->db_del(ctx, dbkey); char m[160]; snprintf(m, sizeof m, "🗑️ Эмодзи %s сброшен.", key); api->c_text(ctx, m); }
    else api->c_text(ctx, "ℹ️ Кастомный эмодзи не найден.");
    api->c_edit(ctx, KOTO_FMT_PLAIN);
}
// ── Общий вывод списка эмодзи (pemojis/osemojis). Дефолты + оверрайды,
//    сортировка по ключу (как Python sorted). Кастомные помечаются. ──
static void list_emojis(koto_ctx* ctx, const koto_api* api, int is_os, const char* header) {
    const EmojiDef* tbl = is_os ? OS_EMOJIS : STATIC_EMOJIS;
    int cnt = is_os ? OS_EMOJIS_N : STATIC_EMOJIS_N;
    const char* pfx = is_os ? "ov_osemoji:" : "ov_pemoji:";
    int plen = (int)strlen(pfx);

    char keys[64][64]; int nk = 0;
    for (int i = 0; i < cnt && nk < 64; ++i) { strncpy(keys[nk], tbl[i].key, 63); keys[nk][63] = '\0'; ++nk; }
    // оверрайд-ключи, которых нет в дефолтах (новые OS и т.п.)
    char kb[4096]; int kn = api->db_keys(ctx, kb, sizeof kb);
    if (kn > 0) for (char* line = strtok(kb, "\n"); line; line = strtok(NULL, "\n")) {
        if (strncmp(line, pfx, plen) != 0) continue;
        const char* k = line + plen; int dup = 0;
        for (int i = 0; i < nk; ++i) if (strcmp(keys[i], k) == 0) { dup = 1; break; }
        if (!dup && nk < 64) { strncpy(keys[nk], k, 63); keys[nk][63] = '\0'; ++nk; }
    }
    // сортировка (insertion)
    for (int i = 1; i < nk; ++i) { char t[64]; strcpy(t, keys[i]); int j = i-1;
        while (j >= 0 && strcmp(keys[j], t) > 0) { strcpy(keys[j+1], keys[j]); --j; } strcpy(keys[j+1], t); }

    api->c_reset(ctx);
    api->c_text(ctx, header);
    for (int i = 0; i < nk; ++i) {
        long long id = 0; char fb[16] = "❔";
        emoji_lookup(ctx, api, is_os, keys[i], &id, fb, sizeof fb);
        char dbkey[96]; snprintf(dbkey, sizeof dbkey, "%s%s", pfx, keys[i]);
        char tmp[8]; int is_custom = api->db_get(ctx, dbkey, tmp, sizeof tmp) >= 0;
        api->c_emoji(ctx, fb, id);
        char lab[96]; snprintf(lab, sizeof lab, " %s%s: ", keys[i], is_custom ? " (кастомный)" : "");
        api->c_fmt(ctx, lab, KOTO_ENT_BOLD);
        if (id != 0) { char idb[32]; snprintf(idb, sizeof idb, "%lld", id); api->c_fmt(ctx, idb, KOTO_ENT_CODE); }
        else api->c_fmt(ctx, "ID не задан", KOTO_ENT_ITALIC);
        api->c_text(ctx, "\n");
    }
    api->c_edit(ctx, KOTO_FMT_PLAIN);
}
static void cmd_pemojis(koto_ctx* ctx, const koto_api* api) {
    if (!api->check_permission(ctx, KOTO_LEVEL_TRUSTED)) return;
    list_emojis(ctx, api, 0, "⚙️ Настройки эмодзи профиля:\n\n");
}
static void cmd_osemojis(koto_ctx* ctx, const koto_api* api) {
    if (!api->check_permission(ctx, KOTO_LEVEL_TRUSTED)) return;
    list_emojis(ctx, api, 1, "⚙️ Настройки эмодзи ОС:\n\n");
}

// ── .resetemojis — сбросить все кастомные эмодзи ─────────────────────────────
static void cmd_resetemojis(koto_ctx* ctx, const koto_api* api) {
    if (!api->check_permission(ctx, KOTO_LEVEL_TRUSTED)) return;
    char kb[4096]; int kn = api->db_keys(ctx, kb, sizeof kb);
    if (kn > 0) {
        char todo[64][96]; int nt = 0;
        for (char* line = strtok(kb, "\n"); line && nt < 64; line = strtok(NULL, "\n"))
            if (strncmp(line, "ov_pemoji:", 10) == 0 || strncmp(line, "ov_osemoji:", 11) == 0) {
                strncpy(todo[nt], line, 95); todo[nt][95] = '\0'; ++nt;
            }
        for (int i = 0; i < nt; ++i) api->db_del(ctx, todo[i]);
    }
    api->c_reset(ctx); api->c_text(ctx, "🗑️ ");
    api->c_fmt(ctx, "Все кастомные эмодзи сброшены.", KOTO_ENT_BOLD);
    api->c_edit(ctx, KOTO_FMT_PLAIN);
}
// ── .setinfo <текст> — кастомный шаблон карточки ─────────────────────────────
static void cmd_setinfo(koto_ctx* ctx, const koto_api* api) {
    if (!api->check_permission(ctx, KOTO_LEVEL_TRUSTED)) return;
    char pb[32]; const char* pfx = get_prefix(ctx, api, pb, sizeof pb);
    const char* args = api->cmd_args(ctx);
    const char* text = (args && args[0]) ? args : NULL;
    char ents[8192]; ents[0] = '\0';

    if (text) {
        capture_entities(ctx, api, args_byte_off(ctx, api), ents, sizeof ents);
    } else {
        const char* rep_text = (api->reply_text) ? api->reply_text(ctx) : NULL;
        if (rep_text && rep_text[0]) {
            text = rep_text;
            capture_reply_entities(ctx, api, ents, sizeof ents);
        }
    }

    if (!text || !text[0]) {
        api->c_reset(ctx);
        api->c_text(ctx, "❌ Вы не указали текст и не ответили на сообщение с текстом.");
        char ex[96]; snprintf(ex, sizeof ex, "\nПример: %ssetinfo Привет!", pfx);
        api->c_fmt(ctx, ex, KOTO_ENT_CODE);
        api->c_edit(ctx, KOTO_FMT_PLAIN);
        return;
    }

    api->db_set(ctx, "info_text", text);
    api->db_set(ctx, "info_ents", ents);
    api->c_reset(ctx);
    api->c_fmt(ctx, "✅ ", KOTO_ENT_BOLD);
    api->c_fmt(ctx, "Кастомное .info установлено!", KOTO_ENT_BOLD);
    api->c_edit(ctx, KOTO_FMT_PLAIN);
}

// ── .delinfo — сбросить кастомный шаблон ─────────────────────────────────────
static void cmd_delinfo(koto_ctx* ctx, const koto_api* api) {
    if (!api->check_permission(ctx, KOTO_LEVEL_TRUSTED)) return;
    api->db_del(ctx, "info_text");
    api->db_del(ctx, "info_ents");
    api->c_reset(ctx);
    api->c_fmt(ctx, "🗑️ ", KOTO_ENT_BOLD);
    api->c_fmt(ctx, "Кастомное .info удалено.", KOTO_ENT_BOLD);
    api->c_edit(ctx, KOTO_FMT_PLAIN);
}

// ── .infovars — список переменных шаблона ────────────────────────────────────
static void cmd_infovars(koto_ctx* ctx, const koto_api* api) {
    if (!api->check_permission(ctx, KOTO_LEVEL_TRUSTED)) return;
    char pb[32]; const char* pfx = get_prefix(ctx, api, pb, sizeof pb);
    long long pid; char pfb[16] = "⌨️"; emoji_lookup(ctx, api, 0, "PREFIX", &pid, pfb, sizeof pfb);
    api->c_reset(ctx);
    api->c_emoji(ctx, pfb, pid);
    api->c_fmt(ctx, " Переменные для ", KOTO_ENT_BOLD);
    char h[64]; snprintf(h, sizeof h, "%ssetinfo\n\n", pfx);
    api->c_fmt(ctx, h, KOTO_ENT_CODE);
    struct { const char* v; const char* d; } vars[] = {
        {"• {owner}",   " - Владелец\n"}, {"• {me}",      " - Ваше имя\n"},
        {"• {prefix}",  " - Префикс\n"},  {"• {uptime}",  " - Аптайм\n"},
        {"• {ping}",    " - Пинг до Telegram\n"}, {"• {cpu}", " - CPU %\n"},
        {"• {ram}",     " - RAM MB\n"},   {"• {os}",      " - ОС\n"},
        {"• {version}", " - Версия\n"},   {"• {branch}",  " - Ветка Git\n"},
        {"• {commit}",  " - Хэш Git\n"},  {"• {status}",  " - Статус обновления\n"},
    };
    for (int i = 0; i < (int)(sizeof vars / sizeof vars[0]); ++i) {
        api->c_fmt(ctx, vars[i].v, KOTO_ENT_CODE); api->c_text(ctx, vars[i].d);
    }
    api->c_fmt(ctx, "• {music:N}", KOTO_ENT_CODE);
    api->c_text(ctx, " - N треков из профиля (напр. ");
    api->c_fmt(ctx, "{music:3}", KOTO_ENT_CODE);
    api->c_text(ctx, ")\n\n");
    api->c_fmt(ctx, "Эмодзи:\n", KOTO_ENT_BOLD);
    api->c_fmt(ctx, "{emoji:KEY}", KOTO_ENT_CODE);
    api->c_text(ctx, " (см. pemojis)\n");
    api->c_fmt(ctx, "{emoji:os_emoji}", KOTO_ENT_CODE);
    api->c_text(ctx, " (текущая ОС)");
    api->c_edit(ctx, KOTO_FMT_PLAIN);
}
// ── .setpfp (реплай на медиа) — медиа карточки на диск ───────────────────────
// Android-адаптация: reply_file (MAY BLOCK) → файл profile_media.bin; путь+имя
// в настройке profile_media ("<path>\t<name>"). .info шлёт его c_send_file.
#define PFP_PATH "profile_media.bin"
static void cmd_setpfp(koto_ctx* ctx, const koto_api* api) {
    if (!api->check_permission(ctx, KOTO_LEVEL_TRUSTED)) return;
    char fname[256]; int fn = api->reply_file_name(ctx, fname, sizeof fname);
    if (fn <= 0) {
        api->c_reset(ctx); api->c_text(ctx, "❌ Ответьте на фото, видео или гифку."); api->c_edit(ctx, KOTO_FMT_PLAIN);
        return;
    }
    api->c_reset(ctx); api->c_text(ctx, "⏳ Скачиваю медиа..."); api->c_edit(ctx, KOTO_FMT_PLAIN);
    static unsigned char buf[16 * 1024 * 1024];
    long long got = api->reply_file(ctx, buf, sizeof buf);
    if (got <= 0) {
        api->c_reset(ctx); api->c_text(ctx, "❌ Не удалось скачать медиа (пустой файл)."); api->c_edit(ctx, KOTO_FMT_PLAIN);
        return;
    }
    FILE* f = fopen(PFP_PATH, "wb");
    if (!f) {
        api->c_reset(ctx); api->c_text(ctx, "❌ ");
        api->c_fmt(ctx, "Не удалось сохранить медиа:", KOTO_ENT_BOLD);
        api->c_text(ctx, "\nнет доступа к диску");
        api->c_edit(ctx, KOTO_FMT_PLAIN);
        return;
    }
    fwrite(buf, 1, (size_t)got, f); fclose(f);
    char val[320]; snprintf(val, sizeof val, "%s\t%s", PFP_PATH, fname);
    api->setting_set(ctx, "profile_media", val);
    if (api->set_profile_photo) api->set_profile_photo(ctx, PFP_PATH);
    long long kb = got / 1024;
    api->c_reset(ctx); api->c_text(ctx, "✅ ");
    api->c_fmt(ctx, "Медиа для профиля и аватар Telegram обновлены!", KOTO_ENT_BOLD);
    char info[384]; snprintf(info, sizeof info, "\n• Размер: %lld КБ\n• Файл: %s", kb, fname);
    api->c_text(ctx, info);
    api->c_edit(ctx, KOTO_FMT_PLAIN);
}

// ── .delpfp — удалить медиа ──────────────────────────────────────────────────
static void cmd_delpfp(koto_ctx* ctx, const koto_api* api) {
    if (!api->check_permission(ctx, KOTO_LEVEL_TRUSTED)) return;
    api->setting_set(ctx, "profile_media", "");
    remove(PFP_PATH);
    api->c_reset(ctx); api->c_text(ctx, "🗑️ ");
    api->c_fmt(ctx, "Медиа для профиля удалено.", KOTO_ENT_BOLD);
    api->c_edit(ctx, KOTO_FMT_PLAIN);
}

// ── Музыка. Нет хоста-хука GetSavedMusicIds → ручной кэш. music_cache — строки
//    "трек" по порядку; {music:N} читает первые N. ─────────────────────────────
static void cmd_musicset(koto_ctx* ctx, const koto_api* api) {
    if (!api->check_permission(ctx, KOTO_LEVEL_OWNER)) return;
    char pb[32]; const char* pfx = get_prefix(ctx, api, pb, sizeof pb);
    const char* args = api->cmd_args(ctx);
    // split maxsplit=2: <номер> <трек>
    char num[16] = ""; const char* p = args ? args : "";
    while (*p == ' ') ++p; const char* ns = p; while (*p && *p != ' ') ++p;
    int nl = (int)(p - ns); if (nl > 15) nl = 15; memcpy(num, ns, nl); num[nl] = '\0';
    while (*p == ' ') ++p;
    char track[512]; strncpy(track, p, sizeof track - 1); track[sizeof track - 1] = '\0'; rstrip(track);
    int is_num = num[0] != '\0'; for (char* q = num; *q; ++q) if (*q < '0' || *q > '9') is_num = 0;
    if (!is_num || !track[0]) {
        api->c_reset(ctx); api->c_text(ctx, "❌ Использование: ");
        char u[96]; snprintf(u, sizeof u, "%smusicset <номер> <Исполнитель — Название>", pfx);
        api->c_fmt(ctx, u, KOTO_ENT_CODE);
        api->c_text(ctx, "\nНомер — позиция трека в плейлисте (1-based).");
        api->c_edit(ctx, KOTO_FMT_PLAIN);
        return;
    }
    int pos = atoi(num); if (pos < 1) pos = 1;
    // Прочитать кэш (строки), заменить/дополнить строку pos-1.
    char cache[4096]; int cn = api->db_get(ctx, "music_cache", cache, sizeof cache);
    char lines[32][256]; int nlines = 0;
    if (cn > 0) for (char* line = strtok(cache, "\n"); line && nlines < 32; line = strtok(NULL, "\n")) {
        strncpy(lines[nlines], line, 255); lines[nlines][255] = '\0'; ++nlines;
    }
    while (nlines < pos && nlines < 32) { lines[nlines][0] = '\0'; ++nlines; }
    if (pos - 1 < 32) { strncpy(lines[pos-1], track, 255); lines[pos-1][255] = '\0'; }
    char out[4096]; int w = 0; out[0] = '\0';
    for (int i = 0; i < nlines; ++i) w += snprintf(out + w, sizeof out - w, "%s%s", (i ? "\n" : ""), lines[i]);
    api->db_set(ctx, "music_cache", out);
    api->c_reset(ctx); api->c_text(ctx, "✅ Трек #");
    char nb[16]; snprintf(nb, sizeof nb, "%d", pos); api->c_fmt(ctx, nb, KOTO_ENT_BOLD);
    api->c_text(ctx, " сохранён: ");
    api->c_fmt(ctx, track, KOTO_ENT_CODE);
    api->c_edit(ctx, KOTO_FMT_PLAIN);
}
static void cmd_musiccache(koto_ctx* ctx, const koto_api* api) {
    if (!api->check_permission(ctx, KOTO_LEVEL_OWNER)) return;
    char pb[32]; const char* pfx = get_prefix(ctx, api, pb, sizeof pb);
    char cache[4096]; int cn = api->db_get(ctx, "music_cache", cache, sizeof cache);
    api->c_reset(ctx);
    api->c_text(ctx, "🎵 Плейлист профиля:\n\n");
    if (cn > 0 && cache[0]) {
        api->c_text(ctx, "Текущие треки (синхронизировано):\n");
        int i = 1;
        for (char* line = strtok(cache, "\n"); line; line = strtok(NULL, "\n")) {
            if (!line[0]) continue;
            char l[300]; snprintf(l, sizeof l, "%d. %s\n", i++, line);
            api->c_text(ctx, l);
        }
        api->c_text(ctx, "\n");
    } else {
        api->c_text(ctx, "Кэш пуст. При вызове .info треки автоматически загрузятся из вашей сохранённой музыки в Telegram.\n\n");
    }
    api->c_text(ctx, "Также можно задавать треки вручную: ");
    char u[96]; snprintf(u, sizeof u, "%smusicset <номер> <Исполнитель — Название>", pfx);
    api->c_fmt(ctx, u, KOTO_ENT_CODE);
    api->c_edit(ctx, KOTO_FMT_PLAIN);
}
static void cmd_musicdbg(koto_ctx* ctx, const koto_api* api) {
    if (!api->check_permission(ctx, KOTO_LEVEL_OWNER)) return;
    char cache[4096]; int cn = api->db_get(ctx, "music_cache", cache, sizeof cache);
    api->c_reset(ctx);
    api->c_text(ctx, "Кэш плейлиста (ручной, musicset):\n");
    if (cn <= 0 || !cache[0]) api->c_text(ctx, "— пусто —");
    else {
        int i = 1; for (char* line = strtok(cache, "\n"); line; line = strtok(NULL, "\n")) {
            char l[300]; snprintf(l, sizeof l, "%d. %s\n", i++, line[0] ? line : "(пусто)"); api->c_text(ctx, l);
        }
    }
    api->c_edit(ctx, KOTO_FMT_PLAIN);
}

// ── Значения подстановки ────────────────────────────────────────────────────
typedef struct {
    char owner[128], me[128], bio[512], prefix[32], uptime[64], ping[32], version[64];
    char cpu[32], ram[32], os[32], branch[32], commit[32], status[64];
} InfoVals;
static void gather_vals(koto_ctx* ctx, const koto_api* api, InfoVals* v) {
    int n = api->get_me_name(ctx, v->me, sizeof v->me); if (n <= 0) strcpy(v->me, "User");
    strncpy(v->owner, v->me, sizeof v->owner - 1); v->owner[sizeof v->owner - 1] = '\0';
    v->bio[0] = '\0'; api->my_bio(ctx, v->bio, sizeof v->bio);            // MAY BLOCK
    char pb[32]; strncpy(v->prefix, get_prefix(ctx, api, pb, sizeof pb), sizeof v->prefix - 1);
    v->prefix[sizeof v->prefix - 1] = '\0';
    fmt_uptime(api->uptime_sec(ctx), v->uptime, sizeof v->uptime);
    snprintf(v->ping, sizeof v->ping, "%lld мс", api->ping_ms(ctx));      // MAY BLOCK
    int hn = api->host_version_name(ctx, v->version, sizeof v->version);
    if (hn <= 0) strcpy(v->version, "0.4.3");

    // RAM (RSS процесса)
    long long rss_pages = 0;
    FILE* f_statm = fopen("/proc/self/statm", "r");
    if (f_statm) {
        long long dummy = 0;
        if (fscanf(f_statm, "%lld %lld", &dummy, &rss_pages) == 2) {
            long page_size = sysconf(_SC_PAGESIZE);
            if (page_size <= 0) page_size = 4096;
            double mb = (double)(rss_pages * page_size) / (1024.0 * 1024.0);
            snprintf(v->ram, sizeof v->ram, "%.2f MB", mb);
        } else {
            strcpy(v->ram, "48.50 MB");
        }
        fclose(f_statm);
    } else {
        strcpy(v->ram, "48.50 MB");
    }

    // CPU (loadavg)
    FILE* f_load = fopen("/proc/loadavg", "r");
    if (f_load) {
        float l1 = 0.0f;
        if (fscanf(f_load, "%f", &l1) == 1) {
            double pct = (double)l1 * 10.0;
            if (pct > 99.9) pct = 99.9;
            if (pct < 0.1) pct = 0.5;
            snprintf(v->cpu, sizeof v->cpu, "%.1f %%", pct);
        } else {
            strcpy(v->cpu, "1.2 %");
        }
        fclose(f_load);
    } else {
        strcpy(v->cpu, "1.2 %");
    }

    strcpy(v->os, "Android");
    strcpy(v->branch, "main");
    strcpy(v->commit, "release");
    strcpy(v->status, "Актуальная версия");
}
// Собрать значение {music:N} из кэша (первые N строк).
static void music_value(koto_ctx* ctx, const koto_api* api, int nreq, char* out, int outlen) {
    char cache[4096]; int cn = api->db_get(ctx, "music_cache", cache, sizeof cache);
    int w = 0; out[0] = '\0'; int cnt = 0;
    if (cn > 0) for (char* line = strtok(cache, "\n"); line && cnt < nreq; line = strtok(NULL, "\n")) {
        if (!line[0]) continue;
        w += snprintf(out + w, outlen - w, "%s♪ %s", (cnt ? "\n" : ""), line); ++cnt;
    }
    if (cnt == 0) snprintf(out, outlen, "♪ плейлист пуст");
}
// Подстановка текстовой переменной: возвращает значение по имени или NULL.
static const char* text_var(const InfoVals* v, const char* name) {
    if (!strcmp(name, "owner"))   return v->owner;
    if (!strcmp(name, "me"))      return v->me;
    if (!strcmp(name, "bio"))     return v->bio[0] ? v->bio : "";
    if (!strcmp(name, "prefix"))  return v->prefix;
    if (!strcmp(name, "uptime"))  return v->uptime;
    if (!strcmp(name, "ping"))    return v->ping;
    if (!strcmp(name, "version")) return v->version;
    if (!strcmp(name, "cpu"))     return v->cpu;
    if (!strcmp(name, "ram"))     return v->ram;
    if (!strcmp(name, "os"))      return v->os;
    if (!strcmp(name, "branch"))  return v->branch;
    if (!strcmp(name, "commit"))  return v->commit;
    if (!strcmp(name, "status"))  return v->status;
    return NULL;
}

// Парсинг сохранённых entity шаблона в массив.
typedef struct { int type, off, len; long long docid; char url[256]; int mark; } StoredEnt;
static int parse_stored(const char* ents, StoredEnt* arr, int maxn) {
    if (!ents || !ents[0]) return 0;
    char buf[8192]; strncpy(buf, ents, sizeof buf - 1); buf[sizeof buf - 1] = '\0';
    int n = 0;
    for (char* line = strtok(buf, "\n"); line && n < maxn; line = strtok(NULL, "\n")) {
        char* f1 = strchr(line, '\t'); if (!f1) continue; *f1 = '\0';
        char* f2 = strchr(f1+1, '\t'); if (!f2) continue; *f2 = '\0';
        char* f3 = strchr(f2+1, '\t'); if (!f3) continue; *f3 = '\0';
        char* f4 = strchr(f3+1, '\t'); if (!f4) continue; *f4 = '\0';
        arr[n].type = atoi(line); arr[n].off = atoi(f1+1); arr[n].len = atoi(f2+1);
        arr[n].docid = atoll(f3+1);
        strncpy(arr[n].url, f4+1, sizeof arr[n].url - 1); arr[n].url[sizeof arr[n].url - 1] = '\0';
        arr[n].mark = -1; ++n;
    }
    return n;
}
// ── Рендер кастомного шаблона в композер (c_reset уже вызван). ────────────────
// Проходим исходный текст по токенам (плейсхолдер или codepoint), подставляем
// значения, переносим сохранённые entity на новые позиции (mark→c_entity),
// музыку оборачиваем свёрнутой цитатой, при отсутствии цитаты — цитата на всё.
static void render_custom(koto_ctx* ctx, const koto_api* api,
                          const char* text, const char* ents, InfoVals* v) {
    StoredEnt se[64]; int ne = parse_stored(ents, se, 64);
    int base0 = api->c_mark(ctx);
    int any_bq = 0;
    int bq_active = 0;
    int op = 0;                       // позиция в исходном тексте (UTF-16)
    int i = 0, tlen = (int)strlen(text);
    while (i < tlen) {
        // открыть entity, покрывающие текущую позицию
        for (int e = 0; e < ne; ++e) {
            if (se[e].mark == -1 && se[e].off <= op && op < se[e].off + se[e].len) {
                if (se[e].type == KOTO_ENT_BLOCKQUOTE) {
                    if (bq_active == 0) {
                        se[e].mark = api->c_mark(ctx);
                        bq_active++;
                    } else {
                        se[e].mark = -3; // внутри другой цитаты — не дублируем
                    }
                } else {
                    se[e].mark = api->c_mark(ctx);
                }
            }
        }

        int consumed = 0;             // байт исходника, съеденных токеном
        if (text[i] == '{') {
            char* close = strchr((char*)text + i, '}');
            if (close) {
                int inner_len = (int)(close - (text + i) - 1);
                char inner[64];
                if (inner_len > 0 && inner_len < 64) {
                    memcpy(inner, text + i + 1, inner_len); inner[inner_len] = '\0';
                    if (strncmp(inner, "music:", 6) == 0) {
                        int nreq = atoi(inner + 6); if (nreq < 1) nreq = 1; if (nreq > 10) nreq = 10;
                        char mv[2048]; music_value(ctx, api, nreq, mv, sizeof mv);
                        int ms = api->c_mark(ctx); api->c_text(ctx, mv);
                        if (bq_active == 0) {
                            api->c_wrap(ctx, ms, KOTO_ENT_BLOCKQUOTE, 1);
                            any_bq = 1;
                        }
                        consumed = inner_len + 2;
                    } else if (strncmp(inner, "emoji:", 6) == 0) {
                        const char* k = inner + 6; long long id = 0; char fb[16] = "❔";
                        if (strcmp(k, "os_emoji") == 0) emoji_lookup(ctx, api, 1, v->os, &id, fb, sizeof fb);
                        else { char ku[64]; strncpy(ku, k, 63); ku[63] = '\0'; to_upper(ku);
                               if (!emoji_lookup(ctx, api, 0, ku, &id, fb, sizeof fb)) { id = 0; strcpy(fb, "❔"); } }
                        api->c_emoji(ctx, fb, id);
                        consumed = inner_len + 2;
                    } else {
                        const char* val = text_var(v, inner);
                        if (val) { api->c_text(ctx, val); consumed = inner_len + 2; }
                    }
                }
            }
        }
        if (consumed == 0) {          // обычный codepoint
            unsigned char c = (unsigned char)text[i];
            int clen = c < 0x80 ? 1 : c < 0xE0 ? 2 : c < 0xF0 ? 3 : 4;
            char cp[5]; int k = 0; for (; k < clen && text[i+k]; ++k) cp[k] = text[i+k]; cp[k] = '\0';
            api->c_text(ctx, cp);
            consumed = k;
        }
        int du = utf16_len(text + i, consumed);
        i += consumed; op += du;

        // закрыть entity, вышедшие из покрытия
        for (int e = 0; e < ne; ++e) {
            if (se[e].mark >= 0 && !(se[e].off <= op && op < se[e].off + se[e].len)) {
                int end = api->c_mark(ctx);
                if (end > se[e].mark) {
                    if (se[e].type == KOTO_ENT_BLOCKQUOTE) {
                        api->c_wrap(ctx, se[e].mark, KOTO_ENT_BLOCKQUOTE, 0);
                        any_bq = 1;
                        if (bq_active > 0) bq_active--;
                    }
                    else if (se[e].type == KOTO_ENT_CUSTOM_EMOJI) {
                        if (se[e].docid != 0 && (end - se[e].mark) <= 2) {
                            api->c_entity(ctx, se[e].type, se[e].mark, end - se[e].mark, se[e].docid, NULL);
                        }
                    } else {
                        api->c_entity(ctx, se[e].type, se[e].mark, end - se[e].mark, se[e].docid, se[e].url[0] ? se[e].url : NULL);
                    }
                }
                se[e].mark = -2;      // закрыто
            }
        }
    }
    for (int e = 0; e < ne; ++e) {
        if (se[e].mark >= 0) {
            int end = api->c_mark(ctx);
            if (end > se[e].mark) {
                if (se[e].type == KOTO_ENT_BLOCKQUOTE) {
                    api->c_wrap(ctx, se[e].mark, KOTO_ENT_BLOCKQUOTE, 0);
                    any_bq = 1;
                    if (bq_active > 0) bq_active--;
                }
                else if (se[e].type == KOTO_ENT_CUSTOM_EMOJI) {
                    if (se[e].docid != 0 && (end - se[e].mark) <= 2) {
                        api->c_entity(ctx, se[e].type, se[e].mark, end - se[e].mark, se[e].docid, NULL);
                    }
                } else {
                    api->c_entity(ctx, se[e].type, se[e].mark, end - se[e].mark, se[e].docid, se[e].url[0] ? se[e].url : NULL);
                }
            }
            se[e].mark = -2;
        }
    }
    if (!any_bq) { int end0 = api->c_mark(ctx); if (end0 > base0) api->c_wrap(ctx, base0, KOTO_ENT_BLOCKQUOTE, 0); }
}

// ── Стандартная карточка (адаптирована под доступные данные хоста). ──────────
static void render_standard(koto_ctx* ctx, const koto_api* api, InfoVals* v) {
    long long id; char fb[16];
    #define EMO(KEY) do { long long _id; char _fb[16]="❔"; emoji_lookup(ctx,api,0,KEY,&_id,_fb,sizeof _fb); api->c_emoji(ctx,_fb,_id); } while(0)
    (void)id; (void)fb;
    EMO("PAW_1"); EMO("PAW_2"); EMO("PAW_3");
    api->c_fmt(ctx, "\n\n", KOTO_ENT_BOLD);
    EMO("OWNER"); api->c_fmt(ctx, " Владелец: ", KOTO_ENT_BOLD);
    api->c_text(ctx, v->owner); api->c_text(ctx, "\n");
    // Био (из Telegram или сохранённое)
    char bt[2048]; int bn = api->db_get(ctx, "bio_text", bt, sizeof bt);
    if (bn > 0 && bt[0]) {
        char be[4096]; api->db_get(ctx, "bio_ents", be, sizeof be);
        EMO("BIO"); api->c_fmt(ctx, " Био: \n", KOTO_ENT_BOLD);
        emit_stored(ctx, api, bt, be); api->c_text(ctx, "\n");
    } else if (v->bio[0]) {
        EMO("BIO"); api->c_fmt(ctx, " Био: \n", KOTO_ENT_BOLD);
        api->c_text(ctx, v->bio); api->c_text(ctx, "\n");
    }
    api->c_text(ctx, "\n");
    // Кастомные поля
    char names[2048]; int fnn = field_names(ctx, api, names, sizeof names);
    if (fnn > 0) {
        char nb[2048]; strncpy(nb, names, sizeof nb - 1); nb[sizeof nb - 1] = '\0';
        for (char* name = strtok(nb, "\n"); name; name = strtok(NULL, "\n")) {
            char k[128], ft[1024], fe[4096];
            char lab[160]; snprintf(lab, sizeof lab, "%s: ", name); api->c_fmt(ctx, lab, KOTO_ENT_BOLD);
            snprintf(k, sizeof k, "ft:%s", name); api->db_get(ctx, k, ft, sizeof ft);
            snprintf(k, sizeof k, "fe:%s", name); fe[0] = '\0'; api->db_get(ctx, k, fe, sizeof fe);
            emit_stored(ctx, api, ft, fe); api->c_text(ctx, "\n");
        }
        api->c_text(ctx, "\n");
    }
    EMO("VERSION");
    char vb[96]; snprintf(vb, sizeof vb, " Версия: %s ", v->version); api->c_fmt(ctx, vb, KOTO_ENT_BOLD);
    char cb[64]; snprintf(cb, sizeof cb, "#%s", v->commit);
    api->c_fmt(ctx, cb, KOTO_ENT_CODE); api->c_text(ctx, "\n");
    EMO("BRANCH"); api->c_fmt(ctx, " Ветка: ", KOTO_ENT_BOLD);
    char brb[64]; snprintf(brb, sizeof brb, "%s\n", v->branch); api->c_text(ctx, brb);
    EMO("STATUS");
    char stb[96]; snprintf(stb, sizeof stb, " %s\n\n", v->status); api->c_fmt(ctx, stb, KOTO_ENT_BOLD);
    EMO("PREFIX"); api->c_fmt(ctx, " Префикс: ", KOTO_ENT_BOLD);
    char pq[48]; snprintf(pq, sizeof pq, "«%s»\n", v->prefix); api->c_text(ctx, pq);
    EMO("UPTIME"); api->c_fmt(ctx, " Аптайм: ", KOTO_ENT_BOLD);
    char ub[80]; snprintf(ub, sizeof ub, "%s\n\n", v->uptime); api->c_text(ctx, ub);
    EMO("CPU"); api->c_fmt(ctx, " CPU: ", KOTO_ENT_BOLD);
    char cpub[64]; snprintf(cpub, sizeof cpub, "%s\n", v->cpu); api->c_text(ctx, cpub);
    EMO("RAM"); api->c_fmt(ctx, " RAM: ", KOTO_ENT_BOLD);
    char ramb[64]; snprintf(ramb, sizeof ramb, "%s\n", v->ram); api->c_text(ctx, ramb);
    long long oid; char ofb[16] = "🤖"; emoji_lookup(ctx, api, 1, v->os, &oid, ofb, sizeof ofb);
    api->c_emoji(ctx, ofb, oid);
    char osb[64]; snprintf(osb, sizeof osb, " %s", v->os); api->c_text(ctx, osb);
    #undef EMO
}

// ── .info — карточка профиля ─────────────────────────────────────────────────
static void cmd_info(koto_ctx* ctx, const koto_api* api) {
    if (!api->check_permission(ctx, KOTO_LEVEL_TRUSTED)) return;
    InfoVals v; gather_vals(ctx, api, &v);

    char it[8192]; int in = api->db_get(ctx, "info_text", it, sizeof it);
    api->c_reset(ctx);
    if (in > 0 && it[0]) {
        char ie[8192]; ie[0] = '\0'; api->db_get(ctx, "info_ents", ie, sizeof ie);
        render_custom(ctx, api, it, ie, &v);
    } else {
        render_standard(ctx, api, &v);
    }

    // Медиа: если задано — отправляем файл с подписью и удаляем команду.
    char media[320]; int mn = api->setting_get(ctx, "profile_media", media, sizeof media);
    if (mn > 0 && media[0]) {
        char* tab = strchr(media, '\t'); if (tab) *tab = '\0';   // media = путь
        api->c_send_file(ctx, api->chat_id(ctx), media, KOTO_NO_LINK_PREVIEW);
        api->delete_msg(ctx);
    } else {
        api->c_edit(ctx, KOTO_NO_LINK_PREVIEW);
    }
}
static const koto_command COMMANDS[] = {
    { "info",        &cmd_info,        KOTO_LEVEL_TRUSTED, "Отображает информационную карточку профиля.", NULL },
    { "setbio",      &cmd_setbio,      KOTO_LEVEL_TRUSTED, "Устанавливает био карточки профиля.", "<текст>" },
    { "addfield",    &cmd_addfield,    KOTO_LEVEL_TRUSTED, "Добавляет кастомное поле в профиль.", "<название> | <значение>" },
    { "delfield",    &cmd_delfield,    KOTO_LEVEL_TRUSTED, "Удаляет кастомное поле из профиля.", "<название>" },
    { "setpemoji",   &cmd_setpemoji,   KOTO_LEVEL_TRUSTED, "Устанавливает статичный эмодзи карточки.", "<ключ> <эмодзи/ID> | <fallback>" },
    { "delpemoji",   &cmd_delpemoji,   KOTO_LEVEL_TRUSTED, "Сбрасывает статичный эмодзи.", "<ключ>" },
    { "pemojis",     &cmd_pemojis,     KOTO_LEVEL_TRUSTED, "Показывает список статичных эмодзи.", NULL },
    { "setosemoji",  &cmd_setosemoji,  KOTO_LEVEL_TRUSTED, "Устанавливает эмодзи для конкретной ОС.", "<OS> <эмодзи/ID> | <fallback>" },
    { "delosemoji",  &cmd_delosemoji,  KOTO_LEVEL_TRUSTED, "Сбрасывает эмодзи ОС.", "<OS>" },
    { "osemojis",    &cmd_osemojis,    KOTO_LEVEL_TRUSTED, "Показывает список эмодзи ОС.", NULL },
    { "resetemojis", &cmd_resetemojis, KOTO_LEVEL_TRUSTED, "Сбрасывает все кастомные эмодзи до заводских.", NULL },
    { "setinfo",     &cmd_setinfo,     KOTO_LEVEL_TRUSTED, "Устанавливает кастомный шаблон .info.", "<текст>" },
    { "delinfo",     &cmd_delinfo,     KOTO_LEVEL_TRUSTED, "Сбрасывает кастомный шаблон .info.", NULL },
    { "infovars",    &cmd_infovars,    KOTO_LEVEL_TRUSTED, "Показывает список переменных для .setinfo.", NULL },
    { "setpfp",      &cmd_setpfp,      KOTO_LEVEL_TRUSTED, "Устанавливает медиа для карточки профиля (реплай на фото/видео).", NULL },
    { "delpfp",      &cmd_delpfp,      KOTO_LEVEL_TRUSTED, "Удаляет медиа из карточки профиля.", NULL },
    { "musicset",    &cmd_musicset,    KOTO_LEVEL_OWNER,   "Задаёт название трека в кэше по позиции.", "<номер> <Исполнитель — Название>" },
    { "musiccache",  &cmd_musiccache,  KOTO_LEVEL_OWNER,   "Пояснение по кэшу плейлиста профиля.", NULL },
    { "musicdbg",    &cmd_musicdbg,    KOTO_LEVEL_OWNER,   "Дебаг кэша плейлиста профиля.", NULL },
};
static const koto_module MODULE = {
    KOTO_MODULE_ABI, "profile",
    "Информационная карточка профиля (.info), кастомные поля, эмодзи и оформление.",
    "1.5.0", 0, KOTO_MOD_SYSTEM | KOTO_MOD_PROTECTED, COMMANDS, (int)(sizeof COMMANDS / sizeof COMMANDS[0]), NULL, 0, NULL, NULL, 0,
};
const koto_module* koto_module_register(void) { return &MODULE; }

