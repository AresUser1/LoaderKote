#ifndef KOTO_UTILS_HPP
#define KOTO_UTILS_HPP

#include <string>
#include <vector>
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <memory>
#include <array>
#include <cstdarg>
#include <ctime>
#include <mutex>
#include <unistd.h>
#include "module_abi.h"

namespace koto_utils {

struct LogEntry {
    std::string time_str;
    std::string level;
    std::string tag;
    std::string msg;
};

class Logger {
public:
    static Logger& instance() {
        static Logger inst;
        return inst;
    }

    void log(const char* level, const char* tag, const char* fmt, ...) {
        char buf[1024];
        va_list args;
        va_start(args, fmt);
        vsnprintf(buf, sizeof(buf), fmt, args);
        va_end(args);

        time_t now = time(nullptr);
        struct tm tm_buf;
        localtime_r(&now, &tm_buf);
        char t_str[32];
        snprintf(t_str, sizeof(t_str), "%02d:%02d:%02d", tm_buf.tm_hour, tm_buf.tm_min, tm_buf.tm_sec);

        fprintf(stderr, "[%s][%s][%s] %s\n", t_str, level, tag, buf);

        std::lock_guard<std::mutex> lock(mtx_);
        entries_.push_back({t_str, level, tag, buf});
        if (entries_.size() > 50) {
            entries_.erase(entries_.begin());
        }
    }

    std::vector<LogEntry> get_entries() {
        std::lock_guard<std::mutex> lock(mtx_);
        return entries_;
    }

    void clear() {
        std::lock_guard<std::mutex> lock(mtx_);
        entries_.clear();
    }

private:
    std::mutex mtx_;
    std::vector<LogEntry> entries_;
};

} // namespace koto_utils

#ifndef KOTO_LOGI
#define KOTO_LOGI(tag, fmt, ...) ::koto_utils::Logger::instance().log("INFO", tag, fmt, ##__VA_ARGS__)
#endif
#ifndef KOTO_LOGW
#define KOTO_LOGW(tag, fmt, ...) ::koto_utils::Logger::instance().log("WARN", tag, fmt, ##__VA_ARGS__)
#endif
#ifndef KOTO_LOGE
#define KOTO_LOGE(tag, fmt, ...) ::koto_utils::Logger::instance().log("ERR", tag, fmt, ##__VA_ARGS__)
#endif
#ifndef KOTO_LOGD
#define KOTO_LOGD(tag, fmt, ...) ::koto_utils::Logger::instance().log("DEBUG", tag, fmt, ##__VA_ARGS__)
#endif

namespace koto_utils {

// Обрезка пробельных символов
inline std::string trim(const std::string& s) {
    auto start = s.find_first_not_of(" \t\r\n");
    if (start == std::string::npos) return "";
    auto end = s.find_last_not_of(" \t\r\n");
    return s.substr(start, end - start + 1);
}

// Замена всех вхождений подстроки
inline std::string replace_all(std::string str, const std::string& from, const std::string& to) {
    if (from.empty()) return str;
    size_t start_pos = 0;
    while ((start_pos = str.find(from, start_pos)) != std::string::npos) {
        str.replace(start_pos, from.length(), to);
        start_pos += to.length();
    }
    return str;
}

// URL-кодирование для поисковых запросов и параметров
inline std::string url_encode(const std::string& value) {
    std::ostringstream escaped;
    escaped.fill('0');
    escaped << std::hex;

    for (unsigned char c : value) {
        if (std::isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') {
            escaped << c;
        } else {
            escaped << '%' << std::setw(2) << std::uppercase << int(c);
        }
    }
    return escaped.str();
}

// Экранирование для shell аргументов (защита от инъекций при вызове curl)
inline std::string shell_escape(const std::string& s) {
    std::string out = "'";
    for (char c : s) {
        if (c == '\'') {
            out += "'\\''";
        } else {
            out += c;
        }
    }
    out += "'";
    return out;
}

// HTTP GET запрос через хост-API или fallback через curl
inline std::string http_get(const koto_api* api, koto_ctx* ctx, const std::string& url, const std::vector<std::string>& headers = {}, int timeout_sec = 10) {
    if (api && api->http_get) {
        std::vector<unsigned char> buf(256 * 1024);
        long long n = api->http_get(ctx, url.c_str(), buf.data(), static_cast<int>(buf.size()));
        if (n > 0) {
            return std::string(reinterpret_cast<char*>(buf.data()), static_cast<size_t>(n));
        }
    }
    std::string cmd = "curl -sL --max-time " + std::to_string(timeout_sec);
    for (const auto& h : headers) {
        cmd += " -H " + shell_escape(h);
    }
    cmd += " " + shell_escape(url);

    struct PipeCloser {
        void operator()(FILE* fp) const { if (fp) pclose(fp); }
    };
    std::array<char, 4096> buffer;
    std::string result;
    std::unique_ptr<FILE, PipeCloser> pipe(popen(cmd.c_str(), "r"));
    if (!pipe) return "";
    while (fgets(buffer.data(), buffer.size(), pipe.get()) != nullptr) {
        result += buffer.data();
    }
    return result;
}

inline std::string http_get(const std::string& url, const std::vector<std::string>& headers = {}, int timeout_sec = 10) {
    return http_get(nullptr, nullptr, url, headers, timeout_sec);
}

// Скачивание файла по URL через хост-API (NativeBridge.downloadFile) или fallback через curl
inline bool download_file(const koto_api* api, koto_ctx* ctx, const std::string& url, const std::string& out_path, const std::vector<std::string>& headers = {}, int timeout_sec = 60) {
    if (api && api->download_file) {
        if (api->download_file(ctx, url.c_str(), out_path.c_str()) != 0) {
            FILE* f = fopen(out_path.c_str(), "rb");
            if (f) {
                fseek(f, 0, SEEK_END);
                long sz = ftell(f);
                fclose(f);
                if (sz > 0) return true;
            }
        }
    }
    std::string cmd = "curl -sL --max-time " + std::to_string(timeout_sec);
    for (const auto& h : headers) {
        cmd += " -H " + shell_escape(h);
    }
    cmd += " -o " + shell_escape(out_path) + " " + shell_escape(url);

    int ret = std::system(cmd.c_str());
    if (ret != 0) return false;

    FILE* f = fopen(out_path.c_str(), "rb");
    if (!f) return false;
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    fclose(f);
    return size > 0;
}

inline bool download_file(const std::string& url, const std::string& out_path, const std::vector<std::string>& headers = {}, int timeout_sec = 60) {
    return download_file(nullptr, nullptr, url, out_path, headers, timeout_sec);
}

// Форматирование секунд в формат MM:SS или HH:MM:SS
inline std::string format_duration(long long total_seconds) {
    if (total_seconds < 0) total_seconds = 0;
    long long hours = total_seconds / 3600;
    long long minutes = (total_seconds % 3600) / 60;
    long long seconds = total_seconds % 60;

    char buf[32];
    if (hours > 0) {
        snprintf(buf, sizeof(buf), "%02lld:%02lld:%02lld", hours, minutes, seconds);
    } else {
        snprintf(buf, sizeof(buf), "%02lld:%02lld", minutes, seconds);
    }
    return std::string(buf);
}

// Генерация визуального прогресс-бара для плеера
inline std::string progress_bar(long long current, long long total, int bar_width = 10) {
    if (total <= 0) total = 1;
    if (current < 0) current = 0;
    if (current > total) current = total;

    double progress = static_cast<double>(current) / static_cast<double>(total);
    int pos = static_cast<int>(progress * bar_width);
    if (pos >= bar_width) pos = bar_width - 1;

    std::string bar = "";
    for (int i = 0; i < bar_width; ++i) {
        if (i == pos) {
            bar += "🔘";
        } else {
            bar += "─";
        }
    }
    return bar;
}

// Разделение строки по разделителю
inline std::vector<std::string> split(const std::string& s, char delim) {
    std::vector<std::string> elems;
    std::stringstream ss(s);
    std::string item;
    while (std::getline(ss, item, delim)) {
        elems.push_back(item);
    }
    return elems;
}

// Хелперы для работы с локальной базой данных модуля
inline std::string db_get_str(const koto_api* api, koto_ctx* ctx, const std::string& key, const std::string& def = "") {
    if (!api || !api->db_get) return def;
    char buf[2048] = {0};
    int len = api->db_get(ctx, key.c_str(), buf, sizeof(buf) - 1);
    if (len > 0) {
        buf[len] = '\0';
        return std::string(buf);
    }
    return def;
}

inline void db_set_str(const koto_api* api, koto_ctx* ctx, const std::string& key, const std::string& val) {
    if (api && api->db_set) {
        api->db_set(ctx, key.c_str(), val.c_str());
    }
}

inline long long db_get_int64(const koto_api* api, koto_ctx* ctx, const std::string& key, long long def = 0) {
    if (!api || !api->db_get_int) return def;
    return api->db_get_int(ctx, key.c_str(), def);
}

inline void db_set_int64(const koto_api* api, koto_ctx* ctx, const std::string& key, long long val) {
    if (api && api->db_set_int) {
        api->db_set_int(ctx, key.c_str(), val);
    }
}

// Хелперы для работы с настройками (.cfg)
inline std::string cfg_get_str(const koto_api* api, koto_ctx* ctx, const std::string& key, const std::string& def = "") {
    if (!api || !api->cfg_get) return def;
    char buf[512] = {0};
    int len = api->cfg_get(ctx, key.c_str(), buf, sizeof(buf) - 1);
    if (len > 0) {
        buf[len] = '\0';
        return std::string(buf);
    }
    return def;
}

inline std::string mod_get_setting(const koto_api* api, koto_ctx* ctx, const std::string& key, const std::string& def = "") {
    if (api && api->cfg_get) {
        char buf[512] = {0};
        int len = api->cfg_get(ctx, key.c_str(), buf, sizeof(buf) - 1);
        if (len > 0) return std::string(buf, len);
    }
    return def;
}

inline long long mod_get_setting_int(const koto_api* api, koto_ctx* ctx, const std::string& key, long long def = 0) {
    std::string s = mod_get_setting(api, ctx, key, "");
    if (s.empty()) return def;
    try {
        return std::stoll(s);
    } catch (...) {
        return def;
    }
}

} // namespace koto_utils

#endif // KOTO_UTILS_HPP
