# 🐱 Полное руководство по разработке Lua-модулей для Kotogram (v0.4.20, ABI 3)

Скриптовые Lua-модули (`.lua`) позволяют быстро и без необходимости компиляции расширять возможности юзербота **Kotogram / KoteLoader**. Вы просто создаёте `.lua` файл в текстовом редакторе и устанавливаете его в приложение — через чат Telegram, через плавающее меню HUD или файловый проводник.

---

## 📑 Оглавление
1. [Базовая структура модуля](#1-базовая-структура-модуля)
2. [Объект сообщения `msg` и `msg.reply`](#2-объект-сообщения-msg-и-msgreply)
3. [Форматирование текста: Markdown и HTML](#3-форматирование-текста-markdown-и-html)
   - [Поддерживаемый Markdown](#поддерживаемый-markdown)
   - [Кастомные анимированные эмодзи Telegram](#кастомные-анимированные-эмодзи-telegram)
   - [Цитаты и сворачиваемые цитаты](#цитаты-и-сворачиваемые-цитаты)
   - [HTML-разметка](#html-разметка)
   - [Декодирование Unicode-эскейпов (`\uXXXX`)](#декодирование-unicode-эскейпов-uxxxx)
4. [Методы объекта `msg`](#4-методы-объекта-msg)
5. [Инлайн-кнопки (Inline Buttons) и Баннеры](#5-инлайн-кнопки-inline-buttons-и-баннеры)
6. [Обработка нажатий на кнопки (`on_callback`)](#6-обработка-нажатий-на-кнопки-on_callback)
7. [Настройки модуля (`settings`) и интерактивное меню `.cfg`](#7-настройки-модуля-settings-и-интерактивное-меню-cfg)
8. [Глобальный API `koto.*`](#8-глобальный-api-koto)
9. [База данных `koto.db.*`](#9-база-данных-kotodb)
10. [Сеть, скачивание файлов и медиаплеер](#10-сеть-скачивание-файлов-и-медиаплеер)
11. [Контроль версий (`min_host_version`)](#11-контроль-версий-min_host_version)
12. [Способы установки и управление модулями](#12-способы-установки-и-управление-модулями)
13. [Практические примеры модулей](#13-практические-примеры-модулей)
    - [Пример 1: TikTok / Media Карточка](#пример-1-tiktok--media-карточка)
    - [Пример 2: Модерация и быстрые действия](#пример-2-модерация-и-быстрые-действия)
    - [Пример 3: Заметки с постоянной БД SQLite](#пример-3-заметки-с-постоянной-бд-sqlite)
    - [Пример 4: Скачивание и отправка видео в плеер Telegram](#пример-4-скачивание-и-отправка-видео-в-плеер-telegram)
    - [Пример 5: Интерактивное меню с кнопками и настройками (.cfg)](#пример-5-интерактивное-меню-с-кнопками-и-настройками-cfg)

---

## 1. Базовая структура модуля

Каждый `.lua` файл выполняется в изолированном контексте (отдельный Lua State) и может объявлять:
- **Метаданные**: `name`, `description`, `version`, `author`, `min_host_version`.
- **Таблицу команд `commands`**: регистрирует команды для меню `.help`, списка модулей и плавающего HUD.
- **Главный перехватчик `on_message(msg)`**: вызывается при получении/отправке сообщения.
- Либо специализированные функции команд вида `cmd_<имя>(msg, args)`.

```lua
name = "my_tool"
description = "Полезный набор команд для работы с текстом"
version = "1.0.0"
author = "Kotogram Dev"
min_host_version = 12 -- Требует Kotogram 0.2.2+ (versionCode 12) или новее
update_url = "https://github.com/username/my_repo" -- Ссылка на Git/GitHub для отслеживания и загрузки обновлений

-- Регистрация команд для справки (.help) и отображения в UI
commands = {
    test = { doc = "Проверка работы модуля", usage = "" },
    shout = { doc = "Отправить текст заглавными буквами", usage = "<текст>" }
}

function on_message(msg)
    -- Обрабатываем только исходящие сообщения от нашего аккаунта
    if not msg.out then return end

    local text = msg.text or ""

    if text == ".test" then
        msg:edit("🎉 **Модуль активен и готов к работе!**")
        return
    end

    if text:sub(1, 7) == ".shout " then
        local arg = text:sub(8)
        msg:edit("🗣 **" .. arg:upper() .. "**")
        return
    end
end
```

---

## 2. Объект сообщения `msg` и `msg.reply`

В функцию `on_message(msg)` передаётся таблица с полями текущего события:
- `msg.id` *(integer)* — уникальный ID сообщения в текущем чате.
- `msg.text` *(string)* — текст сообщения (включая префикс).
- `msg.chat_id` *(integer)* — ID чата (группа, супергруппа, канал или ЛС).
- `msg.sender_id` *(integer)* — ID автора сообщения.
- `msg.reply_to_msg_id` *(integer)* — ID сообщения, на которое сделан ответ (или `0`, если реплая нет).
- `msg.out` *(boolean)* — `true`, если сообщение отправлено вашим аккаунтом; `false`, если пришло от собеседника.

### Поле `msg.reply` (Информация об исходном сообщении)
Если сообщение является ответом (reply) на другое сообщение, поле `msg.reply` содержит полную копию исходного сообщения:
- `msg.reply.id` — ID исходного сообщения.
- `msg.reply.text` — текст исходного сообщения.
- `msg.reply.sender_id` — ID автора исходного сообщения.
- `msg.reply.chat_id` — ID чата.
- `msg.reply.out` — наше ли это исходное сообщение.

```lua
if msg.text == ".who" and msg.reply then
    msg:edit("👤 Автор исходного сообщения: `" .. msg.reply.sender_id .. "`")
end
```

---

## 3. Форматирование текста: Markdown и HTML

Все функции отправки и редактирования (`koto.reply`, `koto.edit`, `koto.send`, `msg:reply`, `msg:edit`, `koto.send_file`) **по умолчанию обрабатывают текст как Markdown** с автоматическим формированием нативных сущностей MTProto Telegram (MessageEntity).

### Поддерживаемый Markdown:
| Синтаксис | Результат в Telegram |
| :--- | :--- |
| `**жирный текст**` | **жирный текст** |
| `__курсив__` | *курсив* |
| `~~зачёркнутый~~` | ~~зачёркнутый~~ |
| `||спойлер||` | скрытый спойлер |
| `` `моноширинный код` `` | `код` |
| ```` ```python\nprint('hello')\n``` ```` | блок кода с указанием языка |
| `> цитата` | блок цитаты Telegram |
| `**> сворачиваемая цитата` | сворачиваемый блок цитаты (Expandable Quote) |
| `[Название ссылки](https://example.com)` | кликабельная ссылка |
| `[**[Жирная ссылка]**](https://example.com)` | ссылка с жирным начертанием |
| `[эмодзи](tg://emoji?id=ID)` | кастомный анимированный эмодзи Telegram Premium |

### Кастомные анимированные эмодзи Telegram
Пользователи с Telegram Premium могут отправлять анимированные эмодзи по их `document_id`. В Lua их можно использовать прямо внутри текста:
```lua
local em_star = "[⭐](tg://emoji?id=5406726206101919864)"
local em_fire = "[🔥](tg://emoji?id=5370697920704159828)"

msg:reply(em_fire .. " **Успешно!** " .. em_star .. "\n> Задача выполнена.")
```

### Цитаты и сворачиваемые цитаты
- Начните строку с `> ` для создания стандартной цитаты:
  ```lua
  msg:reply("> Это обычная цитата Telegram\n> Вторая строка цитаты\nОбычный текст.")
  ```
- Начните строку с `**> ` для создания **сворачиваемой (expandable)** цитаты:
  ```lua
  msg:reply("**> Длинный текст, который Telegram спрячет под кнопку разворачивания.")
  ```

### HTML-разметка
Если вам привычнее формировать HTML, передайте `"html"` вторым параметром или используйте `koto.reply_html` / `koto.edit_html`:
```lua
koto.reply_html("<b>Жирный</b>, <i>курсив</i>, <code>код</code>, <tg-emoji emoji-id='5370697920704159828'>🎬</tg-emoji>")
```

### Декодирование Unicode-эскейпов (`\uXXXX`)
Внешние HTTP REST API часто возвращают JSON со строками вида `\u043f\u0440\u0438\u0432\u0435\u0442`. Движок Kotogram **автоматически декодирует** такие последовательности (включая суррогатные пары для эмодзи) при форматировании. Также доступен прямой вызов:
```lua
local clean_str = koto.unescape("Текст: \u043f\u0440\u0438\u0432\u0435\u0442")
-- вернёт: "Текст: привет"
```

---

## 4. Методы объекта `msg`

Объект `msg` предоставляет объектно-ориентированные методы для удобного управления сообщением:
- `msg:reply("текст", [mode])` — отправить ответ в чат на текущее сообщение (mode: `"md"` (по умолчанию), `"html"`, `"plain"`).
- `msg:edit("текст", [mode])` — отредактировать текущее сообщение команды.
- `msg:delete()` — удалить текущее сообщение команды.
- `msg:react("🔥")` — поставить реакцию эмодзи (например: `"👍"`, `"❤️"`, `"🔥"`, `"🎉"`).
- `msg:react_custom(document_id)` — поставить кастомную эмодзи-реакцию.
- `msg:copy()` — сохранить текущее сообщение в «Избранное» (даже если чат защищён от пересылки).
- `msg:reply_file("путь/к/файлу", [подпись], [mode])` — отправить файл в ответ на сообщение.
- `msg:download(url, [target_path])` — скачать файл по ссылке в локальный кэш.
- `msg:http_get(url)` — выполнить HTTP GET запрос и вернуть текстовый ответ.
- `msg:http_post(url, body, [headers])` — выполнить HTTP POST запрос (body: string/таблица, headers: string/таблица).
- `msg:user_name([uid])` — имя пользователя (по умолчанию: автора сообщения).
- `msg:user_first_name([uid])` — имя (first_name) пользователя (v0.3.6 Hotfix 4).
- `msg:user_last_name([uid])` — фамилия (last_name) пользователя (v0.3.6 Hotfix 4).
- `msg:user_username([uid])` — @username пользователя без собаки (v0.3.6 Hotfix 4).
- `msg:user_full([uid])` — полный профиль в JSON: био, канал, подарки, др, музыка, истории (v0.3.6 Hotfix 4).
- `msg:chat_full([cid])` — полная информация о чате/канале в JSON (v0.3.6 Hotfix 4).

---

## 5. Инлайн-кнопки (Inline Buttons) и Баннеры

Модули Kotogram поддерживают полноценные интерактивные inline-кнопки Telegram, которые отправляются через встроенного бота-помощника и не требуют ручной настройки токенов.

### Добавление кнопок к сообщению

Вы можете прикрепить одну или несколько кнопок к сообщениям `msg:reply(...)`, `msg:edit(...)`, `msg:send(...)` или глобальным `koto.reply(...)` / `koto.edit(...)`:

```lua
-- msg:button(text, callback_data, [new_row = false], [color = 0], [icon = 0])
msg:button("👍 Лайк", "like")
msg:button("👎 Дизлайк", "dislike")
msg:button("⚙️ Настройки", "open_cfg", true) -- new_row = true начинает новую строку кнопок
msg:reply("Выберите действие:")
```

Или в виде цепочки (chaining):
```lua
msg:button("Да", "yes"):button("Нет", "no"):reply("Вы согласны?")
```

### Пакетное добавление кнопок (`msg:buttons`)

```lua
-- Список кнопок в одной сетке
msg:buttons({
    { text = "Кнопка 1", data = "b1" },
    { text = "Кнопка 2", data = "b2" },
    { text = "Новая строка", data = "b3", new_row = true }
})

-- Или вложенные массивы (строки):
msg:buttons({
    { { text = "A", data = "a" }, { text = "B", data = "b" } },
    { { text = "C", data = "c" }, { text = "D", data = "d" } }
})
```

### Цвета кнопок (KOTO_BTN_*)
- `koto.BTN_DEFAULT` (`0`) — обычная кнопка.
- `koto.BTN_PRIMARY` (`1`) — акцентная / синяя.
- `koto.BTN_SUCCESS` (`2`) — зелёная.
- `koto.BTN_DANGER`  (`3`) — красная.

```lua
msg:button("🗑️ Удалить всё", "wipe_all", true, koto.BTN_DANGER)
```

### Баннер-картинка (`msg:banner`)
Прикрепляет медиа-превью карточки сверху:
```lua
msg:banner("https://example.com/cover.jpg")
msg:button("Слушать", "play_audio")
msg:reply("🎵 **Трек дня**")
```

---

## 6. Обработка нажатий на кнопки (`on_callback`)

Когда пользователь или собеседник нажимает на инлайн-кнопку, движок вызывает функцию:

```lua
function on_callback(cb)
    -- Обработка нажатия
end
```

### Поля объекта `cb`
- `cb.data` *(string)* — строка `callback_data`, переданная при создании кнопки.
- `cb.message_id` / `cb.msg_id` *(integer)* — ID сообщения, на котором расположена кнопка.
- `cb.chat_id` *(integer)* — ID чата.
- `cb.sender_id` / `cb.user_id` *(integer)* — ID пользователя, нажавшего на кнопку.
- `cb.out` *(boolean)* — `true`, если исходное сообщение было исходящим.

### Методы объекта `cb`
- `cb:answer(text, [show_alert])` — ответить на клик:
  - `show_alert = false` (по умолчанию) — небольшая всплывающая подсказка внизу (toast).
  - `show_alert = true` — модальное диалоговое окно с кнопкой «ОК».
- `cb:edit(new_text, [mode])` — мгновенно обновить текст сообщения, к которому прикреплена кнопка. Если перед `cb:edit` вызвать `cb:button(...)`, кнопки сообщения также обновятся!
- `cb:edit_html(new_text)` — обновить с разметкой HTML.
- `cb:edit_md(new_text)` — обновить с Markdown.
- `cb:button(text, data, [new_row], [color], [icon])` — прикрепить новую кнопку для обновляемого сообщения.
- `cb:buttons(table)` — обновить сетку кнопок.
- `cb:banner(url)` — обновить баннер.
- `cb:delete()` — удалить сообщение с кнопкой.
- `cb:reply(text, [mode])` — отправить ответ в чат от вашего аккаунта юзербота.
- `cb:config(key, [default])` — прочитать настройку модуля.

### Пример обработки кликов

```lua
function on_callback(cb)
    if cb.data == "ping" then
        cb:answer("Понг! 🏓")
        cb:button("Снова", "ping"):edit("🏓 **Сыграно раундов: 1**")
        return
    end

    if cb.data == "warn_alert" then
        cb:answer("⚠️ Внимание! Это системное предупреждение.", true) -- модальное окно!
        return
    end

    if cb.data == "close" then
        cb:answer("Закрыто")
        cb:delete()
        return
    end
end
```

---

## 7. Настройки модуля (`settings`) и интерактивное меню `.cfg`

Kotogram предоставляет удобную встроенную панель настроек для каждого модуля. При вводе команды `.cfg` (или через настройки в приложении) пользователю открывается интерактивное inline-меню с кнопками-тумблерами, переключателями и выбором режимов.

### Декларация настроек в Lua-скрипте

Объявите глобальную таблицу `settings` в начале вашего скрипта:

```lua
-- Способ 1: Массив полей (сохраняет точный порядок кнопок в меню .cfg)
settings = {
    { key = "auto_reply", label = "Автоответчик",    type = "bool",   default = "true" },
    { key = "delay",      label = "Задержка (сек)",   type = "int",    default = "5" },
    { key = "factor",     label = "Множитель",        type = "float",  default = "1.5" },
    { key = "sign",       label = "Подпись",          type = "str",    default = "— КотЭ" },
    { key = "mode",       label = "Режим работы",     type = "choice", default = "normal", choices = "fast,normal,silent" }
}

-- Способ 2: Таблица по ключам (также полностью поддерживается)
-- settings = {
--     auto_reply = { label = "Автоответчик", type = "bool", default = "true" },
--     delay      = { label = "Задержка", type = "int", default = "5" }
-- }
```

### Поддерживаемые типы полей:
| Тип | Значения `type` | Поведение в меню `.cfg` |
|---|---|---|
| Логический | `"bool"` / `koto.FIELD_BOOL` | Интерактивный тумблер `✅ Вкл` / `❌ Выкл` |
| Числовой (целый) | `"int"` / `koto.FIELD_INT` | Кнопки пошагового изменения `-` и `+` |
| С плавающей точкой | `"float"` / `koto.FIELD_FLOAT` | Шаговый регулятор значений |
| Строка | `"str"` / `koto.FIELD_STR` | Отображение строки и возможность редактирования |
| Выбор из списка | `"choice"` / `koto.FIELD_CHOICE` | Циклическое переключение вариантов по клику (`[fast] ➔ [normal] ➔ [silent]`) |

### Доступ к настройкам из кода модуля (`koto.config.*`)

Значения настроек хранятся в постоянной базе данных SQLite и обновляются прямо в реальном времени при кликах по кнопкам в меню `.cfg`.

```lua
-- Чтение значений (с дефолтными значениями, если еще не настроено в .cfg):
local is_on  = koto.config.get_bool("auto_reply", true)
local delay  = koto.config.get_int("delay", 5)
local mode   = koto.config.get("mode", "normal")

-- Запись новых значений из кода:
koto.config.set_bool("auto_reply", false)
koto.config.set_int("delay", 10)
koto.config.set("mode", "fast")

-- Получить таблицу всех настроек сразу:
local all_cfg = koto.config.all() -- { auto_reply = "1", delay = "10", ... }

-- Быстрый синтаксис через обращение к свойствам:
local current_mode = koto.config.mode
koto.config.mode = "silent"

-- Чтение прямо из объекта сообщения или колбэка:
if msg:config("auto_reply") == "1" then
    -- ...
end
```

---

## 8. Глобальный API `koto.*`

Таблица `koto` доступна глобально в любом месте скрипта:

```lua
-- Отправка и редактирование сообщений
koto.reply(text, [mode])          -- Ответить на команду (дефолт: "md")
koto.reply_html(text)             -- Ответить на команду с HTML
koto.reply_md(text)               -- Ответить на команду с Markdown
koto.edit(text, [mode])           -- Отредактировать сообщение (дефолт: "md")
koto.edit_html(text)              -- Отредактировать сообщение с HTML
koto.send(chat_id, text, [mode])  -- Отправить сообщение в любой чат
koto.respond(text, [mode])        -- Отправить сообщение в текущий чат без reply

-- Удаление и пересылка
koto.delete()                     -- Удалить сообщение команды
koto.delete_msg(msg_id)           -- Удалить сообщение по ID в текущем чате
koto.delete_msg(chat_id, msg_id)  -- Удалить сообщение в указанном чате
koto.copy(msg_id)                 -- Скопировать сообщение в «Избранное»

-- Реакции
koto.react("❤️")                  -- Реакция обычным эмодзи
koto.react_custom(5370697920704159828) -- Реакция кастомным эмодзи по Document ID

-- Отправка медиафайлов
koto.send_file(chat_id, path, [caption], [mode])
koto.reply_file(path, [caption], [mode])

-- Скачивание и сеть
koto.download(url, [path])        -- Потоковое скачивание файла на диск (возвращает путь)
koto.http_get(url)                -- HTTP GET запрос (возвращает тело ответа как string)
koto.http_post(url, body, [hdr])  -- HTTP POST запрос с поддержкой кастомных заголовков (Authorization и др.)
koto.cache_dir()                  -- Путь к изолированной папке кэша приложения

-- Пользователи и чаты (v0.3.6 Hotfix 4 / Section 27)
koto.user_name([uid])             -- Отображаемое имя пользователя
koto.user_first_name([uid])       -- Имя (first_name)
koto.user_last_name([uid])        -- Фамилия (last_name)
koto.user_username([uid])         -- Публичный ник (username)
koto.user_full([uid])             -- Полный профиль в JSON (био, подарки, др, музыка, истории)
koto.chat_full([cid])             -- Полная информация о чате/канале в JSON

-- Утилиты
koto.unescape(text)               -- Декодировать \uXXXX эскейпы
koto.log(text)                    -- Записать строку в лог приложения Kotogram
```

---

## 9. База данных `koto.db.*`

Каждый скрипт получает личное изолированное SQLite-хранилище в постоянной базе данных приложения (`koto.db`). Данные надёжно сохраняются между перезапусками приложения:

```lua
-- Строковые значения
koto.db.set("username", "Kotik")
local name = koto.db.get("username") -- вернёт "Kotik" или nil, если ключа нет

-- Целочисленные значения
koto.db.set_int("counter", 42)
local count = koto.db.get_int("counter", 0) -- вернёт 42 (дефолтное значение: 0)

-- Удаление ключа
koto.db.del("username")

-- Получение списка всех сохранённых ключей модуля
local all_keys = koto.db.keys() -- массив строк: { "counter", ... }

-- Полная очистка БД текущего модуля
koto.db.clear()
```

---

## 10. Сеть, скачивание файлов и медиаплеер

Движок Kotogram содержит встроенный высокопроизводительный сетевой загрузчик и автоматический парсер медиа:

### Автоматический видеоплеер Telegram
Если вы отправляете видеофайл с расширениями `.mp4`, `.mov` или `.webm` через `msg:reply_file(path)` или `koto.send_file(chat_id, path)`:
1. Хост автоматически извлекает метаданные: длительность, разрешение (ширина/высота) и превью-кадр.
2. Файл отправляется с флагом `supports_streaming = true`.
3. В Telegram получатель видит **нативный плеер с превью и возможностью перемотки**, а не просто документ!

```lua
-- Пример загрузки и отправки видео:
local path = koto.download("https://example.com/video.mp4")
if path then
    msg:reply_file(path, "🎬 **Ваше видео готово к просмотру!**")
    os.remove(path) -- удаляем временный файл после отправки
end
```

---

## 11. Контроль версий (`min_host_version`)

Начиная с Kotogram 0.1.1, в ядре реализован строгий контроль совместимости модулей.

Если ваш модуль использует возможности новых версий Kotogram (например, расширенное форматирование, плавающий HUD, новые методы API), укажите минимальную версию хоста:

```lua
min_host_version = 2 -- целое число (versionCode APK)
```

### Таблица версий Kotogram:
| Версия Kotogram | `versionCode` | Значение `min_host_version` | Особенности |
| :--- | :---: | :---: | :--- |
| **0.1.0** | `1` | `1` | Базовый релиз, C++ ядро, Telegram MTProto |
| **0.1.1** | `2` | `2` | Плавающий HUD, кастомный ввод без обрезки, автобэкап сессий и модулей, потоковое видео |
| **0.2.0** | `10` | `10` | Встроенный репозиторий модулей KoteModules, C/C++ нативный ABI 3 |
| **0.2.1** | `11` | `11` | Поддержка сторонних инлайн-ботов (`@lybot`, `@vkmusic_bot`), C++20 STL |
| **0.2.2** | `12` | `12` | Прямое скачивание аудио с YouTube в Telegram-плеер, системный кэш |
| **0.2.3** | `13` | `13` | Поддержка FakeTLS ee-прокси (SNI domain fronting для обхода DPI) и dd-секретов |
| **0.2.4** | `14` | `14` | Автоматическая очистка статусных сообщений при инлайн-отправке, нативный C++ Role-Play |
| **0.2.5** | `15` | `15` | Кэш сохранённой музыки, оптимизация потребления памяти |
| **0.2.6** | `16` | `16` | Фоновый запуск без интернета, горячее переключение прокси, автореконнект |
| **0.2.7** | `17` | `17` | Полная поддержка ссылок и разметки в подписях к медиа, нативная отправка файлов с инлайн-кнопками via @bot, автообнаружение отозванной сессии Telegram |

### Что происходит при несовместимости:
Если пользователь попытается установить модуль с `min_host_version = 2` на старую версию Kotogram (0.1.0):
1. Хост заблокирует установку и удалит временный файл.
2. Приложение покажет понятное уведомление:  
   > ❌ *Модуль 'my_module' требует версию Kotogram 2 или выше! Пожалуйста, обновите приложение.*

---

## 12. Способы установки и управление модулями

### Способ 1: Установка через чат Telegram (самый удобный)
1. Отправьте файл `.lua` документом в любой чат (например, в свои **«Избранные»** / Saved Messages).
2. Ответьте на это сообщение командой:
   ```
   .install
   ```
3. Модуль мгновенно компилируется в байткод и загружается в память. Проверьте его наличие командой `.m` или `.modules`.

### Способ 2: Установка через плавающий HUD или экран приложения
1. Откройте плавающий HUD (иконка котика на экране) или само приложение Kotogram.
2. Перейдите во вкладку **«Модули»**.
3. Нажмите кнопку **«Установить модуль»** и выберите `.lua` файл в проводнике Android.

### Способ 3: Автоматический бэкап при переустановке
Все установленные пользовательские модули автоматически синхронизируются в директорию:
```
/sdcard/Download/KoteLoader_Backup/modules/
```
При удалении приложения и повторной установке APK все ваши модули и сессия восстанавливаются автоматически!

### Управление модулями в реальном времени:
- `.m` или `.modules` — полный список установленных модулей.
- `.delm <имя>` — удалить пользовательский модуль.
- В плавающем HUD модули можно включать и отключать простым переключателем без перезагрузки.

### Обновление модулей и просмотр списка изменений (Changelog):

#### 1. Системные модули ядра
Системные модули (такие как `about`, `admin`, `help`, `ping` и др.) вкомпилированы непосредственно в нативную библиотеку C++ ядра (`libkotocore.so`):
- Они обновляются централизованно вместе с ядром Kotogram через онлайн-обновления.
- Чтобы проверить наличие обновлений и прочитать историю версий:
  1. Во вкладке **«Модули»** нажмите кнопку **«Обновления»** в верхней панели (или откройте системный модуль в списке и нажмите **«Проверить обновление ядра / Changelog»**).
  2. Откроется окно со статусом и полным **списком изменений (Changelog)**.
  3. При наличии новой версии нажмите **«Обновить всё»** — скачивание и установка происходят бесшовно с полным сохранением авторизации Telegram, всех настроек и пользовательских файлов.

#### 2. Пользовательские модули (`.lua` и `.so`)
Пользовательские модули поддерживают несколько удобных способов установки и мгновенного горячего обновления без перезапуска приложения:

##### А. Автоматическое отслеживание и обновление с Git / GitHub
Теперь модули умеют напрямую отслеживать обновления в репозиториях:
1. **Параметр `update_url` в коде модуля**:
   В начале `.lua` файла задайте глобальную переменную:
   ```lua
   update_url = "https://github.com/username/my_repo"
   -- также поддерживаются синонимы: git_url = "..." или repo = "..."
   ```
   **Поддерживаемые форматы ссылок:**
   - Ссылка на репозиторий GitHub: `https://github.com/owner/repo` (движок автоматически ищет `<module_name>.lua` в ветках `main` и `master`).
   - Ссылка на страницу файла на GitHub: `https://github.com/owner/repo/blob/main/my_tool.lua` (автоматически преобразуется в raw URL).
   - Прямая ссылка raw: `https://raw.githubusercontent.com/owner/repo/main/my_tool.lua`.
   - Короткий формат: `owner/repo`.
   - Любая прямая HTTPS-ссылка на файл.

2. **Ручная привязка Git в приложении (для скачанных файлов)**:
   Если вы скачали модуль файлом на телефон или через Telegram, а автор не указал `update_url` в коде (или вы используете свой форк):
   - Откройте карточку модуля во вкладке **«Модули»**.
   - В блоке **«Синхронизация с Git / GitHub»** нажмите кнопку **«Указать Git»** (или **«Изменить»**).
   - Введите ссылку на репозиторий или файл и нажмите **«Сохранить»**.

3. **Обновление в 1 клик**:
   - Нажмите **«Обновить из Git»**.
   - Kotogram подключится к сети (используя встроенный SOCKS5-прокси, если GitHub заблокирован у вашего провайдера).
   - Автоматически считает и сопоставит версию модуля (`version`).
   - Проверит совместимость с версией приложения (`min_host_version`).
   - Покажет всплывающее окно с информацией о найденном обновлении.
   - При подтверждении файл моментально скачивается, валидируется, перезагружается в памяти и сохраняется в бэкап!

##### Б. Обновление из локального файла
- Откройте нужный модуль во вкладке **«Модули»** и нажмите **«Обновить модуль из файла»**.
- Выберите обновлённый `.lua` или `.so` файл. Движок валидирует зависимости (`min_host_version`), заменяет файл и моментально перезагружает модуль.

##### В. Обновление через чат Telegram
- Отправьте обновлённый файл в любой чат/Избранное и ответьте на него командой `.install`.

Все установленные и обновлённые модули автоматически синхронизируются в директорию резервного копирования `/sdcard/Download/KoteLoader_Backup/modules/`.

---

## 13. Практические примеры модулей

### Пример 1: TikTok / Media Карточка
Демонстрация красивой карточки с кастомными эмодзи, цитатами, жирным текстом и ссылками:

```lua
name = "tiktok_demo"
description = "Демонстрация медиа-карточки"
version = "1.0.0"
min_host_version = 2

commands = {
    tt = { doc = "Показать демо карточки видео", usage = "" }
}

function on_message(msg)
    if not msg.out then return end

    if msg.text == ".tt" then
        local emoji_clip = "[🎬](tg://emoji?id=5370697920704159828)"
        local emoji_down = "[📥](tg://emoji?id=5406726206101919864)"

        local text = emoji_clip .. " **TikTok Video:**\n" ..
                     "> #fyp #cars #drift пов: черт был наказан за кадром!\n" ..
                     "• **Автор:** `auto_guru`\n" ..
                     "> • **Длительность:** `38 сек.`\n\n" ..
                     emoji_down .. " [**[Скачать MP4 без водяного знака]**](https://example.com/video.mp4)\n" ..
                     "> __Kotogram Engine__"

        msg:edit(text)
    end
end
```

---

### Пример 2: Модерация и быстрые действия
Быстрые команды через реплай: удаление спама, копирование защищённых постов и реакции:

```lua
name = "mod_quick"
description = "Быстрая модерация в чатах"
version = "1.0.0"
min_host_version = 2

commands = {
    del = { doc = "Удалить сообщение по реплаю", usage = "" },
    save = { doc = "Сохранить сообщение в Избранное", usage = "" },
    like = { doc = "Поставить реакцию на сообщение", usage = "" }
}

function on_message(msg)
    if not msg.out then return end

    -- Удалить сообщение, на которое ответили, и саму команду
    if msg.text == ".del" and msg.reply then
        koto.delete_msg(msg.chat_id, msg.reply.id)
        msg:delete()
        return
    end

    -- Сохранить даже защищённый от пересылки пост в Избранное
    if msg.text == ".save" and msg.reply then
        koto.copy(msg.reply.id)
        msg:edit("💾 **Сохранено в Избранное!**")
        return
    end

    -- Быстрая реакция
    if msg.text == ".like" and msg.reply then
        koto.react("🔥")
        msg:delete()
        return
    end
end
```

---

### Пример 3: Заметки с постоянной БД SQLite
Сохранение и чтение личных заметок прямо из чата:

```lua
name = "quick_notes"
description = "Быстрые заметки в базе данных"
version = "1.0.0"
min_host_version = 2

commands = {
    note = { doc = "Сохранить заметку: .note <ключ> <текст>", usage = "<ключ> <текст>" },
    get = { doc = "Получить заметку: .get <ключ>", usage = "<ключ>" },
    notes = { doc = "Список всех заметок", usage = "" }
}

function on_message(msg)
    if not msg.out then return end
    local text = msg.text or ""

    if text:sub(1, 6) == ".note " then
        local key, val = text:sub(7):match("^(%S+)%s+(.+)$")
        if not key or not val then
            msg:edit("⚠️ **Использование:** `.note <ключ> <текст>`")
            return
        end
        koto.db.set(key, val)
        msg:edit("✅ Заметка **" .. key .. "** успешно сохранена!")
        return
    end

    if text:sub(1, 5) == ".get " then
        local key = text:sub(6):match("^%s*(%S+)%s*$")
        local val = koto.db.get(key)
        if val then
            msg:edit("📝 **Заметка [" .. key .. "]:**\n> " .. val)
        else
            msg:edit("❌ Заметка **" .. key .. "** не найдена.")
        end
        return
    end

    if text == ".notes" then
        local keys = koto.db.keys()
        if #keys == 0 then
            msg:edit("ℹ️ У вас пока нет сохранённых заметок.")
            return
        end
        local list = "📚 **Ваши сохранённые заметки:**\n"
        for _, k in ipairs(keys) do
            list = list .. "• `" .. k .. "`\n"
        end
        msg:edit(list)
        return
    end
end
```

---

### Пример 4: Скачивание и отправка видео в плеер Telegram
Скачивание ролика по прямой ссылке с потоковой отправкой в Telegram:

```lua
name = "video_downloader"
description = "Скачивание видео по ссылке и отправка в плеер Telegram"
version = "1.0.0"
min_host_version = 2

commands = {
    dl = { doc = "Скачать видео по ссылке: .dl <url>", usage = "<url>" }
}

function on_message(msg)
    if not msg.out then return end
    local text = msg.text or ""

    if text:sub(1, 4) == ".dl " then
        local url = text:sub(5):match("^%s*(%S+)%s*$")
        if not url then
            msg:edit("⚠️ **Укажите ссылку на видео:** `.dl <url>`")
            return
        end

        msg:edit("⏳ **Скачиваю видео...**\n> " .. url)

        -- 1. Скачиваем файл потоком на диск устройства
        local path = koto.download(url)
        if not path then
            msg:edit("❌ **Ошибка скачивания:** не удалось загрузить видео.")
            return
        end

        msg:edit("📤 **Отправляю в Telegram плеер...**")

        -- 2. Отправляем в чат. Для .mp4 хост автоматически настраивает видеоплеер!
        msg:reply_file(path, "🎬 **Видео успешно скачано!**\n> Источник: " .. url)

        -- 3. Удаляем локальный файл и служебное сообщение
        os.remove(path)
        msg:delete()
        return
    end
end
```

---

### Пример 5: Получение расширенного профиля пользователя и чата (v0.3.6 Hotfix 4)
Чтение имени, юзернейма, био, подарков и других метаданных через Section 27 ABI:

```lua
name = "userinfo"
description = "Информация о пользователях и чатах"
version = "1.0.0"
min_host_version = 26

commands = {
    whois = { doc = "Получить информацию о пользователе", usage = "[reply/@username/id]" },
    chat = { doc = "Получить информацию о текущем чате", usage = "" }
}

function on_message(msg)
    if not msg.out then return end
    local text = msg.text or ""

    if text:sub(1, 6) == ".whois" or text:sub(1, 5) == ".user" then
        local target_uid = 0
        if msg.reply and msg.reply.sender_id and msg.reply.sender_id ~= 0 then
            target_uid = msg.reply.sender_id
        end

        local first = msg:user_first_name(target_uid)
        local last = msg:user_last_name(target_uid)
        local uname = msg:user_username(target_uid)
        local full_json = msg:user_full(target_uid)

        local out = "👤 **Профиль пользователя:**\n"
        out = out .. "• **Имя:** " .. (first ~= "" and first or "—") .. "\n"
        if last ~= "" then
            out = out .. "• **Фамилия:** " .. last .. "\n"
        end
        if uname ~= "" then
            out = out .. "• **Юзернейм:** @" .. uname .. "\n"
        end
        if full_json and full_json ~= "{}" then
            out = out .. "\n📄 **Расширенный профиль (JSON):**\n```json\n" .. full_json .. "\n```"
        end
        msg:edit(out)
        return
    end

    if text:sub(1, 5) == ".chat" then
        local full_json = msg:chat_full()
        local out = "💬 **Информация о чате (JSON):**\n```json\n" .. full_json .. "\n```"
        msg:edit(out)
        return
    end
end
```


---

### Пример 5: Интерактивное меню с кнопками и настройками (.cfg)

Готовый модуль демонстрирует объявление настроек для меню `.cfg`, генерацию кнопок и обработку кликов с всплывающими окнами (alert):

```lua
name = "interactive_menu"
description = "Интерактивное меню с инлайн-кнопками и меню настроек"
version = "1.0.0"
min_host_version = 114

settings = {
    { key = "notify_alert", label = "Модальные окна", type = "bool", default = "true" },
    { key = "difficulty",   label = "Сложность игры",  type = "choice", default = "normal", choices = "easy,normal,hard" }
}

commands = {
    menu = { doc = "Открыть интерактивное меню", usage = "" }
}

function cmd_menu(msg, args)
    msg:button("🎲 Бросить кубик", "roll")
    msg:button("🔔 Оповещение", "alert")
    msg:button("❌ Закрыть", "close", true, koto.BTN_DANGER)
    msg:reply("🎮 **Выберите действие в меню:**")
end

function on_callback(cb)
    if cb.data == "roll" then
        local roll = math.random(1, 6)
        local diff = koto.config.get("difficulty", "normal")
        cb:answer(string.format("🎲 Вам выпало: %d! (Режим: %s)", roll, diff))
        cb:button("🎲 Бросить снова", "roll")
        cb:button("🔔 Оповещение", "alert")
        cb:button("❌ Закрыть", "close", true, koto.BTN_DANGER)
        cb:edit(string.format("🎮 **Результат броска:** `%d` 🎲", roll))
        return
    end

    if cb.data == "alert" then
        local use_modal = koto.config.get_bool("notify_alert", true)
        cb:answer("🔔 Уведомление из Lua-модуля Kotogram!", use_modal)
        return
    end

    if cb.data == "close" then
        cb:answer("Меню закрыто")
        cb:delete()
        return
    end
end
```
