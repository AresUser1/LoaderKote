// tt_dl.cpp
// Скачивание контента из TikTok (видео, GIF, фото-альбомы) через tikwm API.
// Автор: Kote.
//
// .tt <ссылка>        — скачать и переслать
// .tt caption full    — подпись: название + кредиты
// .tt caption short   — подпись: только кредиты
//
// Отправка медиа идёт прямой ссылкой через c_send_file (хост сам докачивает и
// шлёт через MTProto). JSON tikwm парсится точечно под известную схему.

#include "module_abi.h"
#include "koto_utils.hpp"
#include <string>
#include <vector>
#include <cstring>

static const char* API_PREFIX = "https://www.tikwm.com/api/?hd=1&url=";

// ── Процент-кодирование значения query-параметра ─────────────────────────────
static std::string url_encode(const std::string& s) {
    static const char* hex = "0123456789ABCDEF";
    std::string out;
    out.reserve(s.size() * 3);
    for (unsigned char c : s) {
        if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
            (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.' || c == '~') {
            out.push_back((char)c);
        } else {
            out.push_back('%');
            out.push_back(hex[c >> 4]);
            out.push_back(hex[c & 0xF]);
        }
    }
    return out;
}

static std::string trim(const std::string& s) {
    size_t a = s.find_first_not_of(" \t\r\n");
    if (a == std::string::npos) return "";
    size_t b = s.find_last_not_of(" \t\r\n");
    return s.substr(a, b - a + 1);
}

static std::string to_lower(std::string s) {
    for (char& c : s) if (c >= 'A' && c <= 'Z') c = (char)(c - 'A' + 'a');
    return s;
}

static std::string extract_tiktok_url(const std::string& s) {
    size_t pos = s.find("tiktok.com/");
    if (pos == std::string::npos) pos = s.find("douyin.com/");
    if (pos != std::string::npos) {
        size_t start = s.rfind("http", pos);
        if (start != std::string::npos) {
            size_t end = s.find_first_of(" \t\r\n", pos);
            if (end == std::string::npos) return s.substr(start);
            return s.substr(start, end - start);
        }
    }
    size_t h = s.find("http://");
    if (h == std::string::npos) h = s.find("https://");
    if (h != std::string::npos) {
        size_t end = s.find_first_of(" \t\r\n", h);
        if (end == std::string::npos) return s.substr(h);
        return s.substr(h, end - h);
    }
    return "";
}

// Снять JSON-экранирование в строковом значении (\/ \" \\ \n \t \uXXXX базово).
static std::string json_unescape(const std::string& s) {
    std::string out;
    out.reserve(s.size());
    for (size_t i = 0; i < s.size(); ++i) {
        char c = s[i];
        if (c == '\\' && i + 1 < s.size()) {
            char n = s[++i];
            switch (n) {
                case '/':  out.push_back('/');  break;
                case '"':  out.push_back('"');  break;
                case '\\': out.push_back('\\'); break;
                case 'n':  out.push_back('\n'); break;
                case 't':  out.push_back('\t'); break;
                case 'r':  break;
                case 'u': {
                    if (i + 4 < s.size()) {
                        unsigned cp = 0;
                        for (int k = 0; k < 4; ++k) {
                            char h = s[i + 1 + k]; cp <<= 4;
                            if (h >= '0' && h <= '9') cp |= (unsigned)(h - '0');
                            else if (h >= 'a' && h <= 'f') cp |= (unsigned)(h - 'a' + 10);
                            else if (h >= 'A' && h <= 'F') cp |= (unsigned)(h - 'A' + 10);
                        }
                        i += 4;
                        if (cp < 0x80) out.push_back((char)cp);
                        else if (cp < 0x800) {
                            out.push_back((char)(0xC0 | (cp >> 6)));
                            out.push_back((char)(0x80 | (cp & 0x3F)));
                        } else {
                            out.push_back((char)(0xE0 | (cp >> 12)));
                            out.push_back((char)(0x80 | ((cp >> 6) & 0x3F)));
                            out.push_back((char)(0x80 | (cp & 0x3F)));
                        }
                    }
                    break;
                }
                default: out.push_back(n); break;
            }
        } else out.push_back(c);
    }
    return out;
}

// Значение строкового ключа: "key":"...."  (ищет в пределах scope).
static std::string json_str(const std::string& scope, const std::string& key) {
    std::string pat = "\"" + key + "\":\"";
    size_t p = scope.find(pat);
    if (p == std::string::npos) return "";
    p += pat.size();
    std::string raw;
    for (size_t i = p; i < scope.size(); ++i) {
        char c = scope[i];
        if (c == '\\') { raw.push_back(c); if (i + 1 < scope.size()) raw.push_back(scope[++i]); continue; }
        if (c == '"') break;
        raw.push_back(c);
    }
    return json_unescape(raw);
}

// Собрать строки массива "key":[ "...", "..." ].
static std::vector<std::string> json_str_array(const std::string& body, const std::string& key) {
    std::vector<std::string> out;
    std::string pat = "\"" + key + "\":[";
    size_t p = body.find(pat);
    if (p == std::string::npos) return out;
    p += pat.size();
    bool in_str = false;
    std::string cur;
    for (size_t i = p; i < body.size(); ++i) {
        char c = body[i];
        if (in_str) {
            if (c == '\\') { cur.push_back(c); if (i + 1 < body.size()) cur.push_back(body[++i]); continue; }
            if (c == '"') { out.push_back(json_unescape(cur)); cur.clear(); in_str = false; continue; }
            cur.push_back(c);
        } else {
            if (c == '"') in_str = true;
            else if (c == ']') break;
        }
    }
    return out;
}

// HTTP GET тела в строку (MAY BLOCK). Пусто при ошибке.
static std::string http_get_str(koto_ctx* ctx, const koto_api* api, const std::string& url) {
    std::vector<unsigned char> buf(512 * 1024);
    long long n = api->http_get(ctx, url.c_str(), buf.data(), (int)buf.size());
    if (n <= 0) return "";
    if (n > (long long)buf.size()) n = (long long)buf.size();
    return std::string((const char*)buf.data(), (size_t)n);
}

// Декларация настроек модуля для отображения в панели приложения и .cfg
static const koto_setting_field SETTINGS[] = {
    {
        "caption_full",
        "Скачивать с описанием (полная подпись)",
        KOTO_FIELD_BOOL,
        "1",
        nullptr
    }
};

static bool caption_full(koto_ctx* ctx, const koto_api* api) {
    if (api && api->cfg_get) {
        char buf[32] = {0};
        int n = api->cfg_get(ctx, "caption_full", buf, sizeof(buf) - 1);
        if (n > 0) {
            buf[n] = '\0';
            std::string s = to_lower(trim(buf));
            return (s == "1" || s == "true" || s == "yes");
        }
    }
    return api->db_get_int(ctx, "caption_full", 1) != 0;
}

// Составить подпись в текущий композер (title берётся только в full-режиме).
static void compose_caption(koto_ctx* ctx, const koto_api* api, const std::string& title, bool full) {
    api->c_reset(ctx);
    if (full && !title.empty()) {
        api->c_fmt(ctx, ("\xF0\x9F\x8E\xAC " + title).c_str(), KOTO_ENT_BOLD); // 🎬 <title>
        api->c_text(ctx, "\n\n");
    }
    api->c_fmt(ctx, "\xF0\x9F\x93\xA5 \xD0\xA1\xD0\xBA\xD0\xB0\xD1\x87\xD0\xB0\xD0\xBD\xD0\xBE \xD1\x87\xD0\xB5\xD1\x80\xD0\xB5\xD0\xB7 KoteLoader", KOTO_ENT_ITALIC); // 📥 Скачано через KoteLoader
}

static void edit_msg(koto_ctx* ctx, const koto_api* api, const char* msg_utf8, int fmt_flag) {
    api->c_reset(ctx);
    api->c_fmt(ctx, msg_utf8, fmt_flag);
    if (api->is_outgoing && api->is_outgoing(ctx)) {
        api->c_edit(ctx, 0);
    } else if (api->c_reply) {
        api->c_reply(ctx, 0);
    } else {
        api->c_edit(ctx, 0);
    }
}

static void edit_err(koto_ctx* ctx, const koto_api* api, const char* msg_utf8) {
    edit_msg(ctx, api, msg_utf8, KOTO_ENT_BOLD);
}

// ── Резервное извлечение через ssstik.io ──────────────────────────────────────
static bool fetch_via_ssstik(koto_ctx* ctx, const koto_api* api, const std::string& raw_url,
                             std::string& out_title, std::string& out_play, std::vector<std::string>& out_images) {
    if (!api || !api->http_post) return false;

    // Очищаем параметры отслеживания (?_r=1...)
    std::string clean_url = raw_url;
    size_t qp = clean_url.find('?');
    if (qp != std::string::npos) clean_url = clean_url.substr(0, qp);

    std::string enc = url_encode(clean_url);
    std::string post_data = "id=" + enc + "&locale=en&tt=0";
    std::string headers =
        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36\r\n"
        "Origin: https://ssstik.io\r\n"
        "Referer: https://ssstik.io/en\r\n"
        "HX-Request: true\r\n"
        "HX-Trigger: _gcaptcha_pt\r\n"
        "HX-Target: target\r\n"
        "HX-Current-URL: https://ssstik.io/en\r\n"
        "Content-Type: application/x-www-form-urlencoded; charset=UTF-8";

    std::vector<unsigned char> buf(512 * 1024);
    long long n = api->http_post(ctx, "https://ssstik.io/abc?url=dl", post_data.c_str(),
                                 headers.c_str(), buf.data(), (int)buf.size());
    if (n <= 0) return false;

    std::string html((const char*)buf.data(), (size_t)n);

    // Заголовок
    size_t tp = html.find("<p class=\"maintext\">");
    if (tp != std::string::npos) {
        tp += 20;
        size_t te = html.find("</p>", tp);
        if (te != std::string::npos) {
            out_title = trim(html.substr(tp, te - tp));
        }
    }
    if (out_title.empty()) {
        size_t h2p = html.find("<h2>");
        if (h2p != std::string::npos) {
            h2p += 4;
            size_t h2e = html.find("</h2>", h2p);
            if (h2e != std::string::npos) {
                out_title = trim(html.substr(h2p, h2e - h2p));
            }
        }
    }

    // Прямой URL видео: href="https://tikcdn.io/ssstik/... (исключая /m/ и /a/ и /p/)
    size_t vp = html.find("href=\"https://tikcdn.io/ssstik/");
    while (vp != std::string::npos) {
        vp += 6;
        size_t ve = html.find('"', vp);
        if (ve != std::string::npos) {
            std::string u = html.substr(vp, ve - vp);
            if (u.find("/m/") == std::string::npos &&
                u.find("/a/") == std::string::npos &&
                u.find("/p/") == std::string::npos) {
                out_play = u;
                break;
            }
        }
        vp = html.find("href=\"https://tikcdn.io/ssstik/", vp + 1);
    }

    // Запасной поиск кнопки without_watermark
    if (out_play.empty()) {
        size_t wmp = html.find("without_watermark");
        if (wmp != std::string::npos) {
            size_t hp = html.rfind("href=\"", wmp);
            if (hp != std::string::npos) {
                hp += 6;
                size_t he = html.find('"', hp);
                if (he != std::string::npos) {
                    std::string u = html.substr(hp, he - hp);
                    if (u.rfind("http", 0) == 0 && u.find("/m/") == std::string::npos) {
                        out_play = u;
                    }
                }
            }
        }
    }

    // Фото-слайды (если фотоальбом)
    size_t ip = html.find("https://tikcdn.io/ssstik/p/");
    while (ip != std::string::npos) {
        size_t ie = html.find_first_of("\"' \t\r\n", ip);
        if (ie != std::string::npos) {
            std::string img_url = html.substr(ip, ie - ip);
            out_images.push_back(img_url);
            ip = html.find("https://tikcdn.io/ssstik/p/", ie);
        } else break;
    }

    return !out_play.empty() || !out_images.empty();
}

static void cmd_tt(koto_ctx* ctx, const koto_api* api) {
    const char* raw = api->cmd_args ? api->cmd_args(ctx) : nullptr;
    std::string args = trim(raw ? raw : "");

    // ── Переключение режима подписи ──────────────────────────────────────────
    if (args.rfind("caption", 0) == 0) {
        std::string rest = trim(args.substr(7));
        std::string mode = to_lower(rest);
        if (mode == "full") {
            if (api->cfg_set) api->cfg_set(ctx, "caption_full", "1");
            api->db_set_int(ctx, "caption_full", 1);
            edit_msg(ctx, api, "\xE2\x9C\x85 \xD0\xA0\xD0\xB5\xD0\xB6\xD0\xB8\xD0\xBC \xD0\xBF\xD0\xBE\xD0\xB4\xD0\xBF\xD0\xB8\xD1\x81\xD0\xB8: \xD0\xBF\xD0\xBE\xD0\xBB\xD0\xBD\xD1\x8B\xD0\xB9 (\xD0\xBD\xD0\xB0\xD0\xB7\xD0\xB2\xD0\xB0\xD0\xBD\xD0\xB8\xD0\xB5 + \xD0\xBA\xD1\x80\xD0\xB5\xD0\xB4\xD0\xB8\xD1\x82\xD1\x8B)", KOTO_ENT_BOLD);
            return;
        } else if (mode == "short") {
            if (api->cfg_set) api->cfg_set(ctx, "caption_full", "0");
            api->db_set_int(ctx, "caption_full", 0);
            edit_msg(ctx, api, "\xE2\x9C\x85 \xD0\xA0\xD0\xB5\xD0\xB6\xD0\xB8\xD0\xBC \xD0\xBF\xD0\xBE\xD0\xB4\xD0\xBF\xD0\xB8\xD1\x81\xD0\xB8: \xD0\xBA\xD1\x80\xD0\xB0\xD1\x82\xD0\xBA\xD0\xB8\xD0\xB9 (\xD1\x82\xD0\xBE\xD0\xBB\xD1\x8C\xD0\xBA\xD0\xBE \xD0\xBA\xD1\x80\xD0\xB5\xD0\xB4\xD0\xB8\xD1\x82\xD1\x8B)", KOTO_ENT_BOLD);
            return;
        } else {
            std::string cur = caption_full(ctx, api) ? "full" : "short";
            std::string msg = "\xE2\x84\xB9\xEF\xB8\x8F \xD0\xA2\xD0\xB5\xD0\xBA\xD1\x83\xD1\x89\xD0\xB8\xD0\xB9 \xD1\x80\xD0\xB5\xD0\xB6\xD0\xB8\xD0\xBC: " + cur + "\n\xD0\x98\xD1\x81\xD0\xBF\xD0\xBE\xD0\xBB\xD1\x83\xD1\x87\xD0\xB0\xD1\x8E: .tt caption full / short";
            edit_msg(ctx, api, msg.c_str(), KOTO_ENT_ITALIC);
            return;
        }
    }

    // Поддержка ответа на сообщение со ссылкой
    if (args.empty() && api->reply_text) {
        const char* rep = api->reply_text(ctx);
        if (rep && rep[0]) {
            args = trim(rep);
        }
    }

    if (args.empty()) {
        edit_err(ctx, api, "\xE2\x9D\x8C \xD0\xA3\xD0\xBA\xD0\xB0\xD0\xB6\xD0\xB8\xD1\x82\xD0\xB5 \xD1\x81\xD1\x81\xD1\x8B\xD0\xBB\xD0\xBA\xD1\x83 \xD0\xBD\xD0\xB0 TikTok \xD0\xB8\xD0\xBB\xD0\xB8 \xD0\xBE\xD1\x82\xD0\xB2\xD0\xB5\xD1\x82\xD1\x8C\xD1\x82\xD0\xB5 \xD0\xBD\xD0\xB0 \xD0\xBD\xD0\xB5\xD1\x91."); // ❌ Укажите ссылку на TikTok или ответьте на неё.
        return;
    }

    std::string link = extract_tiktok_url(args);
    if (link.empty()) {
        link = args;
        size_t sp = link.find_first_of(" \t\n");
        if (sp != std::string::npos) link = link.substr(0, sp);
    }

    // 1. Моментальный визуальный статус "Скачиваю TikTok..." сразу при старте
    edit_msg(ctx, api, "\xE2\x8F\xB3 \xD0\xA1\xD0\xBA\xD0\xB0\xD1\x87\xD0\xB8\xD0\xB2\xD0\xB0\xD1\x8E TikTok...", KOTO_ENT_ITALIC); // ⏳ Скачиваю TikTok...

    std::string title;
    std::string play;
    std::vector<std::string> images;

    // Сначала пробуем быстрый TikWM API
    std::string enc = url_encode(link);
    std::string body = http_get_str(ctx, api, std::string(API_PREFIX) + enc);
    if (!body.empty() && body.find("\"code\":0") != std::string::npos) {
        size_t dpos = body.find("\"data\"");
        size_t mpos = body.find("\"music_info\"");
        std::string data_scope = (dpos == std::string::npos)
            ? body
            : (mpos != std::string::npos && mpos > dpos ? body.substr(dpos, mpos - dpos) : body.substr(dpos));
        title = json_str(data_scope, "title");
        images = json_str_array(body, "images");
        if (images.empty()) {
            play = json_str(data_scope, "play");
            if (play.empty()) play = json_str(data_scope, "hdplay");
            if (play.empty()) play = json_str(data_scope, "wmplay");
        }
    }

    // Если TikWM упал с 502/таймаутом или не дал видео — фоллбэк на SSSTik
    if (play.empty() && images.empty()) {
        fetch_via_ssstik(ctx, api, link, title, play, images);
    }

    if (play.empty() && images.empty()) {
        edit_err(ctx, api, "\xE2\x9D\x8C \xD0\xA1\xD0\xB5\xD1\x80\xD0\xB2\xD0\xB5\xD1\x80\xD1\x8B TikTok \xD0\xBD\xD0\xB5 \xD0\xBE\xD1\x82\xD0\xB2\xD0\xB5\xD1\x82\xD0\xB8\xD0\xBB\xD0\xB8 (502 / \xD1\x82\xD0\xB0\xD0\xB9\xD0\xBC\xD0\xB0\xD1\x83\xD1\x82). \xD0\x9F\xD0\xBE\xD0\xB2\xD1\x82\xD0\xBE\xD1\x80\xD0\xB8\xD1\x82\xD0\xB5 \xD1\x87\xD0\xB5\xD1\x80\xD0\xB5\xD0\xB7 \xD0\xBF\xD0\xB0\xD1\x80\xD1\x83 \xD1\x81\xD0\xB5\xD0\xBA\xD1\x83\xD0\xBD\xD0\xB4."); // ❌ Серверы TikTok не ответили (502 / таймаут). Повторите через пару секунд.
        return;
    }

    // 2. Статус отправки
    edit_msg(ctx, api, "\xF0\x9F\x93\xA5 \xD0\x9E\xD1\x82\xD0\xBF\xD1\x80\xD0\xB0\xD0\xB2\xD0\xBB\xD1\x8F\xD1\x8E...", KOTO_ENT_ITALIC); // 📥 Отправляю...

    long long cid = api->chat_id(ctx);
    bool full = caption_full(ctx, api);

    // ── Фото-альбом ───────────────────────────────────────────────────────────
    if (!images.empty()) {
        compose_caption(ctx, api, title, full);   // подпись = композер (на 1-м фото)
        if (api->c_send_album) {
            std::vector<const char*> ptrs;
            ptrs.reserve(images.size());
            for (const auto& img : images) ptrs.push_back(img.c_str());
            api->c_send_album(ctx, cid, ptrs.data(), (int)ptrs.size(), 0);
        } else {
            bool first = true;
            for (const auto& img : images) {
                if (first) { compose_caption(ctx, api, title, full); first = false; }
                else api->c_reset(ctx);
                api->c_send_file(ctx, cid, img.c_str(), 0);
            }
        }
        api->delete_msg(ctx);
        return;
    }

    // ── Видео / GIF ─────────────────────────────────────────────────────────
    if (play.empty()) {
        edit_err(ctx, api, "\xE2\x9D\x8C \xD0\x9D\xD0\xB5 \xD0\xBD\xD0\xB0\xD0\xB9\xD0\xB4\xD0\xB5\xD0\xBD \xD0\xBF\xD1\x80\xD1\x8F\xD0\xBC\xD0\xBE\xD0\xB9 URL \xD0\xB2\xD0\xB8\xD0\xB4\xD0\xB5\xD0\xBE."); // ❌ Не найден прямой URL видео.
        return;
    }

    compose_caption(ctx, api, title, full);
    api->c_send_file(ctx, cid, play.c_str(), 0);
    api->delete_msg(ctx);
}

static const koto_command COMMANDS[] = {
    {
        "tt",
        &cmd_tt,
        KOTO_LEVEL_TRUSTED,
        "[ru] Скачать контент из TikTok (видео, GIF, фото). [en] Download content from TikTok (video, GIF, photo).", // "Скачать контент из TikTok (видео, GIF, фото)."
        "<\xD1\x81\xD1\x81\xD1\x8B\xD0\xBB\xD0\xBA\xD0\xB0> | caption [full|short]" // "<ссылка> | caption [full|short]"
    }
};

static const koto_module MODULE = {
    KOTO_MODULE_ABI,
    "tt_dl",
    "[ru] Скачивание видео из TikTok (видео, гифки, фото-альбомы). C++ ABI 3. [en] Download TikTok content (video, GIF, photo albums). C++ ABI 3.", // "Скачивание видео из TikTok (видео, гифки, фото-альбомы). C++ ABI 3."
    "1.7.1",
    24,
    0,
    COMMANDS,
    sizeof(COMMANDS) / sizeof(COMMANDS[0]),
    nullptr, 0,
    nullptr,
    SETTINGS,
    sizeof(SETTINGS) / sizeof(SETTINGS[0]),
    "https://raw.githubusercontent.com/AresUser1/KoteModules/main/modules/tt_dl.so"
};

extern "C" const koto_module* koto_module_register(void) {
    return &MODULE;
}
