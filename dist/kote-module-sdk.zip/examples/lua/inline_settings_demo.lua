name = "inline_demo"
description = "Демонстрация интерактивных кнопок и меню настроек (.cfg) на Lua"
version = "1.0.0"
author = "Kotogram Dev"
min_host_version = 114

-- ── 1. Декларация настроек для интерактивного меню (.cfg) ────────────────────
-- Доступные типы: "bool", "int", "float", "str", "choice"
settings = {
    { key = "auto_quote", label = "Цитата в ответе", type = "bool", default = "true" },
    { key = "cooldown",   label = "Задержка (сек)",   type = "int",  default = "3" },
    { key = "mode",       label = "Режим работы",     type = "choice", default = "standard", choices = "standard,turbo,eco" },
    { key = "prefix_icon",label = "Иконка карточки",  type = "str",  default = "🎮" }
}

-- ── 2. Декларация команд ─────────────────────────────────────────────────────
commands = {
    demo = { doc = "Открыть интерактивное меню с кнопками", usage = "" },
    cfgtest = { doc = "Показать текущие значения настроек", usage = "" }
}

-- ── 3. Обработка команд ──────────────────────────────────────────────────────
function cmd_cfgtest(msg, args)
    -- Чтение настроек через koto.config (или msg:config)
    local auto_q = koto.config.get_bool("auto_quote", true)
    local cd     = koto.config.get_int("cooldown", 3)
    local mode   = koto.config.get("mode", "standard")
    local icon   = koto.config.get("prefix_icon", "🎮")

    local text = string.format(
        "⚙️ **Текущие настройки модуля `%s`:**\n\n" ..
        "• Иконка: %s\n" ..
        "• Цитата в ответе: %s\n" ..
        "• Задержка: `%d сек`\n" ..
        "• Режим: `%s`\n\n" ..
        "_Изменить их можно через команду `.cfg`_",
        name, icon, auto_q and "✅ Вкл" or "❌ Выкл", cd, mode
    )
    msg:reply(text)
end

function cmd_demo(msg, args)
    local icon = koto.config.get("prefix_icon", "🎮")
    local mode = koto.config.get("mode", "standard")

    -- Добавляем инлайн-кнопки к сообщению:
    -- msg:button(текст, callback_data, [new_row], [color], [icon])
    msg:button("👍 Лайк (0)", "like:0")
    msg:button("👎 Дизлайк (0)", "dislike:0")
    msg:button("🎲 Случайное число", "roll", true, koto.BTN_PRIMARY)
    msg:button("💬 Всплывашка", "alert", true)
    msg:button("❌ Закрыть", "close", false, koto.BTN_DANGER)

    msg:reply(string.format("%s **Интерактивное меню на Lua!**\n\nТекущий режим: `%s`\nНажимайте кнопки ниже:", icon, mode))
end

-- ── 4. Обработка входящих сообщений (обязательно) ────────────────────────────
function on_message(msg)
    if not msg or not msg.out then return end
    local text = msg.text or ""
    local cmd = text:match("^[%.!/](%w+)")
    if cmd then
        cmd = cmd:lower()
        if cmd == "demo" then
            local args = text:match("^[%.!/]%w+%s*(.*)$") or ""
            cmd_demo(msg, args)
        elseif cmd == "cfgtest" then
            local args = text:match("^[%.!/]%w+%s*(.*)$") or ""
            cmd_cfgtest(msg, args)
        end
    end
end

-- ── 5. Обработка нажатий на инлайн-кнопки ────────────────────────────────────
function on_callback(cb)
    local data = cb.data or ""

    -- 1. Кнопка Лайк
    if data:sub(1, 5) == "like:" then
        local count = tonumber(data:sub(6)) or 0
        count = count + 1
        cb:answer("Вы поставили лайк! ❤️")

        -- Обновляем кнопки и текст сообщения
        cb:button(string.format("👍 Лайк (%d)", count), "like:" .. count)
        cb:button("👎 Дизлайк", "dislike:0")
        cb:button("🎲 Случайное число", "roll", true, koto.BTN_PRIMARY)
        cb:button("💬 Всплывашка", "alert", true)
        cb:button("❌ Закрыть", "close", false, koto.BTN_DANGER)
        cb:edit(string.format("🎮 **Интерактивное меню на Lua!**\n\nЛайков собрано: **%d**", count))
        return
    end

    -- 2. Кнопка Дизлайк
    if data:sub(1, 8) == "dislike:" then
        cb:answer("Дизлайк засчитан 💔")
        return
    end

    -- 3. Кнопка Случайное число
    if data == "roll" then
        local num = math.random(1, 100)
        cb:answer(string.format("🎲 Выпало число: %d!", num), true) -- Всплывающее модальное окно (alert=true)
        return
    end

    -- 4. Кнопка Всплывашка
    if data == "alert" then
        cb:answer("🔔 Это модальное уведомление из Lua-модуля!", true)
        return
    end

    -- 5. Кнопка Закрыть
    if data == "close" then
        cb:answer("Панель закрыта")
        cb:delete()
        return
    end
end
