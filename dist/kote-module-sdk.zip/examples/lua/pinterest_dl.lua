-- ============================================================================
-- Модуль: pinterest_dl (Pinterest Downloader)
-- Автор оригинала (Hikka): @weyrix
-- Адаптация для Kotogram: Kote Team
-- Версия: 1.1.0
-- Описание: Скачивает видео, GIF, звук и фото из Pinterest с выбором качества
-- ============================================================================

name = "pinterest_dl"
description = "Скачивает медиа из Pinterest с выбором формата (видео/гиф/звук/фото) и качества через инлайн-кнопки"
version = "1.1.0"
min_host_version = 114

commands = {
    {
        name = "pin",
        usage = "<ссылка или реплай>",
        doc = "Скачать медиа из Pinterest с выбором формата и качества через инлайн-кнопки"
    },
    {
        name = "pindl",
        usage = "<ссылка или реплай>",
        doc = "Алиас для .pin"
    },
    {
        name = "pinterest",
        usage = "<ссылка или реплай>",
        doc = "Алиас для .pin"
    }
}

-- Хранилище активных интерактивных сессий и дедупликация сообщений
local sessions = {}
local last_msg_key = nil

local MODES = {
    video = "🖼 Фото / 🎬 Видео",
    gif   = "🎞 GIF (без звука)",
    audio = "🎵 Звук (MP3)"
}

local QUALITIES = {
    best  = "🔥 Макс.",
    ["720"] = "📺 720p",
    ["480"] = "📱 480p"
}

-- Генерация текста для инлайн-карточки
local function get_text(st)
    local q_label = (st.mode ~= "audio") and (QUALITIES[st.quality] or st.quality) or "Аудио поток"
    local mode_name = MODES[st.mode] or st.mode
    return "📌 <b>Pinterest Downloader</b>\n\n" ..
           "⚙️ <b>Текущие настройки:</b>\n" ..
           "• Формат: <b>" .. mode_name .. "</b>\n" ..
           "• Качество: <b>" .. q_label .. "</b>\n\n" ..
           "<i>Выберите параметры ниже и нажмите «Скачать»:</i>"
end

-- Генерация клавиатуры инлайн-кнопок
local function get_buttons(sid, st)
    local mode = st.mode
    local quality = st.quality

    local m_video = (mode == "video" and "✅ " or "") .. "🖼 Фото / 🎬 Видео"
    local m_gif   = (mode == "gif"   and "✅ " or "") .. "🎞 GIF"
    local m_audio = (mode == "audio" and "✅ " or "") .. "🎵 Звук"

    local rows = {
        {
            { text = m_video, data = "pin:m:" .. sid .. ":video" },
            { text = m_gif,   data = "pin:m:" .. sid .. ":gif" },
            { text = m_audio, data = "pin:m:" .. sid .. ":audio" }
        }
    }

    if mode ~= "audio" then
        local q_best = (quality == "best" and "✅ " or "") .. "🔥 Макс."
        local q_720  = (quality == "720"  and "✅ " or "") .. "📺 720p"
        local q_480  = (quality == "480"  and "✅ " or "") .. "📱 480p"
        table.insert(rows, {
            { text = q_best, data = "pin:q:" .. sid .. ":best" },
            { text = q_720,  data = "pin:q:" .. sid .. ":720" },
            { text = q_480,  data = "pin:q:" .. sid .. ":480" }
        })
    end

    table.insert(rows, {
        { text = "⬇️ Скачать", data = "pin:dl:" .. sid },
        { text = "❌ Отмена",  data = "pin:c:" .. sid }
    })

    return rows
end

-- Поиск ссылки на Pinterest
local function find_pinterest_url(text)
    if not text or text == "" then return nil end
    local url = text:match("(https?://[%w%-_%.]*pinterest%.[%w%.]+/pin/[%w%-_]+/?%S*)")
    if url then return url end
    url = text:match("(https?://pin%.it/[%w%-_]+%S*)")
    if url then return url end
    return nil
end

-- Безопасное получение полей реплая (поддержка reply_msg и reply)
local function get_reply_field(msg, field)
    if not msg then return nil end
    if type(msg.reply_msg) == "table" then
        return msg.reply_msg[field]
    end
    if type(msg.reply) == "table" then
        return msg.reply[field]
    end
    return nil
end

-- Декодирование HTML-сущностей и очистка заголовка
local function clean_title(title)
    if not title or title == "" then return nil end
    title = title:gsub("%s*|%s*Pinterest.*$", ""):gsub("^%s+", ""):gsub("%s+$", "")
    title = title:gsub("&quot;", '"')
                 :gsub("&#39;", "'")
                 :gsub("&#x27;", "'")
                 :gsub("&amp;", "&")
                 :gsub("&lt;", "<")
                 :gsub("&gt;", ">")
    if title == "" then return nil end
    return title
end

local function escape_html(s)
    if not s or s == "" then return "" end
    return (s:gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;"))
end

-- Извлечение строкового JSON-поля с учетом экранирования
local function extract_json_string_field(json, key)
    if not json or json == "" then return nil end
    local pat = '"' .. key .. '"%s*:%s*"'
    local _, s_end = json:find(pat)
    if not s_end then return nil end
    local i = s_end + 1
    local len = #json
    local out = {}
    while i <= len do
        local c = json:sub(i, i)
        if c == '"' then
            break
        elseif c == '\\' and i < len then
            local nxt = json:sub(i + 1, i + 1)
            if nxt == '"' or nxt == '\\' or nxt == '/' then
                table.insert(out, nxt)
            elseif nxt == 'n' or nxt == 'r' or nxt == 't' then
                table.insert(out, " ")
            end
            i = i + 2
        else
            table.insert(out, c)
            i = i + 1
        end
    end
    local val = table.concat(out):gsub("^%s+", ""):gsub("%s+$", "")
    if val == "" then return nil end
    return val
end

-- Извлечение числового ID пина
local function extract_pin_id(s)
    if not s or s == "" then return nil end
    local id = s:match('"seoUrl"%s*:%s*"/pin/(%d+)')
    if id and #id >= 4 then return id end
    id = s:match('"pinId"%s*:%s*"(%d+)')
    if id and #id >= 4 then return id end
    id = s:match('pinterest%.[^/"\'\r\n]+/pin/(%d+)')
    if id and #id >= 4 then return id end
    id = s:match('/pin/(%d%d%d%d%d+)')
    if id then return id end
    return nil
end

-- Апгрейд миниатюры до оригинального качества
local function upgrade_to_orig(u)
    if not u then return nil end
    local out = u
    out = out:gsub("/1200x/", "/originals/", 1)
    out = out:gsub("/736x/", "/originals/", 1)
    out = out:gsub("/564x/", "/originals/", 1)
    out = out:gsub("/474x/", "/originals/", 1)
    out = out:gsub("/236x/", "/originals/", 1)
    return out
end

-- Отсеивание спрайтов/иконок Pinterest
local function is_sprite(u)
    if not u or u == "" then return true end
    if u:find("d53b014d86a6b6761bf649a0ed813c2b", 1, true) then return true end
    if u:find("default_user", 1, true) then return true end
    if u:find("favicon", 1, true) then return true end
    return false
end

-- Выбор видеопотока из текста/JSON по качеству
local function pick_video_from_blob(blob, quality)
    if not blob or blob == "" then return nil, nil end
    local mp4_720, mp4_480, mp4_any = nil, nil, nil
    for u in blob:gmatch('(https?://v%d?%.pinimg%.com/videos/[^"%s<>\'?]+%.mp4)') do
        if u:find("/720p/", 1, true) then mp4_720 = mp4_720 or u
        elseif u:find("/480p/", 1, true) then mp4_480 = mp4_480 or u
        end
        mp4_any = mp4_any or u
    end
    if not mp4_any then
        for esc in blob:gmatch('(https?:\\/\\/v%d?%.pinimg%.com\\/videos\\/[^"%s<>\'?]+%.mp4)') do
            local u = esc:gsub("\\/", "/"):gsub("\\.*$", "")
            if u:find("/720p/", 1, true) then mp4_720 = mp4_720 or u
            elseif u:find("/480p/", 1, true) then mp4_480 = mp4_480 or u
            end
            mp4_any = mp4_any or u
        end
    end
    if mp4_any then
        local chosen = (quality == "480" and mp4_480) or (quality == "720" and mp4_720) or mp4_720 or mp4_any or mp4_480
        return chosen, mp4_any
    end

    local hls = blob:match('(https?://v%d?%.pinimg%.com/videos/[^"%s<>\'?]+%.m3u8)')
    if not hls then
        local esc_hls = blob:match('(https?:\\/\\/v%d?%.pinimg%.com\\/videos\\/[^"%s<>\'?]+%.m3u8)')
        if esc_hls then hls = esc_hls:gsub("\\/", "/"):gsub("\\.*$", "") end
    end
    if hls then
        local q_tag = (quality == "480") and "/480p/" or "/720p/"
        local converted = hls:gsub("/hls/", q_tag, 1):gsub("%.m3u8$", ".mp4")
        return converted, hls
    end
    return nil, nil
end

local function pin_log(msg)
    if koto and koto.log then
        pcall(koto.log, "[pinterest_dl] " .. tostring(msg))
    end
end

-- Разрешение ссылки на медиапоток, заголовка и fallback URL
local function resolve_media(url, quality)
    local html = nil
    local title = nil
    local pin_id = extract_pin_id(url)

    -- 1. Для короткой ссылки pin.it сначала разрешаем редирект через url_shortener
    local fetch_url = url
    local slug = url:match("pin%.it/([%w%-_]+)")
    if slug and slug ~= "" then
        fetch_url = "https://api.pinterest.com/url_shortener/" .. slug .. "/redirect/"
    end

    if not pin_id then
        html = koto.http_get(fetch_url)
        if html and html ~= "" then
            pin_id = extract_pin_id(html)
        end
        if not pin_id and slug and slug ~= "" and fetch_url ~= url then
            local fb_html = koto.http_get(url)
            if fb_html and fb_html ~= "" then
                pin_id = extract_pin_id(fb_html)
                if not html or html == "" then html = fb_html end
            end
        end
    end

    pin_log("resolve_media url=" .. tostring(url) .. " pin_id=" .. tostring(pin_id or "nil"))

    -- Stage A: Быстрый PinResource JSON API (когда известен pin_id)
    if pin_id then
        local api_url = "https://www.pinterest.com/resource/PinResource/get/?data=%7B%22options%22%3A%7B%22field_set_key%22%3A%22unauth_react_main_pin%22%2C%22id%22%3A%22" .. pin_id .. "%22%7D%7D"
        local jstr = koto.http_get(api_url)
        if jstr and jstr ~= "" then
            local jclean = jstr:gsub("\\/", "/")
            title = clean_title(
                extract_json_string_field(jclean, "title")
                or extract_json_string_field(jclean, "description")
                or extract_json_string_field(jclean, "grid_title")
            )

            local v_url, v_fb = pick_video_from_blob(jclean, quality)
            if v_url then
                pin_log("Stage A (PinResource video) OK")
                return v_url, true, title, v_fb
            end

            local orig_url = jclean:match('"orig"%s*:%s*{[^}]*"url"%s*:%s*"(https?://i%.pinimg%.com/[^"]+)"')
                          or jclean:match('"originals"%s*:%s*{[^}]*"url"%s*:%s*"(https?://i%.pinimg%.com/[^"]+)"')
            local fb_736 = jclean:match('"736x"%s*:%s*{[^}]*"url"%s*:%s*"(https?://i%.pinimg%.com/[^"]+)"')
            if orig_url and not is_sprite(orig_url) then
                pin_log("Stage A (PinResource orig image) OK")
                return orig_url, false, title, fb_736
            end
            if fb_736 and not is_sprite(fb_736) then
                pin_log("Stage A (PinResource 736x image) OK")
                return fb_736, false, title, nil
            end
        end
    end

    -- Stage B: HTML-страница канонического пина
    if pin_id and (not html or html == "" or not html:find("pinimg.com", 1, true)) then
        local h2 = koto.http_get("https://www.pinterest.com/pin/" .. pin_id .. "/")
        if h2 and h2 ~= "" then
            html = h2
        end
    end

    if html and html ~= "" then
        if not title then
            local head_chunk = html:sub(1, 250000)
            title = clean_title(head_chunk:match('<title>(.-)</title>'))
        end

        local v_url, v_fb = pick_video_from_blob(html, quality)
        if v_url then
            pin_log("Stage B (HTML video) OK")
            return v_url, true, title, v_fb
        end

        -- Поиск preload-ссылки без медленного бэктрекинга
        local preload_pos = html:find("pin-image-preload", 1, true)
        if preload_pos then
            local slice = html:sub(math.max(1, preload_pos - 300), math.min(#html, preload_pos + 300))
            local href = slice:match('href="([^"]+)"')
            if href and href:find("i.pinimg.com/", 1, true) and not is_sprite(href) then
                pin_log("Stage B (HTML preload image) OK")
                return upgrade_to_orig(href), false, title, href
            end
        end

        -- og:image в начале документа
        local head_chunk = html:sub(1, 250000)
        local og_img = head_chunk:match('<meta[^>]+property="og:image"[^>]+content="([^"]+)"')
                    or head_chunk:match('<meta[^>]+content="([^"]+)"[^>]+property="og:image"')
        if og_img and og_img:find("i.pinimg.com/", 1, true) and not is_sprite(og_img) then
            pin_log("Stage B (HTML og:image) OK")
            return upgrade_to_orig(og_img), false, title, og_img
        end

        -- Перебор i.pinimg.com ссылок на пин-хэши, пропуская спрайты
        for u in html:gmatch('(https?://i%.pinimg%.com/[%w]+/%x%x/%x%x/%x%x/[%x]+%.[%a%d]+)') do
            if not is_sprite(u) and (u:find("/originals/", 1, true) or u:find("/1200x/", 1, true)
                                     or u:find("/736x/", 1, true) or u:find("/564x/", 1, true)) then
                pin_log("Stage B (HTML scan image) OK")
                return upgrade_to_orig(u), false, title, u
            end
        end

        -- Экранированный JSON в скриптах (https:\/\/i.pinimg.com\/...)
        for esc in html:gmatch('(https?:\\/\\/i%.pinimg%.com\\/[^"%s<>\']+)') do
            local u = esc:gsub("\\/", "/"):gsub("\\.*$", "")
            if not is_sprite(u) and (u:find("/originals/", 1, true) or u:find("/1200x/", 1, true)
                                     or u:find("/736x/", 1, true) or u:find("/564x/", 1, true)) then
                if u:match('/%x%x/%x%x/%x%x/[%x]+%.[%a%d]+$') then
                    pin_log("Stage B (HTML escaped JSON image) OK")
                    return upgrade_to_orig(u), false, title, u
                end
            end
        end
    end

    -- Stage C: widgets.pinterest.com JSON API
    if pin_id then
        local wj = koto.http_get("https://widgets.pinterest.com/v3/pidgets/pins/info/?pin_ids=" .. pin_id)
        if wj and wj ~= "" then
            local wclean = wj:gsub("\\/", "/")
            if not title then
                title = clean_title(extract_json_string_field(wclean, "description"))
            end
            local v_url, v_fb = pick_video_from_blob(wclean, quality)
            if v_url then
                pin_log("Stage C (widgets video) OK")
                return v_url, true, title, v_fb
            end
            local w_img = wclean:match('"564x"%s*:%s*{[^}]*"url"%s*:%s*"(https?://i%.pinimg%.com/[^"]+)"')
                       or wclean:match('"236x"%s*:%s*{[^}]*"url"%s*:%s*"(https?://i%.pinimg%.com/[^"]+)"')
            if w_img and not is_sprite(w_img) then
                pin_log("Stage C (widgets image) OK")
                return upgrade_to_orig(w_img), false, title, w_img
            end
        end

        -- Stage D: oembed.json
        local oj = koto.http_get("https://www.pinterest.com/oembed.json?url=https://www.pinterest.com/pin/" .. pin_id .. "/")
        if oj and oj ~= "" then
            local oclean = oj:gsub("\\/", "/")
            if not title then
                title = clean_title(extract_json_string_field(oclean, "title"))
            end
            local tu = oclean:match('"thumbnail_url"%s*:%s*"(https?://i%.pinimg%.com/[^"]+)"')
            if tu and not is_sprite(tu) then
                pin_log("Stage D (oembed image) OK")
                return upgrade_to_orig(tu), false, title, tu
            end
        end
    end

    pin_log("resolve_media FAILED all stages for url=" .. tostring(url))
    return nil, false, title, nil
end

-- Скачивание файла с запасным URL
local function download_with_fallback(primary_url, fallback_url, target_filename)
    local dl_path = target_filename and koto.download(primary_url, target_filename) or koto.download(primary_url)
    if (not dl_path or dl_path == "") and fallback_url and fallback_url ~= "" and fallback_url ~= primary_url then
        dl_path = target_filename and koto.download(fallback_url, target_filename) or koto.download(fallback_url)
    end
    return dl_path
end

-- Обработка скачивания и отправки пользователю
local function handle_download(cb, st)
    local q_label = (st.mode ~= "audio") and (QUALITIES[st.quality] or st.quality) or "MP3"
    local mode_name = MODES[st.mode] or st.mode
    cb:edit_html("⏳ <b>Скачиваю и обрабатываю (" .. mode_name .. " / " .. q_label .. ")...</b>")

    local media_url, is_video, title, fallback_url = resolve_media(st.url, st.quality)
    if not media_url then
        cb:edit_html("❌ <b>Не удалось извлечь медиа из Pinterest ссылки.</b>\nВозможно, пин приватный или удален.")
        return
    end

    cb:edit_html("⏳ <b>Загрузка файла (" .. (is_video and "видео" or "фото") .. ")...</b>")

    local cdir = (koto.cache_dir and koto.cache_dir()) or "/data/local/tmp"
    local time_id = tostring(os.time()) .. "_" .. tostring(math.random(1000, 9999))
    local target_filename = nil

    if st.mode == "audio" and is_video then
        target_filename = cdir .. "/pin_audio_" .. time_id .. ".m4a"
    elseif st.mode == "gif" and is_video then
        target_filename = cdir .. "/pin_anim_" .. time_id .. ".mp4"
    end

    local dl_path = download_with_fallback(media_url, fallback_url, target_filename)
    if not dl_path or dl_path == "" then
        cb:edit_html("❌ <b>Ошибка при скачивании файла с сервера Pinterest.</b>")
        return
    end

    cb:edit_html("📤 <b>Отправляю файл...</b>")

    local safe_title = escape_html(title)
    local caption = "📌 <b>" .. (safe_title ~= "" and safe_title or "Pinterest") .. "</b>"
    if st.mode == "audio" and is_video then
        caption = "🎵 <b>" .. (safe_title ~= "" and safe_title or "Pinterest Audio") .. "</b>"
    end

    local target_chat = (st.chat_id and st.chat_id ~= 0) and st.chat_id or cb.chat_id
    if target_chat and target_chat ~= 0 then
        koto.send_file(target_chat, dl_path, caption, "html")
    else
        koto.reply_file(dl_path, caption, "html")
    end

    cb:delete()
    cb:answer("✅ Готово!")
end

-- Команда .pin (также .pindl, .pinterest)
function cmd_pin(msg, args)
    if msg and msg.id and msg.id ~= 0 then
        local key = tostring(msg.chat_id or 0) .. ":" .. tostring(msg.id)
        if last_msg_key == key then return end
        last_msg_key = key
    end

    local reply_text = get_reply_field(msg, "text") or ""
    local reply_id = get_reply_field(msg, "id") or (msg.reply_to_msg_id and msg.reply_to_msg_id ~= 0 and msg.reply_to_msg_id or msg.id)

    local url = find_pinterest_url(args)
    if not url and reply_text ~= "" then
        url = find_pinterest_url(reply_text)
    end
    if not url and msg.text then
        url = find_pinterest_url(msg.text)
    end

    if not url then
        msg:edit_html("❌ <b>Укажите ссылку на пин или ответьте на сообщение со ссылкой.</b>")
        return
    end

    local now = os.time()
    for sid_old, item in pairs(sessions) do
        if item.created_at and (now - item.created_at > 3600) then
            sessions[sid_old] = nil
        end
    end

    local sid = tostring(now) .. "_" .. tostring(math.random(100000, 999999))
    local st = {
        url = url,
        mode = "video",
        quality = "best",
        chat_id = msg.chat_id,
        reply_to = reply_id,
        created_at = now
    }
    sessions[sid] = st

    msg:buttons(get_buttons(sid, st))
    msg:edit_html(get_text(st))
end

cmd_pindl = cmd_pin
cmd_pinterest = cmd_pin

-- Обработка кликов по инлайн-кнопкам
function on_callback(cb)
    if not cb.data or not cb.data:match("^pin:") then
        return
    end

    local sid, mode = cb.data:match("^pin:m:([%w_]+):(%w+)$")
    if sid and mode then
        local st = sessions[sid]
        if not st then
            cb:answer("⚠️ Сессия устарела", true)
            cb:edit_html("⚠️ <b>Сессия устарела. Отправьте команду заново.</b>")
            return
        end
        st.mode = mode
        cb:buttons(get_buttons(sid, st))
        cb:edit_html(get_text(st))
        cb:answer("Формат: " .. (MODES[mode] or mode))
        return
    end

    local q_sid, qual = cb.data:match("^pin:q:([%w_]+):([%w]+)$")
    if q_sid and qual then
        local st = sessions[q_sid]
        if not st then
            cb:answer("⚠️ Сессия устарела", true)
            cb:edit_html("⚠️ <b>Сессия устарела. Отправьте команду заново.</b>")
            return
        end
        st.quality = qual
        cb:buttons(get_buttons(q_sid, st))
        cb:edit_html(get_text(st))
        cb:answer("Качество: " .. (QUALITIES[qual] or qual))
        return
    end

    local c_sid = cb.data:match("^pin:c:([%w_]+)$")
    if c_sid then
        sessions[c_sid] = nil
        cb:delete()
        cb:answer("Отменено")
        return
    end

    local dl_sid = cb.data:match("^pin:dl:([%w_]+)$")
    if dl_sid then
        local st = sessions[dl_sid]
        if not st then
            cb:answer("⚠️ Сессия устарела", true)
            cb:edit_html("⚠️ <b>Сессия устарела. Отправьте команду заново.</b>")
            return
        end
        cb:answer("⏳ Начинаю скачивание...")
        handle_download(cb, st)
        sessions[dl_sid] = nil
        return
    end
end
