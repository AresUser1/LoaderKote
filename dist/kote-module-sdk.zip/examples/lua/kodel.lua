-- ============================================================================
-- Модуль: Kodel
-- Автор оригинала (Hikka): @Kovalsky_modules
-- Адаптация и расширение для Kotogram: Kote Team
-- Версия: 1.0.0
-- Описание: Быстрое удаление сообщений (по ответу или по количеству)
-- ============================================================================

name = "Kodel"
description = "Быстрое удаление сообщений: по ответу или по количеству (.d, .d 5)"
version = "1.0.0"
min_host_version = 114

commands = {
    {
        name = "d",
        usage = "[кол-во] (в ответ или без)",
        doc = "Удалить сообщение по ответу, либо N сообщений (.d 5)"
    },
    {
        name = "del",
        usage = "[кол-во]",
        doc = "Алиас для команды .d"
    },
    {
        name = "kodel",
        usage = "[кол-во]",
        doc = "Алиас для команды .d"
    }
}

-- Безопасное определение ID сообщения, на которое сделан ответ
local function get_reply_id(msg)
    if not msg then return nil end
    if msg.reply_to_msg_id and msg.reply_to_msg_id ~= 0 then
        return msg.reply_to_msg_id
    end
    if type(msg.reply_msg) == "table" and msg.reply_msg.id and msg.reply_msg.id ~= 0 then
        return msg.reply_msg.id
    end
    if type(msg.reply) == "table" and msg.reply.id and msg.reply.id ~= 0 then
        return msg.reply.id
    end
    return nil
end

-- Основная логика удаления сообщений
function cmd_d(msg, args)
    local chat_id = msg.chat_id
    local my_id = msg.id
    local reply_id = get_reply_id(msg)

    local count = tonumber(args and args:match("(%d+)") or nil)

    if reply_id then
        if count and count > 1 then
            -- Удаляем N сообщений ниже начиная с ответа (включая сам ответ)
            for i = 0, count - 1 do
                koto.delete(chat_id, reply_id + i)
            end
        else
            -- Удаляем только то сообщение, на которое ответили
            koto.delete(chat_id, reply_id)
        end
    else
        -- Если команда вызвана без реплая, но с указанием числа (.d 5):
        -- удаляем N предыдущих сообщений перед командой
        if count and count > 0 then
            for i = 1, count do
                koto.delete(chat_id, my_id - i)
            end
        end
    end

    -- Удаляем само сообщение с вызовом команды .d
    msg:delete()
end

cmd_del = cmd_d
cmd_kodel = cmd_d

-- Обязательная точка входа для Kotogram
function on_message(msg)
    if not msg or not msg.out then return end
    local text = msg.text or ""
    local cmd, rest = text:match("^[%.!/](%w+)%s*(.*)$")
    if cmd then
        cmd = cmd:lower()
        if cmd == "d" or cmd == "del" or cmd == "kodel" then
            cmd_d(msg, rest)
            return
        end
    end
end
